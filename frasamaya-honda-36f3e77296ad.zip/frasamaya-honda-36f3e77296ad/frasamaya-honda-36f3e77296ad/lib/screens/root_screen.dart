import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/core/blocs/authentication/authentication_bloc.dart';
import 'package:honda/core/blocs/authentication/authentication_event.dart';
import 'package:honda/core/blocs/authentication/authentication_state.dart';
import 'package:honda/core/helpers/prefs.dart';
import 'package:honda/screens/main_screen.dart';
import 'package:honda/screens/onboarding_screen.dart';
import 'package:honda/screens/splash_screen.dart';

class RootScreen extends StatefulWidget {
  @override
  _RootScreenState createState() => _RootScreenState();
}

class _RootScreenState extends State<RootScreen> {
  ThemeData _themeData = ThemeData(
    fontFamily: 'CeraPro',
    inputDecorationTheme: InputDecorationTheme(
      border: OutlineInputBorder(borderSide: BorderSide(color: Colors.grey)),
      enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.grey)),
      focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.black)),
      errorBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.red)),
      focusedErrorBorder: OutlineInputBorder(borderSide: BorderSide(color: Colors.red)),
      errorStyle: TextStyle(fontSize: 14),
    ),
    appBarTheme: AppBarTheme(
      color: Colors.white,
      textTheme: TextTheme(
        headline6: TextStyle(
          color: Colors.black,
          fontSize: 20,
          fontWeight: FontWeight.bold,
        ),
      ),
      iconTheme: IconThemeData(color: Colors.black),
      elevation: 0,
    ),
  );

  AuthenticationBloc _authenticationBloc;
  FirebaseMessaging _firebaseMessaging;

  @override
  void initState() {
    _authenticationBloc = AuthenticationBloc();
    _firebaseMessaging = FirebaseMessaging();
    _firebaseMessaging.configure(
      onMessage: (Map<String, dynamic> message) async {
        debugPrint('onMessage: $message');
      },
      onResume: (Map<String, dynamic> message) async {
        debugPrint('onResume: $message');
      },
      onLaunch: (Map<String, dynamic> message) async {
        debugPrint('onLaunch: $message');
      },
    );
    _firebaseMessaging.getToken().then((token) async {
      print("TOKEN" + token);
      await setFcm(token);
    });
    super.initState();

    _authenticationBloc.add(Authenticate());
  }

  @override
  void dispose() {
    _authenticationBloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (context) => _authenticationBloc),
      ],
      child: MaterialApp(
        title: 'Honda',
        theme: _themeData,
        home: MultiBlocListener(
          listeners: [
            BlocListener<AuthenticationBloc, AuthenticationState>(
              listener: (context, state) async {
                if (state is SuccessAuthenticationState) {
                  await setRegisterId(''); // clear register id
                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => MainScreen()));
                }
              },
            ),
          ],
          child: BlocBuilder<AuthenticationBloc, AuthenticationState>(
            builder: (context, state) {
              if (state is FailedAuthenticationState) {
                return OnboardingScreen();
              }
              return SplashScreen();
            },
          ),
        ),
      ),
    );
  }
}
