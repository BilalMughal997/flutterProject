import 'package:double_back_to_close_app/double_back_to_close_app.dart';
import 'package:flutter/material.dart';
import 'package:honda/features/home/screens/home_section.dart';
import 'package:honda/features/product/screens/product_section.dart';
import 'package:honda/features/profile/screens/profile_section.dart';
import 'package:honda/features/service/screens/service_section.dart';
import 'package:honda/features/simulation/screen/simulation_section.dart';

import '../widgets/honda_navigation_widget.dart';

class MainScreen extends StatefulWidget {
  final HondaMenu menu;

  const MainScreen({Key key, this.menu}) : super(key: key);

  @override
  _MainScreenState createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  HondaMenu _currentMenu;
  GlobalKey<ScaffoldState> _scaffoldKey;

  @override
  void initState() {
    _currentMenu = widget.menu ?? HondaMenu.HOME;
    _scaffoldKey = GlobalKey<ScaffoldState>();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      bottomNavigationBar: HondaNavigationWidget(
        onChanged: _onMenuChanged,
        currentMenu: _currentMenu,
      ),
      body: DoubleBackToCloseApp(
        snackBar: SnackBar(content: Text('Tekan back lagi untuk keluar.')),
        child: _defineScreen(),
      ),
    );
  }

  _onMenuChanged(HondaMenu currentMenu) {
    setState(() {
      _currentMenu = currentMenu;
    });
  }

  Widget _defineScreen() {
    return IndexedStack(
      index: _currentMenu.index,
      children: <Widget>[
        HomeSection(),
        ProductSection(scaffoldKey: _scaffoldKey),
        ServiceSection(),
        SimulationSection(scaffoldKey: _scaffoldKey),
        ProfileSection(),
      ],
    );
  }
}
