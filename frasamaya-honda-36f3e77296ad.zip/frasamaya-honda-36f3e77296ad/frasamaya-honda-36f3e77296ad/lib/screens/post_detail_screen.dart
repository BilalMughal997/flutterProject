import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';

class PostDetailScreen extends StatelessWidget {
  final String title;
  final DateTime date;
  final ImageProvider image;
  final String content;

  const PostDetailScreen({Key key, this.title, this.date, this.image, this.content}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final df = DateFormat('dd MMM yyyy');
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail'),
      ),
      body: Container(
        child: SingleChildScrollView(
          padding: EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Container(
                child: Text(
                  title,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              SizedBox(height: 20),
              Container(
                width: MediaQuery.of(context).size.width,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text(
                      date == null ? '-' : df.format(date),
                      style: TextStyle(color: Colors.grey),
                    ),
                    Divider(),
                    Row(
                      children: <Widget>[
                        Text('By: Administrator', style: TextStyle(color: Colors.grey)),
                        Spacer(),
                        // Icon(Icons.share, color: Colors.grey),
                        // SizedBox(width: 10),
                        // Text('230', style: TextStyle(color: Colors.grey)),
                      ],
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Container(
                child: Image(
                  image: image,
                ),
              ),
              SizedBox(height: 20),
              Container(
                child: Text(content),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
