import 'package:flutter/material.dart';

class SplashScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        child: Stack(
          alignment: Alignment.center,
          fit: StackFit.expand,
          children: <Widget>[
            FittedBox(
              fit: BoxFit.fill,
              child: Image(
                image: AssetImage('assets/images/BG.jpg'),
              ),
            ),
            Container(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: <Widget>[
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.25,
                  ),
                  Image(image: AssetImage('assets/images/logo_with_text.png'), width: MediaQuery.of(context).size.height * 0.20),
                  SizedBox(height: 20),
                  Text(
                    'Selamat Datang di Aplikasi',
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    'Honda Royal Kenjeran',
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(
                    height: MediaQuery.of(context).size.height * 0.45,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
