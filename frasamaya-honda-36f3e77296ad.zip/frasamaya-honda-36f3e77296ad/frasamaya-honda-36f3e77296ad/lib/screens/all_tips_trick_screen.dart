import 'package:flutter/material.dart';

class AllTipsTrickScreen extends StatefulWidget {
  @override
  _AllTipsTrickScreenState createState() => _AllTipsTrickScreenState();
}

class _AllTipsTrickScreenState extends State<AllTipsTrickScreen> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Semua TipsTrick'),
      ),
      body: Container(),
    );
  }
}
