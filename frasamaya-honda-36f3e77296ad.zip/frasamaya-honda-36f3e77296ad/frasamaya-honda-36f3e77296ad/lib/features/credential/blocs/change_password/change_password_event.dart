import 'package:equatable/equatable.dart';
import 'package:honda/features/credential/models/change_password_form.dart';

abstract class ChangePasswordEvent extends Equatable {
  const ChangePasswordEvent();
}

class Change extends ChangePasswordEvent {
  final ChangePasswordForm form;

  Change(this.form);

  @override
  List<Object> get props => [form];
}
