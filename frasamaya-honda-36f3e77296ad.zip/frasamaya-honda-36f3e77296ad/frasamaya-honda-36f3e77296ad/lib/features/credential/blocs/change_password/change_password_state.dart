import 'package:equatable/equatable.dart';

abstract class ChangePasswordState extends Equatable {
  const ChangePasswordState();
}

class InitialChangePasswordState extends ChangePasswordState {
  @override
  List<Object> get props => [];
}

class LoadingChangePasswordState extends ChangePasswordState {
  @override
  List<Object> get props => [];
}

class SuccessChangePasswordState extends ChangePasswordState {
  @override
  List<Object> get props => [];
}

class FailedChangePasswordState extends ChangePasswordState {
  final String reason;

  FailedChangePasswordState(this.reason);

  @override
  List<Object> get props => [];
}
