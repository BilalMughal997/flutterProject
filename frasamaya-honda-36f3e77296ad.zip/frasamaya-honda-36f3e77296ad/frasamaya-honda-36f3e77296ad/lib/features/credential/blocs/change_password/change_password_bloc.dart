import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/credential/contracts/change_password_repository_contract.dart';

import './bloc.dart';

class ChangePasswordBloc extends Bloc<ChangePasswordEvent, ChangePasswordState> {
  ChangePasswordRepositoryContract _repository;

  ChangePasswordBloc() {
    _repository = GetIt.I<ChangePasswordRepositoryContract>();
  }

  @override
  ChangePasswordState get initialState => InitialChangePasswordState();

  @override
  Stream<ChangePasswordState> mapEventToState(
    ChangePasswordEvent event,
  ) async* {
    if (event is Change) {
      yield LoadingChangePasswordState();

      try {
        final res = await _repository.updatePassword(event.form);
        if (res)
          yield SuccessChangePasswordState();
        else
          yield FailedChangePasswordState('Gagal mengganti password');
      } catch (e) {
        yield FailedChangePasswordState(e.toString());
      }
    }
  }
}
