import 'package:equatable/equatable.dart';

abstract class ChangePhoneState extends Equatable {
  const ChangePhoneState();
}

class InitialChangePhoneState extends ChangePhoneState {
  @override
  List<Object> get props => [];
}

class LoadingChangePhoneState extends ChangePhoneState {
  @override
  List<Object> get props => [];
}

class SuccessChangePhoneState extends ChangePhoneState {
  @override
  List<Object> get props => [];
}

class FailedChangePhoneState extends ChangePhoneState {
  final String reason;

  FailedChangePhoneState(this.reason);

  @override
  List<Object> get props => [reason];
}
