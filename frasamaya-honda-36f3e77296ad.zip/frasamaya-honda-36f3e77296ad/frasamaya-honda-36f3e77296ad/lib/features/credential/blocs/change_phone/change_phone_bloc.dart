import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/credential/contracts/change_phone_repository_contract.dart';

import './bloc.dart';

class ChangePhoneBloc extends Bloc<ChangePhoneEvent, ChangePhoneState> {
  ChangePhoneRepositoryContract _repository;

  ChangePhoneBloc() {
    _repository = GetIt.I<ChangePhoneRepositoryContract>();
  }

  @override
  ChangePhoneState get initialState => InitialChangePhoneState();

  @override
  Stream<ChangePhoneState> mapEventToState(
    ChangePhoneEvent event,
  ) async* {
    if (event is ChangePhone) {
      yield LoadingChangePhoneState();

      try {
        final res = await _repository.changePhone(event.form);
        if (res)
          yield SuccessChangePhoneState();
        else
          FailedChangePhoneState('Gagal ganti nomer');
      } catch (e) {
        yield FailedChangePhoneState(e.toString());
      }
    }
  }
}
