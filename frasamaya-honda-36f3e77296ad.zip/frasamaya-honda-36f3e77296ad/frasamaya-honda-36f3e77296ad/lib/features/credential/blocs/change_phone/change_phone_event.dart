import 'package:equatable/equatable.dart';
import 'package:honda/features/credential/models/change_password_form.dart';

abstract class ChangePhoneEvent extends Equatable {
  const ChangePhoneEvent();
}

class ChangePhone extends ChangePhoneEvent {
  final ChangeNumberForm form;

  ChangePhone(this.form);

  @override
  List<Object> get props => [form];
}
