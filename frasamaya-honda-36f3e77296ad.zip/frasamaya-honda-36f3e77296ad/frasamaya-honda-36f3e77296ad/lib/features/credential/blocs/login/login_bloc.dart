import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/core/helpers/prefs.dart';
import 'package:honda/features/credential/contracts/login_repository_contract.dart';

import './bloc.dart';

class LoginBloc extends Bloc<LoginEvent, LoginState> {
  LoginRepositoryContract _loginRepository;
  String _token;
  bool _loading;

  String get token => _token;

  bool get loading => _loading;

  LoginBloc() {
    _loginRepository = GetIt.I<LoginRepositoryContract>();
    _loading = false;
  }

  @override
  LoginState get initialState => InitialLoginState();

  @override
  Stream<LoginState> mapEventToState(
    LoginEvent event,
  ) async* {
    if (event is DoLogin) {
      _loading = true;
      yield LoadingLoginState();

      try {
        _token = await _loginRepository.getToken(event.credential);
        setToken(_token);
        yield SuccessLoginState(_token);
      } catch (e) {
        _loading = false;
        yield FailedLoginState('Periksa kembali credential anda.');
      }
    }
  }
}
