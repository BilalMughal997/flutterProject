import 'package:equatable/equatable.dart';

abstract class LoginState extends Equatable {
  const LoginState();
}

class InitialLoginState extends LoginState {
  @override
  List<Object> get props => [];
}

class LoadingLoginState extends LoginState {
  @override
  List<Object> get props => null;
}

class SuccessLoginState extends LoginState {
  final String token;

  SuccessLoginState(this.token);

  @override
  List<Object> get props => [this.token];
}

class FailedLoginState extends LoginState {
  final String reason;

  FailedLoginState(this.reason);

  @override
  List<Object> get props => [this.reason];
}
