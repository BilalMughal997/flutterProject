import 'package:equatable/equatable.dart';
import 'package:honda/core/models/user.dart';

abstract class LoginEvent extends Equatable {
  const LoginEvent();
}

class DoLogin extends LoginEvent {
  final Credential credential;

  DoLogin(this.credential);

  @override
  List<Object> get props => [this.credential];
}
