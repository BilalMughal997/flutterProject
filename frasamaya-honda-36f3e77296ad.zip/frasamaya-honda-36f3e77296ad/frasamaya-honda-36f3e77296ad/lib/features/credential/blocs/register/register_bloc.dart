import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/credential/contracts/register_repository_contract.dart';

import './bloc.dart';

class RegisterBloc extends Bloc<RegisterEvent, RegisterState> {
  RegisterRepositoryContract _registerRepository;
  bool _loading;

  RegisterBloc() {
    _registerRepository = GetIt.I<RegisterRepositoryContract>();
    _loading = false;
  }

  bool get loading => _loading;

  @override
  RegisterState get initialState => InitialRegisterState();

  @override
  Stream<RegisterState> mapEventToState(
    RegisterEvent event,
  ) async* {
    if (event is DoRegister) {
      _loading = true;
      yield LoadingRegisterState();

      try {
        final _result = await _registerRepository.register(event.registerForm);
        if (_result == null) throw Exception('Registrasi gagal');
        yield SuccessRegisterState(_result);
      } catch (e) {
        yield FailedRegisterState(e.toString());
      }

      _loading = false;
    }
  }
}
