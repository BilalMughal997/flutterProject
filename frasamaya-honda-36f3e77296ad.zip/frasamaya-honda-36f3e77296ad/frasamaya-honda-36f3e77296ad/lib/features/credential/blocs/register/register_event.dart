import 'package:equatable/equatable.dart';
import 'package:honda/core/models/user.dart';

abstract class RegisterEvent extends Equatable {
  const RegisterEvent();
}

class DoRegister extends RegisterEvent {
  final Register registerForm;

  DoRegister(this.registerForm);

  @override
  List<Object> get props => [this.registerForm];
}
