import 'package:equatable/equatable.dart';

abstract class RegisterState extends Equatable {
  const RegisterState();
}

class InitialRegisterState extends RegisterState {
  @override
  List<Object> get props => [];
}

class LoadingRegisterState extends RegisterState {
  @override
  List<Object> get props => null;
}

class SuccessRegisterState extends RegisterState {
  final String result;

  SuccessRegisterState(this.result);

  @override
  List<Object> get props => [this.result];
}

class FailedRegisterState extends RegisterState {
  final String reason;

  FailedRegisterState(this.reason);

  @override
  List<Object> get props => [this.reason];
}
