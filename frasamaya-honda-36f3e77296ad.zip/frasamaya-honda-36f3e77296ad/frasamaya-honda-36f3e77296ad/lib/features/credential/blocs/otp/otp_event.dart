import 'package:equatable/equatable.dart';

abstract class OtpEvent extends Equatable {
  const OtpEvent();
}

class VerifyNumber extends OtpEvent {
  final String phone;
  final String code;

  VerifyNumber(this.phone, this.code);

  @override
  List<Object> get props => [phone, code];
}

class VerifyNumberPassword extends OtpEvent {
  final String phone;
  final String code;

  VerifyNumberPassword(this.phone, this.code);

  @override
  List<Object> get props => [phone, code];
}

class ResendOtp extends OtpEvent {
  final String phone;

  ResendOtp(this.phone);

  @override
  List<Object> get props => [phone];
}
