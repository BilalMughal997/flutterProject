import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/core/contracts/auth_repository_contract.dart';
import 'package:honda/core/helpers/prefs.dart';
import 'package:honda/features/credential/contracts/otp_repository_contract.dart';

import './bloc.dart';

class OtpBloc extends Bloc<OtpEvent, OtpState> {
  OtpRepositoryContract _repository;
  AuthRepositoryContract _authRepository;

  OtpBloc() {
    _repository = GetIt.I<OtpRepositoryContract>();
    _authRepository = GetIt.I<AuthRepositoryContract>();
  }

  @override
  OtpState get initialState => InitialOtpState();

  @override
  Stream<OtpState> mapEventToState(
    OtpEvent event,
  ) async* {
    if (event is VerifyNumber) {
      yield LoadingOtpState();

      try {
        final res = await _repository.verify(event.phone, event.code);
        if (res == '') throw Exception('Verifikasi gagal');
        setToken(res);
        yield SuccessOtpState();
      } catch (e) {
        yield FailedOtpState(e.toString());
      }
    }

    if (event is ResendOtp) {
      try {
        final res = await _repository.resend(event.phone);
        if (!res) throw Exception('Verifikasi gagal');
      } catch (e) {}
    }

    if (event is VerifyNumberPassword) {
      yield LoadingOtpState();

      try {
        final res = await _repository.verify(event.phone, event.code);
        if (res == '') throw Exception('Verifikasi gagal');
        setToken(res);
        final user = await _authRepository.getUser();
        setToken('');
        if (user == null) throw Exception('Verifikasi gagal');
        yield SuccessOtpState(user: user);
      } catch (e) {
        yield FailedOtpState(e.toString());
      }
    }
  }
}
