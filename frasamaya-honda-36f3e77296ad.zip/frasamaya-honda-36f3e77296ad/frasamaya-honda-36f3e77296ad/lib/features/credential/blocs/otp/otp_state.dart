import 'package:equatable/equatable.dart';
import 'package:honda/core/models/user.dart';

abstract class OtpState extends Equatable {
  const OtpState();
}

class InitialOtpState extends OtpState {
  @override
  List<Object> get props => [];
}

class LoadingOtpState extends OtpState {
  @override
  List<Object> get props => null;
}

class SuccessOtpState extends OtpState {
  final User user;

  SuccessOtpState({this.user});
  @override
  List<Object> get props => [user];
}

class FailedOtpState extends OtpState {
  final String reason;

  FailedOtpState(this.reason);

  @override
  List<Object> get props => [reason];
}
