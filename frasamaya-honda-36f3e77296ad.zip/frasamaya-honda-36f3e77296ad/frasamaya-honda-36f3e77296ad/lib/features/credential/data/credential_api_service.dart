import 'package:chopper/chopper.dart';
import 'package:honda/core/client_preset.dart';

part 'credential_api_service.chopper.dart';

@ChopperApi(baseUrl: 'user')
abstract class CredentialApiService extends ChopperService {
  @Post(path: '/')
  Future<Response> register(@Body() Map<String, dynamic> body);

  @Post(path: 'login')
  Future<Response> getToken(@Body() Map<String, dynamic> body);

  @Post(path: 'resend')
  Future<Response> resendOTP(@Body() Map<String, dynamic> body);

  @Post(path: 'verify')
  Future<Response> verifyOTP(@Body() Map<String, dynamic> body);

  @Post(path: 'forgot')
  Future<Response> forgotPassword(@Body() Map<String, dynamic> body);

  @Post(path: 'update')
  Future<Response> updatePassword(@Body() Map<String, dynamic> body);

  @Post(path: 'changephone')
  Future<Response> changePhone(@Body() Map<String, dynamic> body);

  static CredentialApiService create() {
    final client = ClientPreset.client(services: [_$CredentialApiService()]);
    return _$CredentialApiService(client);
  }
}
