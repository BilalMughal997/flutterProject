import 'package:honda/features/credential/models/change_password_form.dart';

abstract class ChangePhoneRepositoryContract {
  Future<bool> changePhone(ChangeNumberForm form);
}
