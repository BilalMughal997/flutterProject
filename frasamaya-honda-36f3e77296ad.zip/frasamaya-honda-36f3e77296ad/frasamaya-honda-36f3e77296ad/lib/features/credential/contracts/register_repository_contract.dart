import 'package:honda/core/models/user.dart';

abstract class RegisterRepositoryContract {
  Future<String> register(Register registerForm);
}
