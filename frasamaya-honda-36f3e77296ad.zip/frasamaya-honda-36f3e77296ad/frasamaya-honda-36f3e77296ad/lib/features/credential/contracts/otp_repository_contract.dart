abstract class OtpRepositoryContract {
  Future<String> verify(String phone, String code);

  Future<bool> resend(String phone);
}
