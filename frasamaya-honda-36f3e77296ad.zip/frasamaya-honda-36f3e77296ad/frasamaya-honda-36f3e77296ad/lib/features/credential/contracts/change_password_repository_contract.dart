import 'package:honda/features/credential/models/change_password_form.dart';

abstract class ChangePasswordRepositoryContract {
  Future<bool> updatePassword(ChangePasswordForm form);
}
