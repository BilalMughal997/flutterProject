import 'package:honda/core/models/user.dart';

abstract class LoginRepositoryContract {
  Future<String> getToken(Credential credential);
}
