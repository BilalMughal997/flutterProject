import 'package:honda/features/credential/contracts/change_password_repository_contract.dart';
import 'package:honda/features/credential/data/credential_api_service.dart';
import 'package:honda/features/credential/models/change_password_form.dart';

class ChangePasswordRepository implements ChangePasswordRepositoryContract {
  CredentialApiService _service;

  ChangePasswordRepository() {
    _service = CredentialApiService.create();
  }

  @override
  Future<bool> updatePassword(ChangePasswordForm form) async {
    final resp = await _service.updatePassword(form.toJson());
    return resp.statusCode >= 200 || resp.statusCode < 300;
  }
}
