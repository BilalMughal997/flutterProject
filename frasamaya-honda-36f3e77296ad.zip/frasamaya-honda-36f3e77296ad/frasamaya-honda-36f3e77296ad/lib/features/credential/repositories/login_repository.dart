import 'package:honda/core/models/user.dart';
import 'package:honda/features/credential/contracts/login_repository_contract.dart';
import 'package:honda/features/credential/data/credential_api_service.dart';

class LoginRepository implements LoginRepositoryContract {
  CredentialApiService _service;

  LoginRepository() {
    _service = CredentialApiService.create();
  }

  @override
  Future<String> getToken(Credential credential) async {
    final resp = await _service.getToken(credential.toJson());
    return resp.body['token'] ?? '';
  }
}
