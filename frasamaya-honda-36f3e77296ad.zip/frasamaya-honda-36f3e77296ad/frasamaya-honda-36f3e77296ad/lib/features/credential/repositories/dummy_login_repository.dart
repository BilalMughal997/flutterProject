import 'package:honda/core/models/user.dart';
import 'package:honda/features/credential/contracts/login_repository_contract.dart';

class DummyLoginRepository implements LoginRepositoryContract {
  @override
  Future<String> getToken(Credential credential) async {
    await Future.delayed(Duration(seconds: 3));
//    return Future.error("gagal login");
    return Future.value("ikitoken");
  }
}
