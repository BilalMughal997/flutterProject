import 'package:honda/core/models/user.dart';
import 'package:honda/features/credential/contracts/register_repository_contract.dart';

class DummyRegisterRepository implements RegisterRepositoryContract {
  @override
  Future<String> register(Register registerForm) async {
    await Future.delayed(Duration(seconds: 2));
    return Future.value('true');
  }
}
