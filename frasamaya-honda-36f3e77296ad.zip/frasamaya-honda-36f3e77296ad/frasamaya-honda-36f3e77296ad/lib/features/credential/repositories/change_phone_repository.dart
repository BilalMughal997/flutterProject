import 'package:honda/features/credential/contracts/change_phone_repository_contract.dart';
import 'package:honda/features/credential/data/credential_api_service.dart';
import 'package:honda/features/credential/models/change_password_form.dart';

class ChangePhoneRepository implements ChangePhoneRepositoryContract {
  CredentialApiService _service;

  ChangePhoneRepository() {
    _service = CredentialApiService.create();
  }

  @override
  Future<bool> changePhone(ChangeNumberForm form) async {
    final resp = await _service.changePhone(form.toJson());
    return resp.statusCode >= 200 && resp.statusCode < 300;
  }
}
