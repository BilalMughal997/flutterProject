import 'package:honda/core/models/user.dart';
import 'package:honda/features/credential/contracts/register_repository_contract.dart';
import 'package:honda/features/credential/data/credential_api_service.dart';

class RegisterRepository implements RegisterRepositoryContract {
  CredentialApiService _service;

  RegisterRepository() {
    _service = CredentialApiService.create();
  }

  @override
  Future<String> register(Register registerForm) async {
    final resp = await _service.register(registerForm.toJson());

    if (resp.statusCode >= 200 && resp.statusCode < 300) {
      return resp.body['userid'] is int ? resp.body['userid'].toString() : null;
    }

    return null;
  }
}
