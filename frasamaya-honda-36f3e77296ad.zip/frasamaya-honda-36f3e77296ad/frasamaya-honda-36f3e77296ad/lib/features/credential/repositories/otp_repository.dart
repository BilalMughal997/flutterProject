import 'package:honda/features/credential/contracts/otp_repository_contract.dart';
import 'package:honda/features/credential/data/credential_api_service.dart';

class OtpRepository implements OtpRepositoryContract {
  CredentialApiService _service;

  OtpRepository() {
    _service = CredentialApiService.create();
  }

  @override
  Future<bool> resend(String phone) async {
    final body = {'phone': phone};

    final resp = await _service.resendOTP(body);
    return resp.statusCode >= 200 && resp.statusCode < 300;
  }

  @override
  Future<String> verify(String phone, String code) async {
    final body = {
      'phone': phone,
      'otp': code,
    };

    final resp = await _service.verifyOTP(body);
    if (resp.statusCode >= 200 && resp.statusCode < 300) return resp.body['token'];
    return '';
  }
}
