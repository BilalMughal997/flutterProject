class ChangePasswordForm {
  String password;
  String phone;
  String repassword;

  ChangePasswordForm({this.password, this.phone, this.repassword});

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['password'] = this.password;
    data['phone'] = this.phone;
    data['repassword'] = this.repassword;
    return data;
  }
}

class ChangeNumberForm {
  String id;
  String phone;

  ChangeNumberForm({this.id, this.phone});

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['userid'] = this.id;
    data['phone'] = this.phone;
    return data;
  }
}
