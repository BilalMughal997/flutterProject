import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:honda/config/app_config.dart';

class CredentialTabWidget extends StatefulWidget {
  final CredentialTab currentTab;
  final ValueChanged<CredentialTab> onChanged;
  final Widget loginForm;
  final Widget registerForm;

  const CredentialTabWidget({
    Key key,
    this.currentTab,
    @required this.onChanged,
    @required this.loginForm,
    @required this.registerForm,
  }) : super(key: key);

  @override
  _CredentialTabWidgetState createState() => _CredentialTabWidgetState();
}

class _CredentialTabWidgetState extends State<CredentialTabWidget> {
  CredentialTab _currentTab;

  @override
  void initState() {
    _currentTab = widget.currentTab ?? CredentialTab.LOGIN;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 20),
      child: Stack(
        children: <Widget>[
          Container(
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              children: <Widget>[
                Expanded(
                  child: _theTab("Masuk", active: _currentTab == CredentialTab.LOGIN, onTap: () {
                    setState(() => _currentTab = CredentialTab.LOGIN);
                    widget.onChanged(CredentialTab.LOGIN);
                  }),
                ),
                Expanded(
                  child: _theTab("Daftar", active: _currentTab == CredentialTab.REGISTER, onTap: () {
                    setState(() => _currentTab = CredentialTab.REGISTER);
                    widget.onChanged(CredentialTab.REGISTER);
                  }),
                ),
              ],
            ),
          ),
          Container(
              margin: EdgeInsets.only(
                top: 49,
              ),
              child: _theTabView()),
        ],
      ),
    );
  }

  Widget _theTab(String text, {bool active: false, VoidCallback onTap}) {
    return InkWell(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(active ? 10 : 0),
          topRight: Radius.circular(active ? 10 : 0),
        ),
        child: Container(
          height: 50,
          color: !active ? AppConfig.of(context).color.primary : Colors.white,
          child: Center(
            child: Text(
              text,
              textAlign: TextAlign.center,
              style: TextStyle(
                color: !active ? Colors.white : AppConfig.of(context).color.primary,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _theTabView() {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.symmetric(
        horizontal: 25,
        vertical: 20,
      ),
      decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(_currentTab == CredentialTab.LOGIN ? 0 : 10),
            topRight: Radius.circular(_currentTab == CredentialTab.REGISTER ? 0 : 10),
            bottomLeft: Radius.circular(10),
            bottomRight: Radius.circular(10),
          ),
          border: Border.all(color: Colors.white, width: 5)),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Visibility(
            visible: _currentTab == CredentialTab.LOGIN,
            child: widget.loginForm,
          ),
          Visibility(
            visible: _currentTab == CredentialTab.REGISTER,
            child: widget.registerForm,
          ),
        ],
      ),
    );
  }
}

enum CredentialTab {
  LOGIN,
  REGISTER,
}
