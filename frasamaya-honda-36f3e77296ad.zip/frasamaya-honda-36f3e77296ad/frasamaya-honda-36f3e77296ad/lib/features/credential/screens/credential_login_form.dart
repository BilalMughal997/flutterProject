import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/config/app_config.dart';
import 'package:honda/core/blocs/authentication/authentication_bloc.dart';
import 'package:honda/core/blocs/authentication/authentication_event.dart';
import 'package:honda/core/helpers/prefs.dart';
import 'package:honda/core/models/user.dart';
import 'package:honda/features/credential/blocs/login/bloc.dart';
import 'package:honda/features/credential/screens/request_change_password_screen.dart';
import 'package:honda/widgets/honda_button.dart';

class CredentialLoginForm extends StatefulWidget {
  final GlobalKey<ScaffoldState> scaffoldKey;

  const CredentialLoginForm({
    Key key,
    @required this.scaffoldKey,
  }) : super(key: key);

  @override
  _CredentialLoginFormState createState() => _CredentialLoginFormState();
}

class _CredentialLoginFormState extends State<CredentialLoginForm> {
  bool _obscure;
  Credential _credential;
  GlobalKey<FormState> _formKey;
  LoginBloc _loginBloc;
  bool _loading;

  @override
  void initState() {
    _obscure = true;
    _credential = Credential();
    _formKey = GlobalKey<FormState>();
    _loginBloc = LoginBloc();
    _loading = false;
    super.initState();
  }

  @override
  void dispose() {
    _loginBloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => _loginBloc,
      child: BlocListener<LoginBloc, LoginState>(
        listener: (context, state) {
          if (state is LoadingLoginState) setState(() => _loading = true);
          if (state is SuccessLoginState) {
            BlocProvider.of<AuthenticationBloc>(context).add(Authenticate());
          }

          if (state is FailedLoginState) {
            setState(() => _loading = false);
            widget.scaffoldKey.currentState.showSnackBar(
              SnackBar(
                content: Text(state.reason),
              ),
            );
          }
        },
        child: Container(
          child: Form(
            key: _formKey,
            child: Column(
              children: <Widget>[
                Text(
                  'Masuk ke akun anda',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 40),
                TextFormField(
                  decoration: InputDecoration(
                    prefixIcon: new IconButton(
                      icon: Image.asset('assets/icons/mail_active.png', width: 25.0, height: 25.0),
                      onPressed: null,
                    ),
                    hintText: 'No.Telepon, cth: 081123123123',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (t) {
                    if (t.isEmpty) return 'No.Telepon diperlukan.';
                    return null;
                  },
                  onSaved: (t) {
                    setState(() => _credential.phone = t.substring(1, t.length));
                  },
                ),
                SizedBox(height: 10),
                TextFormField(
                  obscureText: _obscure,
                  validator: (t) {
                    if (t.isEmpty) return 'Kata sandi diperlukan.';
                    return null;
                  },
                  onSaved: (t) {
                    setState(() => _credential.password = t);
                  },
                  decoration: InputDecoration(
                    prefixIcon: new IconButton(
                      icon: Image.asset('assets/icons/lock_active.png', width: 25.0, height: 25.0),
                      onPressed: null,
                    ),
                    hintText: 'Kata Sandi',
                    suffixIcon: IconButton(
                      onPressed: () {
                        setState(() => _obscure = !_obscure);
                      },
                      icon: Icon(
                        Icons.remove_red_eye,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                SizedBox(
                  width: double.infinity,
                  child: InkWell(
                    onTap: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => RequestChangePasswordScreen()));
                    },
                    child: Text(
                      'Lupa kata sandi?',
                      textAlign: TextAlign.right,
                      style: TextStyle(
                        color: AppConfig.of(context).color.primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 40),
                SizedBox(
                  height: 60,
                  width: double.infinity,
                  child: PrimaryButton(
                    text: 'MASUK',
                    fontSize: 25,
                    onPressed: _submit,
                    loading: _loading,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _submit() async {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      _credential.fcm = await getFcm();
      print(_credential.fcm);
      _loginBloc.add(DoLogin(_credential));
    }
  }
}
