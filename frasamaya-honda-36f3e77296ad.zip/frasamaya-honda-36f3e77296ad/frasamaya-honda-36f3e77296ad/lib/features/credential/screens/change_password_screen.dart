import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/features/credential/blocs/change_password/bloc.dart';
import 'package:honda/features/credential/models/change_password_form.dart';
import 'package:honda/features/credential/screens/credential_screen.dart';
import 'package:honda/widgets/honda_button.dart';

class ChangePasswordScreen extends StatefulWidget {
  final String phone;

  const ChangePasswordScreen({Key key, @required this.phone}) : super(key: key);
  @override
  _ChangePasswordScreenState createState() => _ChangePasswordScreenState();
}

class _ChangePasswordScreenState extends State<ChangePasswordScreen> {
  ChangePasswordForm _form;
  bool _loading;
  TextEditingController _controller;
  GlobalKey<FormState> _formKey;
  ChangePasswordBloc _bloc;

  @override
  void initState() {
    _form = ChangePasswordForm();
    _loading = false;
    _controller = TextEditingController(text: '');
    _formKey = GlobalKey<FormState>();
    _bloc = ChangePasswordBloc();
    super.initState();

    _form.phone = "0" + widget.phone;
  }

  @override
  void dispose() {
    _bloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Ganti Password"),
      ),
      body: BlocProvider(
        create: (context) => _bloc,
        child: BlocListener(
          bloc: _bloc,
          listener: (context, state) async {
            if (state is LoadingChangePasswordState) setState(() => _loading = true);

            if (state is SuccessChangePasswordState) {
              setState(() {
                _loading = false;
              });

              await showDialog(
                  context: context,
                  builder: (context) => AlertDialog(
                        title: Text('Berhasil'),
                        actions: <Widget>[
                          FlatButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: Text('OK'),
                          ),
                        ],
                      ));

              Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => CredentialScreen()));
            }
          },
          child: Container(
            child: Form(
              key: _formKey,
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  children: <Widget>[
                    TextFormField(
                      obscureText: true,
                      controller: _controller,
                      decoration: InputDecoration(
                        prefixIcon: new IconButton(
                          icon: Image.asset('assets/icons/lock_active.png', width: 25.0, height: 25.0),
                          onPressed: null,
                        ),
                        hintText: 'Masukan password baru',
                      ),
                      validator: (t) {
                        if (t.isEmpty) return 'Password diperlukan.';
                        return null;
                      },
                      onSaved: (t) {
                        setState(() => _form.password = t);
                      },
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      obscureText: true,
                      decoration: InputDecoration(
                        prefixIcon: new IconButton(
                          icon: Image.asset('assets/icons/lock_active.png', width: 25.0, height: 25.0),
                          onPressed: null,
                        ),
                        hintText: 'Ulangi password baru',
                      ),
                      validator: (t) {
                        if (t.isEmpty) return 'Password diperlukan.';
                        if (t != _controller.text) return 'Password tidak sama';
                        return null;
                      },
                      onSaved: (t) {
                        setState(() => _form.repassword = t);
                      },
                    ),
                    SizedBox(height: 40),
                    SizedBox(
                      height: 60,
                      width: double.infinity,
                      child: PrimaryButton(
                        text: 'submit'.toUpperCase(),
                        fontSize: 25,
                        onPressed: _submit,
                        loading: _loading,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _submit() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      _bloc.add(Change(_form));
    }
  }
}
