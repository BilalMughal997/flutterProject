import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/config/app_config.dart';
import 'package:honda/core/helpers/prefs.dart';
import 'package:honda/core/models/user.dart';
import 'package:honda/features/credential/blocs/register/bloc.dart';
import 'package:honda/features/credential/screens/credential_phone_verification_screen.dart';
import 'package:honda/widgets/honda_button.dart';

class CredentialRegisterForm extends StatefulWidget {
  final GlobalKey<ScaffoldState> scaffoldKey;

  const CredentialRegisterForm({Key key, @required this.scaffoldKey}) : super(key: key);

  @override
  _CredentialRegisterFormState createState() => _CredentialRegisterFormState();
}

class _CredentialRegisterFormState extends State<CredentialRegisterForm> {
  bool _obscure;
  bool _obscure2;
  RegisterBloc _registerBloc;
  GlobalKey<FormState> _formKey;
  Register _registerForm;
  TextEditingController _controller;

  @override
  void initState() {
    _obscure = true;
    _obscure2 = true;
    _registerBloc = RegisterBloc();
    _formKey = GlobalKey<FormState>();
    _registerForm = Register();
    _controller = TextEditingController(text: '');
    super.initState();
  }

  @override
  void dispose() {
    _registerBloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => _registerBloc,
      child: BlocListener<RegisterBloc, RegisterState>(
        listener: (context, state) async {
          if (state is SuccessRegisterState) {
            widget.scaffoldKey.currentState.showSnackBar(
              SnackBar(
                content: Text('Success'),
              ),
            );

            _formKey.currentState.reset();
            _controller.clear();
            await setRegisterId(state.result);
            final otp = await Navigator.push(context, MaterialPageRoute(builder: (context) => CredentialPhoneVerificationScreen(phoneNumber: _registerForm.phone)));

            if (otp is bool && otp) {
              widget.scaffoldKey.currentState.showSnackBar(SnackBar(content: Text('Akun berhasil di buat, silahkan login.')));
            }
          }

          if (state is FailedRegisterState) {
            widget.scaffoldKey.currentState.showSnackBar(
              SnackBar(
                content: Text(state.reason),
              ),
            );
          }
        },
        child: Container(
          child: Form(
            key: _formKey,
            child: Column(
              children: <Widget>[
                Text(
                  'Silahkan daftarkan akun anda',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 40),
                TextFormField(
                  validator: (t) {
                    if (t.isEmpty) return 'Nama lengkap diperlukan.';
                    return null;
                  },
                  onSaved: (t) => setState(() => _registerForm.name = t),
                  keyboardType: TextInputType.text,
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.account_circle, color: AppConfig.of(context).color.primary),
                    hintText: 'Nama Lengkap',
                  ),
                ),
                SizedBox(height: 10),
                TextFormField(
                  validator: (t) {
                    if (t.isEmpty) return 'No. Telepon diperlukan.';
                    return null;
                  },
                  onSaved: (t) => setState(() => _registerForm.phone = t.substring(1, t.length)),
                  keyboardType: TextInputType.number,
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.phone, color: AppConfig.of(context).color.primary),
                    hintText: 'No. Telepon, cth: 081123123123',
                  ),
                ),
                SizedBox(height: 10),
                TextFormField(
                  validator: (t) {
                    if (t.isEmpty) return 'Email diperlukan.';
                    return null;
                  },
                  onSaved: (t) => setState(() => _registerForm.email = t),
                  keyboardType: TextInputType.emailAddress,
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.email, color: AppConfig.of(context).color.primary),
                    hintText: 'Email',
                  ),
                ),
                SizedBox(height: 10),
                TextFormField(
                  obscureText: _obscure,
                  controller: _controller,
                  validator: (t) {
                    if (t.isEmpty) return 'Kata sandi diperlukan.';
                    return null;
                  },
                  onSaved: (t) => setState(() => _registerForm.password = t),
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.lock, color: AppConfig.of(context).color.primary),
                    hintText: 'Kata Sandi',
                    suffixIcon: IconButton(
                      onPressed: () {
                        setState(() => _obscure = !_obscure);
                      },
                      icon: Icon(
                        Icons.remove_red_eye,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 10),
                TextFormField(
                  obscureText: _obscure2,
                  validator: (t) {
                    if (t.isEmpty) return 'Kata sandi diperlukan.';
                    if (_controller.text != t) return 'Kata sandi tidak sama';
                    return null;
                  },
                  onSaved: (t) => setState(() => _registerForm.passwordConfirmation = t),
                  decoration: InputDecoration(
                    prefixIcon: Icon(Icons.lock, color: AppConfig.of(context).color.primary),
                    hintText: 'Ulangi Kata Sandi',
                    suffixIcon: IconButton(
                      onPressed: () {
                        setState(() => _obscure2 = !_obscure2);
                      },
                      icon: Icon(
                        Icons.remove_red_eye,
                        color: Colors.grey,
                      ),
                    ),
                  ),
                ),
                SizedBox(height: 40),
                SizedBox(
                  height: 60,
                  width: double.infinity,
                  child: PrimaryButton(
                    text: 'DAFTAR',
                    fontSize: 25,
                    onPressed: _submit,
                    loading: _registerBloc.loading,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  _submit() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      _registerBloc.add(DoRegister(_registerForm));
    }
  }
}
