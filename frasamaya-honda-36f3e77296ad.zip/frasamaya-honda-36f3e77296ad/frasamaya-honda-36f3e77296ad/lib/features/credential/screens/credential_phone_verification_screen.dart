import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/config/app_config.dart';
import 'package:honda/core/blocs/authentication/authentication_bloc.dart';
import 'package:honda/core/blocs/authentication/authentication_event.dart';
import 'package:honda/features/credential/blocs/otp/bloc.dart';
import 'package:honda/features/credential/screens/change_number_screen.dart';
import 'package:honda/widgets/honda_button.dart';
import 'package:pin_code_fields/pin_code_fields.dart';

class CredentialPhoneVerificationScreen extends StatefulWidget {
  final String phoneNumber;

  const CredentialPhoneVerificationScreen({
    Key key,
    this.phoneNumber: '000000000000',
  }) : super(key: key);

  @override
  _CredentialPhoneVerificationScreenState createState() => _CredentialPhoneVerificationScreenState();
}

class _CredentialPhoneVerificationScreenState extends State<CredentialPhoneVerificationScreen> {
  OtpBloc _bloc;
  bool _loading;
  GlobalKey<ScaffoldState> _scaffoldKey;
  String _code;
  String _phone;

  @override
  void initState() {
    _bloc = OtpBloc();
    _loading = false;
    _scaffoldKey = GlobalKey<ScaffoldState>();
    _code = "";
    _phone = widget.phoneNumber;
    super.initState();
  }

  @override
  void dispose() {
    _bloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => _bloc,
      child: Scaffold(
        key: _scaffoldKey,
        body: BlocListener(
          bloc: _bloc,
          listener: (context, state) {
            print(state);
            if (state is LoadingOtpState) {
              setState(() => _loading = true);
            }

            if (state is FailedOtpState) {
              setState(() => _loading = false);
            }

            if (state is SuccessOtpState) {
              BlocProvider.of<AuthenticationBloc>(context).add(Authenticate());
            }
          },
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 10, vertical: 40),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                mainAxisAlignment: MainAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: <Widget>[
                  Image.asset(
                    'assets/icons/checked.png',
                    width: 100,
                    height: 100,
                    alignment: Alignment.center,
                  ),
                  Text(
                    'Verifikasi Nomor Anda',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'Masukan kode verifikasi yang kami kirimkan ke ${_phone}',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.normal,
                    ),
                  ),
                  SizedBox(height: 20),
                  Card(
                    child: Padding(
                      padding: EdgeInsets.symmetric(horizontal: 30, vertical: 20),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          PinCodeTextField(
                            length: 4,
                            inactiveColor: Colors.grey,
                            activeColor: AppConfig.of(context).color.primary,
                            selectedColor: AppConfig.of(context).color.accent,
                            onChanged: (String value) {
                              print(value);
                            },
                            onCompleted: (String code) {
                              setState(() => _code = code);
                              _bloc.add(VerifyNumber(_phone, code));
                            },
                          ),
                          SizedBox(height: 20),
                          SizedBox(
                            width: double.infinity,
                            height: 50,
                            child: PrimaryButton(
                              loading: _loading,
                              text: 'VERIFIKASI',
                              onPressed: () {
                                if (_code.length == 4) _bloc.add(VerifyNumber(_phone, _code));
                              },
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 20),
                  Text(
                    'Nomor yang anda masukan salah?',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.normal,
                    ),
                  ),
                  SizedBox(height: 20),
                  FlatButton(
                    textColor: AppConfig.of(context).color.primary,
                    child: Text(
                      'Ubah nomor',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    onPressed: () async {
                      final newPhone = await Navigator.push(context, MaterialPageRoute(builder: (context) => ChangeNumberScreen()));
                      if (newPhone is String && newPhone != '') setState(() => _phone = newPhone);
                    },
                  ),
                  FlatButton(
                    textColor: Colors.blue,
                    child: Text(
                      'Kirim ulang kode',
                      textAlign: TextAlign.center,
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    onPressed: () {
                      _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text('Mengirim kode OTP')));
                      _bloc.add(ResendOtp(_phone));
                    },
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
