import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:honda/config/app_config.dart';
import 'package:honda/features/credential/screens/credential_login_form.dart';
import 'package:honda/features/credential/screens/credential_register_form.dart';
import 'package:honda/features/credential/widgets/credential_tab_widget.dart';

class CredentialScreen extends StatefulWidget {
  @override
  _CredentialScreenState createState() => _CredentialScreenState();
}

class _CredentialScreenState extends State<CredentialScreen> {
  GlobalKey<ScaffoldState> _scaffoldKey;

  @override
  void initState() {
    _scaffoldKey = GlobalKey<ScaffoldState>();
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      body: Container(
        color: AppConfig.of(context).color.primary,
        padding: EdgeInsets.symmetric(horizontal: 15),
        constraints: BoxConstraints(
          minHeight: MediaQuery.of(context).size.height,
        ),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              SizedBox(height: 80),
              Image(image: AssetImage('assets/images/logo_with_text.png'), height: 80),
              SizedBox(height: 50),
              CredentialTabWidget(
                onChanged: (currentTab) {
                  print(currentTab);
                },
                loginForm: CredentialLoginForm(scaffoldKey: _scaffoldKey),
                registerForm: CredentialRegisterForm(scaffoldKey: _scaffoldKey),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
