import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/core/helpers/prefs.dart';
import 'package:honda/features/credential/blocs/change_phone/bloc.dart';
import 'package:honda/features/credential/models/change_password_form.dart';
import 'package:honda/widgets/honda_button.dart';

class ChangeNumberScreen extends StatefulWidget {
  @override
  _ChangeNumberScreenState createState() => _ChangeNumberScreenState();
}

class _ChangeNumberScreenState extends State<ChangeNumberScreen> {
  ChangeNumberForm _form;
  GlobalKey<ScaffoldState> _scaffoldKey;
  GlobalKey<FormState> _formKey;
  bool _loading;
  ChangePhoneBloc _bloc;

  @override
  void initState() {
    _form = ChangeNumberForm();
    _scaffoldKey = GlobalKey<ScaffoldState>();
    _formKey = GlobalKey<FormState>();
    _loading = false;
    _bloc = ChangePhoneBloc();
    super.initState();
  }

  @override
  void dispose() {
    _bloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text('Ganti Nomer'),
      ),
      body: BlocListener(
        bloc: _bloc,
        listener: (context, state) {
          if (state is LoadingChangePhoneState) setState(() => _loading = true);
          if (state is SuccessChangePhoneState) {
            setState(() => _loading = false);
            Navigator.pop(
              context,
              _form.phone,
            );
          }
        },
        child: Container(
          child: Form(
            key: _formKey,
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: <Widget>[
                  TextFormField(
                    decoration: InputDecoration(
                      prefixIcon: new IconButton(
                        icon: Image.asset('assets/icons/mail_active.png', width: 25.0, height: 25.0),
                        onPressed: null,
                      ),
                      hintText: 'No.Telepon, cth: 081123123123',
                    ),
                    keyboardType: TextInputType.number,
                    validator: (t) {
                      if (t.isEmpty) return 'No.Telepon diperlukan.';
                      return null;
                    },
                    onChanged: (t) => setState(() => _form.phone = t),
                  ),
                  SizedBox(height: 40),
                  SizedBox(
                    height: 60,
                    width: double.infinity,
                    child: PrimaryButton(
                      text: 'submit'.toUpperCase(),
                      fontSize: 25,
                      loading: _loading,
                      onPressed: () async {
                        if (_formKey.currentState.validate()) {
                          _formKey.currentState.save();
                          _form.id = await getRegisterId();
                          _bloc.add(ChangePhone(_form));
                        }
                      },
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
