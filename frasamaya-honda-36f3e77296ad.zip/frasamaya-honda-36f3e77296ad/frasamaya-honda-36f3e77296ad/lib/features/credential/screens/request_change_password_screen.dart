import 'package:flutter/material.dart';
import 'package:honda/features/credential/blocs/otp/bloc.dart';
import 'package:honda/features/credential/data/credential_api_service.dart';
import 'package:honda/features/credential/screens/phone_verification_screen.dart';
import 'package:honda/widgets/honda_button.dart';

class RequestChangePasswordScreen extends StatefulWidget {
  @override
  _RequestChangePasswordScreenState createState() => _RequestChangePasswordScreenState();
}

class _RequestChangePasswordScreenState extends State<RequestChangePasswordScreen> {
  String _phone = '';
  GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  OtpBloc _bloc = OtpBloc();
  CredentialApiService _service = CredentialApiService.create();

  @override
  void dispose() {
    _bloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ganti password'),
      ),
      body: Container(
        child: Form(
          key: _formKey,
          child: SingleChildScrollView(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: <Widget>[
                TextFormField(
                  decoration: InputDecoration(
                    prefixIcon: new IconButton(
                      icon: Image.asset('assets/icons/mail_active.png', width: 25.0, height: 25.0),
                      onPressed: null,
                    ),
                    hintText: 'No.Telepon, cth: 081123123123',
                  ),
                  keyboardType: TextInputType.number,
                  validator: (t) {
                    if (t.isEmpty) return 'No.Telepon diperlukan.';
                    return null;
                  },
                  onChanged: (t) => setState(() => _phone = t.substring(1, t.length)),
                ),
                SizedBox(height: 40),
                SizedBox(
                  height: 60,
                  width: double.infinity,
                  child: PrimaryButton(
                    text: 'submit'.toUpperCase(),
                    fontSize: 25,
                    onPressed: () async {
                      if (_formKey.currentState.validate()) {
                        await _service.forgotPassword({'phone': _phone});
                        Navigator.push(context, MaterialPageRoute(builder: (context) => PhoneVerificationScreen(phoneNumber: _phone)));
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
