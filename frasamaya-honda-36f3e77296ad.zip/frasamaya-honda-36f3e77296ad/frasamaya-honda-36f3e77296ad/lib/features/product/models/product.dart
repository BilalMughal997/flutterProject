class Product {
  String cylinder;
  List<Color> color;
  String description;
  String id;
  List<String> image;
  String name;
  String price;
  String type;

  Product({this.cylinder, this.color, this.description, this.id, this.image, this.name, this.price, this.type});

  factory Product.fromJson(Map<String, dynamic> json) {
    return Product(
      cylinder: json['cilinder'],
      color: json['color'] != null ? (json['color'] as List).map((i) => Color.fromJson(i)).toList() : null,
      description: json['description'],
      id: json['id_product'],
      image: json['image'] != null ? new List<String>.from(json['image']) : null,
      name: json['name'],
      price: json['price'],
      type: json['type'],
    );
  }
}

class Color {
  String hexa;
  String text;

  Color({this.hexa, this.text});

  factory Color.fromJson(Map<String, dynamic> json) {
    return Color(
      hexa: json['hexa'],
      text: json['text'],
    );
  }
}
