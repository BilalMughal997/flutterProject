import 'package:chopper/chopper.dart';
import 'package:honda/core/client_preset.dart';

part 'product_api_service.chopper.dart';

@ChopperApi(baseUrl: '/')
abstract class ProductApiService extends ChopperService {
  @Get(path: 'category')
  Future<Response> getCategories();

  @Get(path: 'product')
  Future<Response> getProducts({@Query('search') String search: ''});

  @Get(path: 'product/index/{id}')
  Future<Response> getProduct(@Path('id') int id);

  static ProductApiService create() {
    final client = ClientPreset.authClient(services: [_$ProductApiService()]);
    return _$ProductApiService(client);
  }
}
