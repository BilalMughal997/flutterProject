import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/product/contracts/product_repository_contract.dart';

import './bloc.dart';

class CategoryBloc extends Bloc<CategoryEvent, CategoryState> {
  ProductRepositoryContract _repository;

  CategoryBloc() {
    _repository = GetIt.I<ProductRepositoryContract>();
  }

  @override
  CategoryState get initialState => InitialCategoryState();

  @override
  Stream<CategoryState> mapEventToState(
    CategoryEvent event,
  ) async* {
    if (event is GetCategories) {
      yield LoadingCategoryState();

      try {
        final categories = await _repository.getCategories();
        yield LoadedCategoryState(categories);
      } catch (e) {
        yield FailedCategoryState(e.toString());
      }
    }
  }
}
