import 'package:equatable/equatable.dart';
import 'package:honda/features/product/models/category.dart';

abstract class CategoryState extends Equatable {
  const CategoryState();
}

class InitialCategoryState extends CategoryState {
  @override
  List<Object> get props => [];
}

class LoadingCategoryState extends CategoryState {
  @override
  List<Object> get props => [];
}

class LoadedCategoryState extends CategoryState {
  final List<Category> categories;

  LoadedCategoryState(this.categories);

  @override
  List<Object> get props => [categories];
}

class FailedCategoryState extends CategoryState {
  final String reason;

  FailedCategoryState(this.reason);

  @override
  List<Object> get props => [reason];
}
