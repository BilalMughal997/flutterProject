import 'package:equatable/equatable.dart';

abstract class ProductEvent extends Equatable {
  const ProductEvent();
}

class GetProducts extends ProductEvent {
  final String search;

  GetProducts({this.search: ''});

  @override
  List<Object> get props => [search];
}
