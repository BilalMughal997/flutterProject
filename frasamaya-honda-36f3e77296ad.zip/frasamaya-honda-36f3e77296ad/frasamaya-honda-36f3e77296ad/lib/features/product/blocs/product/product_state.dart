import 'package:equatable/equatable.dart';
import 'package:honda/features/product/models/product.dart';

abstract class ProductState extends Equatable {
  const ProductState();
}

class InitialProductState extends ProductState {
  @override
  List<Object> get props => [];
}

class LoadingProductState extends ProductState {
  @override
  List<Object> get props => [];
}

class LoadedProductState extends ProductState {
  final List<Product> products;

  LoadedProductState(this.products);

  @override
  List<Object> get props => [products];
}

class FailedProductState extends ProductState {
  final String reason;

  FailedProductState(this.reason);

  @override
  List<Object> get props => [reason];
}
