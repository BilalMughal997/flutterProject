import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/product/contracts/product_repository_contract.dart';

import './bloc.dart';

class ProductBloc extends Bloc<ProductEvent, ProductState> {
  ProductRepositoryContract _repository;

  ProductBloc() {
    _repository = GetIt.I<ProductRepositoryContract>();
  }

  @override
  ProductState get initialState => InitialProductState();

  @override
  Stream<ProductState> mapEventToState(
    ProductEvent event,
  ) async* {
    if (event is GetProducts) {
      yield LoadingProductState();

      try {
        final products = await _repository.getProducts(search: event.search);
        yield LoadedProductState(products);
      } catch (e) {
        yield FailedProductState(e.toString());
      }
    }
  }
}
