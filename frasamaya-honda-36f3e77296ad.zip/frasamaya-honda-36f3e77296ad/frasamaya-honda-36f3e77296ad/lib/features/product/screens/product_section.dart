import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/features/product/blocs/category/bloc.dart';
import 'package:honda/features/product/blocs/product/bloc.dart';
import 'package:honda/features/product/models/product.dart';
import 'package:honda/features/product/screens/product_detail_screen.dart';
import 'package:honda/features/product/widgets/category_container_widget.dart';
import 'package:honda/features/product/widgets/single_product_grid.dart';

class ProductSection extends StatefulWidget {
  final GlobalKey<ScaffoldState> scaffoldKey;

  const ProductSection({Key key, @required this.scaffoldKey}) : super(key: key);

  @override
  _ProductSectionState createState() => _ProductSectionState();
}

class _ProductSectionState extends State<ProductSection> {
  CategoryBloc _categoryBloc;
  ProductBloc _productBloc;
  List<CategoryItemModel> _categories;
  List<Product> _products;
  bool _loading;

  @override
  void initState() {
    _categoryBloc = CategoryBloc();
    _productBloc = ProductBloc();
    _categories = [];
    _products = [];
    _loading = false;
    super.initState();

    _categoryBloc.add(GetCategories());
    _productBloc.add(GetProducts());
  }

  @override
  void dispose() {
    _productBloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (context) => _categoryBloc),
        BlocProvider(create: (context) => _productBloc),
      ],
      child: MultiBlocListener(
        listeners: [
          BlocListener(
            bloc: _categoryBloc,
            listener: (context, state) {
              if (state is LoadedCategoryState) {
                setState(() {
                  _categories.add(CategoryItemModel(id: '', label: 'All', active: true));
                  final remoteCategory = state.categories.map<CategoryItemModel>((c) => CategoryItemModel(id: c.id, label: c.name)).toList();
                  _categories.addAll(remoteCategory);
                });
              }
            },
          ),
          BlocListener(
            bloc: _productBloc,
            listener: (context, state) {
              if (state is LoadedProductState) {
                setState(() {
                  _products = state.products;
                  _loading = false;
                });
              }

              if (state is LoadingProductState) setState(() => _loading = true);
              if (state is FailedProductState) {
                setState(() => _loading = false);
                setState(() => _products.clear());
                widget.scaffoldKey.currentState.showSnackBar(SnackBar(content: Text('Pencarian tidak ditemukan.')));
              }
            },
          ),
        ],
        child: Container(
          child: CustomScrollView(
            slivers: <Widget>[
              SliverAppBar(
                stretch: true,
                expandedHeight: 20,
                floating: true,
                pinned: true,
                title: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: <Widget>[
                          Text('Your Dream Cars.'),
                        ],
                      ),
                    ),
//                    Image(
//                      image: AssetImage('assets/icons/notification_inverted_active.png'),
//                    )
                  ],
                ),
              ),
              SliverPadding(
                padding: EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 20,
                ),
                sliver: _loading ? _buildLoading() : _buildList(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  _buildList() {
    return SliverGrid.count(
      crossAxisCount: 2,
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      children: _products
          .map<Widget>((e) => SingleProductGrid(
                name: e.name,
                image: NetworkImage(e.image.first),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => ProductDetailScreen(product: e)));
                },
              ))
          .toList(),
    );
  }

  _buildLoading() {
    return SliverFillRemaining(
      child: Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}
