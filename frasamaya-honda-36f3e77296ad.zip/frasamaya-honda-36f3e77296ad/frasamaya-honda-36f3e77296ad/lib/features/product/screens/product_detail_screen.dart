import 'package:flutter/material.dart';
import 'package:honda/features/product/models/product.dart';
import 'package:honda/features/product/widgets/product_color_info_widget.dart';
import 'package:honda/features/product/widgets/product_image_slider_widget.dart';
import 'package:honda/features/product/widgets/product_info_graphic.dart';
import 'package:honda/features/product/widgets/product_info_text_widget.dart';

class ProductDetailScreen extends StatefulWidget {
  final Product product;

  const ProductDetailScreen({
    Key key,
    @required this.product,
  }) : super(key: key);

  @override
  _ProductDetailScreenState createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  int _currentSliderPosition;

  @override
  void initState() {
    _currentSliderPosition = 0;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Detail'),
        actions: <Widget>[
          // IconButton(
          //   onPressed: () {},
          //   icon: Icon(Icons.share),
          // )
        ],
      ),
      body: Container(
        child: SingleChildScrollView(
          child: Column(
            children: <Widget>[
              ProductImageSliderWidget(images: widget.product.image, currentPosition: _currentSliderPosition),
              SizedBox(height: 20),
              Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    ProductInfoTextWidget(
                      name: widget.product.name,
                      description: widget.product.description,
                    ),
                    SizedBox(height: 30),
                    ProductInfoGraphic(
                      transmission: widget.product.type,
                      type: widget.product.cylinder,
                      price: widget.product.price,
                    ),
                    SizedBox(height: 30),
                    ProductColorInfoWidget(
                      colors: widget.product.color,
                      position: (pos) {
                        setState(() {
                          _currentSliderPosition = pos;
                        });
                      },
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
