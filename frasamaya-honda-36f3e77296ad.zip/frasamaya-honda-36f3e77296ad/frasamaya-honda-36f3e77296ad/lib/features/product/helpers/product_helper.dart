import 'package:honda/features/product/models/product.dart';

String carTypeText(String code) {
  String type = '';
  if (code == '0') type = 'S';
  if (code == '1') type = 'RS';
  if (code == '2') type = 'Prestige';
  return type;
}

String transmissionText(String code) {
  String transmission = '';
  if (code == '0') transmission = 'MT';
  if (code == '1') transmission = 'AT';
  if (code == '2') transmission = 'CVT';
  return transmission;
}

String productNameBuilder(Product product) {
  return "${product.name} ${carTypeText(product.type)} ${transmissionText('')}";
}
