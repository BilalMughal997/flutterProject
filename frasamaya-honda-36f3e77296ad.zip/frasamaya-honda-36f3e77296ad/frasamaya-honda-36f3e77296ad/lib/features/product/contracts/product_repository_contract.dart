import 'package:honda/features/product/models/category.dart';
import 'package:honda/features/product/models/product.dart';

abstract class ProductRepositoryContract {
  Future<List<Category>> getCategories();

  Future<List<Product>> getProducts({String search: ''});

  Future<Product> getProduct(String id);
}
