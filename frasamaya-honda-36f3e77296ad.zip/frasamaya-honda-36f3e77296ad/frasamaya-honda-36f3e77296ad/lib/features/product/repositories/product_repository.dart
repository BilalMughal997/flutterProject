import 'package:honda/features/product/contracts/product_repository_contract.dart';
import 'package:honda/features/product/data/product_api_service.dart';
import 'package:honda/features/product/models/category.dart';
import 'package:honda/features/product/models/product.dart';

class ProductRepository implements ProductRepositoryContract {
  ProductApiService _service;

  ProductRepository() {
    _service = ProductApiService.create();
  }

  @override
  Future<List<Category>> getCategories() async {
    final resp = await _service.getCategories();
    return resp.body['data'].map<Category>((json) => Category.fromJson(json)).toList();
  }

  @override
  Future<Product> getProduct(String id) async {
    final resp = await _service.getProduct(int.parse(id));
    return Product.fromJson(resp.body['data']);
  }

  @override
  Future<List<Product>> getProducts({String search: ''}) async {
    final resp = await _service.getProducts(search: search);
    return resp.body['data'].map<Product>((json) => Product.fromJson(json)).toList();
  }
}
