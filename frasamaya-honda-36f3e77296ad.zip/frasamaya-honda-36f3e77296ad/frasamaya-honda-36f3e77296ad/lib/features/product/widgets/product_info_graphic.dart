import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ProductInfoGraphic extends StatelessWidget {
  final String transmission;
  final String type;
  final String price;

  const ProductInfoGraphic({
    Key key,
    this.transmission,
    this.type,
    this.price,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 30),
        decoration: BoxDecoration(borderRadius: BorderRadius.circular(20), border: Border.all(color: Colors.grey)),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Image(
                    image: AssetImage('assets/icons/transmission_icon.png'),
                    width: 50,
                    height: 50,
                  ),
                  SizedBox(height: 20),
                  Text(
                    transmission,
                    textAlign: TextAlign.center,
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Image(
                    image: AssetImage('assets/icons/engine_icon.png'),
                    width: 50,
                    height: 50,
                  ),
                  SizedBox(height: 20),
                  Text(
                    '$type cc',
                    textAlign: TextAlign.center,
                    style: TextStyle(fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: <Widget>[
                  Image(
                    image: AssetImage('assets/icons/price_icon.png'),
                    width: 50,
                    height: 50,
                  ),
                  SizedBox(height: 20),
                  Text(
                    'Rp. ${int.parse(price) / 1000000} JT',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
