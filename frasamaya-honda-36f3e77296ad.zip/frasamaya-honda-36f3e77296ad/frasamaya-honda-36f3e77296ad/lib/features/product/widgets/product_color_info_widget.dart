import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:honda/config/app_config.dart';
import 'package:honda/features/product/models/product.dart' as ProductColor;
import 'package:supercharged/supercharged.dart';

class ProductColorInfoWidget extends StatefulWidget {
  final List<ProductColor.Color> colors;
  final ValueChanged<int> position;

  ProductColorInfoWidget({this.colors, this.position});

  @override
  _ProductColorInfoWidgetState createState() => _ProductColorInfoWidgetState();
}

class _ProductColorInfoWidgetState extends State<ProductColorInfoWidget> {
  ProductColor.Color _selectedColor;

  @override
  void initState() {
    _selectedColor = widget.colors.first;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(
            'Warna',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 10),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Row(
                  children: widget.colors
                      .map<Widget>(
                        (e) => InkWell(
                          onTap: () {
                            setState(() {
                              _selectedColor = e;
                              widget.position(widget.colors.indexOf(e));
                            });
                          },
                          child: Container(
                            width: 40,
                            height: 40,
                            margin: EdgeInsets.only(right: 5),
                            decoration: BoxDecoration(
                              border: Border.all(
                                color: _selectedColor.hexa == e.hexa ? AppConfig.of(context).color.primary : Colors.grey,
                                width: _selectedColor.hexa == e.hexa ? 3 : 1,
                              ),
                              shape: BoxShape.circle,
                              color: e.hexa.toColor(),
                            ),
                          ),
                        ),
                      )
                      .toList(),
                ),
              ],
            ),
          ),
          SizedBox(height: 20),
          Text(
            _selectedColor.text,
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 50),
        ],
      ),
    );
  }
}
