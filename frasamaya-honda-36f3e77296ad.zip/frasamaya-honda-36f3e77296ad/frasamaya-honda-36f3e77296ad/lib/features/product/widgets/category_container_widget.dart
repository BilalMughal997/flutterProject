import 'package:flutter/material.dart';
import 'package:honda/features/product/widgets/category_chip_widget.dart';

class CategoryContainerWidget extends StatefulWidget {
  final List<CategoryItemModel> categories;
  final ValueChanged<CategoryItemModel> onChanged;

  const CategoryContainerWidget({
    Key key,
    this.categories,
    this.onChanged,
  }) : super(key: key);

  @override
  _CategoryContainerWidgetState createState() => _CategoryContainerWidgetState();
}

class _CategoryContainerWidgetState extends State<CategoryContainerWidget> {
  List<CategoryItemModel> _categories;

  @override
  void initState() {
    _categories = widget.categories;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: BoxConstraints(minWidth: MediaQuery.of(context).size.width),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.start,
          children: _categories
              .map<Widget>(
                (c) => CategoryChipWidget(
                  id: c.id,
                  label: c.label,
                  active: c.active,
                  onTap: () {
                    widget.onChanged(c);
                    _setSelected(c);
                  },
                ),
              )
              .toList(),
        ),
      ),
    );
  }

  _setSelected(CategoryItemModel c) {
    setState(() {
      _categories.forEach((cat) {
        cat.active = false;
      });
      _categories.firstWhere((cat) => cat.id == c.id).active = true;
    });
  }
}

class CategoryItemModel {
  String id;
  String label;
  bool active;

  CategoryItemModel({this.id, this.label, this.active: false});
}
