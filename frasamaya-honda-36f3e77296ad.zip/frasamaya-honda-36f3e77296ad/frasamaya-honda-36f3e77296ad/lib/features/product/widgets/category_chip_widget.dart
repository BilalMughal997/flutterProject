import 'package:flutter/material.dart';
import 'package:honda/config/app_config.dart';

class CategoryChipWidget extends StatefulWidget {
  final String id;
  final String label;
  final VoidCallback onTap;
  final bool active;

  const CategoryChipWidget({Key key, this.label, this.onTap, this.active: false, this.id}) : super(key: key);

  @override
  _CategoryChipWidgetState createState() => _CategoryChipWidgetState();
}

class _CategoryChipWidgetState extends State<CategoryChipWidget> {
  bool _active;

  @override
  void initState() {
    _active = widget.active;
    super.initState();
  }

  @override
  void didUpdateWidget(CategoryChipWidget oldWidget) {
    setState(() => _active = widget.active);
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: widget.onTap,
      child: Container(
        margin: EdgeInsets.only(right: 5),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: _active ? AppConfig.of(context).color.primary : Colors.grey),
          color: _active ? AppConfig.of(context).color.primary : Colors.white,
        ),
        padding: EdgeInsets.symmetric(horizontal: 15, vertical: 5),
        child: Center(
          child: Text(
            widget.label,
            style: TextStyle(
              color: _active ? Colors.white : Colors.grey,
            ),
          ),
        ),
      ),
    );
  }
}
