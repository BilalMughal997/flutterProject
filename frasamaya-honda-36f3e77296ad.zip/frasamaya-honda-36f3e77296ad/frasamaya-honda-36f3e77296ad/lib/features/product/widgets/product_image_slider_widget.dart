import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';
import 'package:honda/features/home/widgets/home_section_banner_widget.dart';

class ProductImageSliderWidget extends StatefulWidget {
  final List<String> images;
  final int currentPosition;

  const ProductImageSliderWidget({
    Key key,
    @required this.images,
    this.currentPosition,
  }) : super(key: key);

  @override
  _ProductImageSliderWidgetState createState() => _ProductImageSliderWidgetState();
}

class _ProductImageSliderWidgetState extends State<ProductImageSliderWidget> {
  int _currentPosition;
  CarouselController _carouselController;

  @override
  void initState() {
    _currentPosition = 0;
    _carouselController = CarouselController();
    super.initState();
  }

  @override
  void didUpdateWidget(ProductImageSliderWidget oldWidget) {
    if (oldWidget.currentPosition != widget.currentPosition) {
      setState(() => _currentPosition = widget.currentPosition);
      _carouselController.animateToPage(widget.currentPosition, duration: Duration(milliseconds: 500));
    }
    super.didUpdateWidget(oldWidget);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          CarouselSlider(
            carouselController: _carouselController,
            options: CarouselOptions(
              aspectRatio: 9 / 3,
              autoPlay: false,
              pauseAutoPlayOnTouch: true,
              onPageChanged: (page, _) {
                setState(() => _currentPosition = page);
              },
            ),
            items: widget.images
                .map(
                  (e) => Builder(
                    builder: (context) => Container(
                      padding: EdgeInsets.symmetric(horizontal: 10),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image(
                          image: NetworkImage(e),
                          fit: BoxFit.fitHeight,
                        ),
                      ),
                    ),
                  ),
                )
                .toList(),
          ),
          SizedBox(
            child: BannerPositionIndicator(
              length: widget.images.length,
              currentPosition: _currentPosition,
              center: true,
            ),
          ),
        ],
      ),
    );
  }
}
