import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';

class ProductInfoTextWidget extends StatelessWidget {
  final String name;
  final String description;

  const ProductInfoTextWidget({Key key, this.name: 'Name', this.description: 'Description'}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Text(
            name,
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          SizedBox(height: 10),
          Text(
            description,
            style: TextStyle(color: Colors.grey[600], height: 1.5),
          ),
        ],
      ),
    );
  }
}
