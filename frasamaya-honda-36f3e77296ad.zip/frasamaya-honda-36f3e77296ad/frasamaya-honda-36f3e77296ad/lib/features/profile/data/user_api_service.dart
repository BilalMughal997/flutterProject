import 'package:chopper/chopper.dart';
import 'package:honda/core/client_preset.dart';
import 'package:http/http.dart' show MultipartFile;

part 'user_api_service.chopper.dart';

@ChopperApi(baseUrl: 'user')
abstract class UserApiService extends ChopperService {
  @Get(path: 'detail')
  Future<Response> profile();

  @Post(path: 'password')
  Future<Response> updatePassword(@Body() Map<String, dynamic> body);

  @Post(path: 'edit')
  @multipart
  Future<Response> updateProfile({
    @Part('name') String name,
    @Part('phone') String phone,
    @Part('email') String email,
    @Part('password') String password,
    @Part('repassword') String repassword,
    @PartFile('avatar') MultipartFile avatar,
  });

  static UserApiService create() {
    final client = ClientPreset.authClientMultipart(services: [_$UserApiService()]);
    return _$UserApiService(client);
  }
}
