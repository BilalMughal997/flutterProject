import 'package:equatable/equatable.dart';

abstract class EditProfileState extends Equatable {
  const EditProfileState();
}

class InitialEditProfileState extends EditProfileState {
  @override
  List<Object> get props => [];
}

class LoadingEditProfileState extends EditProfileState {
  @override
  List<Object> get props => [];
}

class SuccessEditProfileState extends EditProfileState {
  @override
  List<Object> get props => [];
}

class FailedEditProfileState extends EditProfileState {
  final String reason;

  FailedEditProfileState(this.reason);

  @override
  List<Object> get props => [reason];
}
