import 'package:equatable/equatable.dart';
import 'package:honda/features/profile/models/user_form.dart';

abstract class EditProfileEvent extends Equatable {
  const EditProfileEvent();
}

class UpdateProfile extends EditProfileEvent {
  final UserForm form;

  UpdateProfile(this.form);

  @override
  List<Object> get props => [form];
}
