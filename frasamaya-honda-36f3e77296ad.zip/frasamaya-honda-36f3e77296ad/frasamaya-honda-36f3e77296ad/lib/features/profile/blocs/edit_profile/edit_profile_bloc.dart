import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/profile/contracts/user_repository_contract.dart';

import './bloc.dart';

class EditProfileBloc extends Bloc<EditProfileEvent, EditProfileState> {
  UserRepositoryContract _repository;

  EditProfileBloc() {
    _repository = GetIt.I<UserRepositoryContract>();
  }

  @override
  EditProfileState get initialState => InitialEditProfileState();

  @override
  Stream<EditProfileState> mapEventToState(
    EditProfileEvent event,
  ) async* {
    if (event is UpdateProfile) {
      yield LoadingEditProfileState();

      try {
        final res = await _repository.updateProfile(event.form);
        if (res)
          yield SuccessEditProfileState();
        else
          yield FailedEditProfileState('Gagal update data');
      } catch (e) {
        yield FailedEditProfileState(e.toString());
      }
    }
  }
}
