import 'dart:io';

class UserForm {
  File avatar;
  String email;
  String name;
  String password;
  String phone;
  String repassword;

  UserForm({this.avatar, this.email, this.name, this.password, this.phone, this.repassword});
}
