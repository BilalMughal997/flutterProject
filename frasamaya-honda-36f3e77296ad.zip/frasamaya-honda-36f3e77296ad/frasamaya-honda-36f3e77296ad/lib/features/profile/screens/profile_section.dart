import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/core/blocs/authentication/authentication_bloc.dart';
import 'package:honda/core/blocs/authentication/authentication_event.dart';
import 'package:honda/features/page/screens/page_screen.dart';
import 'package:honda/features/profile/widgets/big_user_profile_widget.dart';
import 'package:honda/features/service/screens/car_selector_screen.dart';
import 'package:honda/features/service/screens/service_history_screen.dart';
import 'package:honda/widgets/honda_button.dart';

class ProfileSection extends StatefulWidget {
  @override
  _ProfileSectionState createState() => _ProfileSectionState();
}

class _ProfileSectionState extends State<ProfileSection> {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            BigUserProfileWidget(),
            Container(
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      'User',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                    ),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text('Kendaraan Saya'),
                      trailing: Icon(Icons.arrow_forward_ios),
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => CarSelectorScreen(isEdit: true)));
                      },
                    ),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text('Riwayat Servis'),
                      trailing: Icon(Icons.arrow_forward_ios),
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => ServiceHistoryScreen()));
                      },
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Tentang',
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                    ),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text('Tentang Kami'),
                      trailing: Icon(Icons.arrow_forward_ios),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PageScreen(
                              type: PageType.TENTANG_KAMI,
                            ),
                          ),
                        );
                      },
                    ),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text('Fasilitas Kami'),
                      trailing: Icon(Icons.arrow_forward_ios),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PageScreen(
                              type: PageType.FASILITAS_KAMI,
                            ),
                          ),
                        );
                      },
                    ),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text('Alamat Kami'),
                      trailing: Icon(Icons.arrow_forward_ios),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PageScreen(
                              type: PageType.ALAMAT_KAMI,
                            ),
                          ),
                        );
                      },
                    ),
                    ListTile(
                      contentPadding: EdgeInsets.zero,
                      title: Text('Hubungi Kami'),
                      trailing: Icon(Icons.arrow_forward_ios),
                      onTap: () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => PageScreen(
                              type: PageType.HUBUNGI_KAMI,
                            ),
                          ),
                        );
                      },
                    ),
                    SizedBox(height: 20),
                    SizedBox(
                      width: double.infinity,
                      child: SecondaryButton(
                        text: 'Keluar',
                        onPressed: _logout,
                      ),
                    ),
                    SizedBox(height: 20),
                  ],
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  _logout() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: Text('Keluar dari aplikasi?'),
        actions: <Widget>[
          FlatButton(
            onPressed: () {
              Navigator.pop(context);
            },
            child: Text('Tidak'),
          ),
          FlatButton(
            onPressed: () {
              BlocProvider.of<AuthenticationBloc>(context).add(Logout());
              Navigator.popUntil(context, ModalRoute.withName("/"));
            },
            child: Text('Ya'),
          ),
        ],
      ),
    );
  }
}
