import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/config/app_config.dart';
import 'package:honda/core/blocs/authentication/authentication_bloc.dart';
import 'package:honda/core/blocs/authentication/authentication_event.dart';
import 'package:honda/core/helpers/media_process.dart';
import 'package:honda/core/models/user.dart';
import 'package:honda/features/profile/blocs/edit_profile/bloc.dart';
import 'package:honda/features/profile/models/user_form.dart';
import 'package:honda/widgets/honda_button.dart';

class EditProfileScreen extends StatefulWidget {
  @override
  _EditProfileScreenState createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  EditProfileBloc _bloc;
  GlobalKey<FormState> _formKey;
  GlobalKey<ScaffoldState> _scaffoldKey;
  ImageProvider _avatarPlaceholder;
  UserForm _form;
  bool _loading;
  User _user;

  @override
  void initState() {
    _bloc = EditProfileBloc();
    _formKey = GlobalKey<FormState>();
    _scaffoldKey = GlobalKey<ScaffoldState>();
    _user = BlocProvider.of<AuthenticationBloc>(context).user;
    _avatarPlaceholder = NetworkImage(_user.avatar ?? 'https://placehold.it/500');
    _form = UserForm();
    _loading = false;
    super.initState();
  }

  @override
  void dispose() {
    _bloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text('Edit Profil'),
      ),
      body: BlocProvider(
        create: (context) => _bloc,
        child: BlocListener(
          bloc: _bloc,
          listener: (context, state) async {
            if (state is LoadingEditProfileState) setState(() => _loading = true);
            if (state is SuccessEditProfileState) {
              setState(() => _loading = false);
              BlocProvider.of<AuthenticationBloc>(context).add(RefreshUser());
              await showDialog(
                context: context,
                barrierDismissible: false,
                builder: (context) => AlertDialog(
                  content: Text('Data anda berhasil diperbaharui.'),
                  actions: <Widget>[
                    FlatButton(
                      onPressed: () {
                        Navigator.pop(context);
                      },
                      child: Text('OK'),
                    ),
                  ],
                ),
              );

              Navigator.pop(context);
            }

            if (state is FailedEditProfileState) {
              setState(() => _loading = false);
              _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text(state.reason)));
            }
          },
          child: Container(
            width: MediaQuery.of(context).size.width,
            child: Form(
              key: _formKey,
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: <Widget>[
                    InkWell(
                      onTap: _selectFile,
                      child: Container(
                        width: 100,
                        height: 100,
                        padding: EdgeInsets.all(3),
                        decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white),
                        child: Stack(
                          children: [
                            ClipRRect(
                              borderRadius: BorderRadius.circular(100),
                              child: Image(
                                image: _avatarPlaceholder,
                                width: 100,
                                height: 100,
                              ),
                            ),
                            Align(
                              child: Icon(
                                Icons.camera_alt,
                                size: 40,
                                color: Colors.white,
                              ),
                              alignment: Alignment.center,
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 30,
                    ),
                    TextFormField(
                      initialValue: _user.name,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Masukan nama anda',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        prefixIcon: Icon(
                          Icons.account_circle,
                          size: 30,
                          color: AppConfig.of(context).color.primary,
                        ),
                      ),
                      onSaved: (t) => _form.name = t,
                      validator: (t) {
                        if (t.isEmpty) return 'Nama diperlukan';
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      initialValue: _user.phone,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Masukan no. telpon anda',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        prefixIcon: Icon(
                          Icons.phone,
                          size: 30,
                          color: AppConfig.of(context).color.primary,
                        ),
                      ),
                      onSaved: (t) => _form.phone = t,
                      validator: (t) {
                        if (t.isEmpty) return 'No. telpon diperlukan';
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      initialValue: _user.email,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Masukan email anda',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        prefixIcon: Icon(
                          Icons.email,
                          size: 30,
                          color: AppConfig.of(context).color.primary,
                        ),
                      ),
                      onSaved: (t) => _form.email = t,
                      validator: (t) {
                        if (t.isEmpty) return 'Email diperlukan';
                        return null;
                      },
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      obscureText: true,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Masukan password anda',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        prefixIcon: Icon(
                          Icons.lock,
                          size: 30,
                          color: AppConfig.of(context).color.primary,
                        ),
                      ),
                      onSaved: (t) => _form.password = t,
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      obscureText: true,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Ulangi password anda',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                        prefixIcon: Icon(
                          Icons.lock,
                          size: 30,
                          color: AppConfig.of(context).color.primary,
                        ),
                      ),
                      onSaved: (t) => _form.repassword = t,
                    ),
                    SizedBox(height: 30),
                    SizedBox(
                      height: 45,
                      width: double.infinity,
                      child: PrimaryButton(
                        loading: _loading,
                        text: 'Simpan',
                        onPressed: _submit,
                      ),
                    ),
                    SizedBox(height: 30),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  void _selectFile() async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            ListTile(
              leading: Container(
                decoration: BoxDecoration(
                  color: AppConfig.of(context).color.primary.withAlpha(100),
                  borderRadius: BorderRadius.circular(10),
                ),
                padding: EdgeInsets.all(5),
                child: Icon(
                  Icons.camera_alt,
                  color: Colors.white,
                ),
              ),
              title: Text('Kamera'),
              onTap: () async {
                final file = await pickImageFromCamera(withCropper: true);
                if (file != null) {
                  setState(() {
                    _avatarPlaceholder = FileImage(file);
                    _form.avatar = file;
                  });
                }
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Container(
                decoration: BoxDecoration(
                  color: AppConfig.of(context).color.primary.withAlpha(100),
                  borderRadius: BorderRadius.circular(10),
                ),
                padding: EdgeInsets.all(5),
                child: Icon(
                  Icons.image,
                  color: Colors.white,
                ),
              ),
              title: Text('Gallery'),
              onTap: () async {
                final file = await pickImageFromGallery(withCropper: true);
                if (file != null) {
                  setState(() {
                    _avatarPlaceholder = FileImage(file);
                    _form.avatar = file;
                  });
                }
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }

  void _submit() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      _bloc.add(UpdateProfile(_form));
    }
  }
}
