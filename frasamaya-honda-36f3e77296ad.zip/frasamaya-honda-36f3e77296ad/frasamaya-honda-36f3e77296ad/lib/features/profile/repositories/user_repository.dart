import 'dart:io';

import 'package:honda/features/profile/contracts/user_repository_contract.dart';
import 'package:honda/features/profile/data/user_api_service.dart';
import 'package:honda/features/profile/models/user_form.dart';
import 'package:http/http.dart' show MultipartFile;

class UserRepository implements UserRepositoryContract {
  UserApiService _service;

  UserRepository() {
    _service = UserApiService.create();
  }

  @override
  Future<bool> updateProfile(UserForm form) async {
    if (form.avatar is File) {
      final bytes = await form.avatar.readAsBytes();
      final file = MultipartFile.fromBytes('avatar', bytes, filename: form.avatar.path);
      final resp = await _service.updateProfile(
        name: form.name,
        phone: form.phone,
        email: form.email,
        password: form.password,
        repassword: form.repassword,
        avatar: file,
      );

      return resp.statusCode >= 200 && resp.statusCode < 300;
    }

    final resp = await _service.updateProfile(
      name: form.name,
      phone: form.phone,
      email: form.email,
      password: form.password,
      repassword: form.repassword,
    );
    return resp.statusCode >= 200 && resp.statusCode < 300;
  }
}
