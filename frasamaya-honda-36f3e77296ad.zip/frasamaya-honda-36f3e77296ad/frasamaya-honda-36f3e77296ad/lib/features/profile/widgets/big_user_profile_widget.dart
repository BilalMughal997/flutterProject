import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/config/app_config.dart';
import 'package:honda/core/blocs/authentication/authentication_bloc.dart';
import 'package:honda/features/profile/screens/edit_profile_screen.dart';
import 'package:honda/widgets/honda_button.dart';

class BigUserProfileWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      child: Stack(
        children: <Widget>[
          ClipPath(
            clipper: ProfileDecorator(),
            child: Container(
              width: double.infinity,
              height: 140,
              color: AppConfig.of(context).color.primary,
            ),
          ),
          Container(
            margin: EdgeInsets.only(top: 35),
            width: MediaQuery.of(context).size.width,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: <Widget>[
                Text(
                  'Profil Saya',
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 30),
                Container(
                  width: 100,
                  height: 100,
                  padding: EdgeInsets.all(3),
                  decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(100),
                    child: Image(
                      image: NetworkImage(BlocProvider.of<AuthenticationBloc>(context).user.avatar ?? 'https://placehold.it/500'),
                      width: 100,
                      height: 100,
                    ),
                  ),
                ),
                Text(
                  BlocProvider.of<AuthenticationBloc>(context).user.name,
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.black),
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 10),
                SizedBox(
                  height: 30,
                  child: SecondaryButton(
                    text: 'Edit Profil',
                    onPressed: () {
                      Navigator.push(context, MaterialPageRoute(builder: (context) => EditProfileScreen()));
                    },
                  ),
                ),
                SizedBox(height: 20),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ProfileDecorator extends CustomClipper<Path> {
  @override
  getClip(Size size) {
    final path = Path();
    path.lineTo(0.0, size.height - 70);
    path.quadraticBezierTo(0.0, size.height, size.width / 2, size.height);
    path.quadraticBezierTo(size.width, size.height, size.width, size.height - 70);
    path.lineTo(size.width, size.height - 70);
    path.lineTo(size.width, 0);
    return path;
  }

  @override
  bool shouldReclip(CustomClipper oldClipper) => true;
}
