import 'package:honda/features/profile/models/user_form.dart';

abstract class UserRepositoryContract {
  Future<bool> updateProfile(UserForm form);
}
