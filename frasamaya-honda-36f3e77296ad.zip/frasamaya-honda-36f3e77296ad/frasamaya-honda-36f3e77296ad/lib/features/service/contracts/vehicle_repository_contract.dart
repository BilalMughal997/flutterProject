import 'package:honda/features/service/models/vehicle.dart';

abstract class VehicleRepositoryContract {
  Future<List<Vehicle>> getVehicles();

  Future<bool> storeVehicle(VehicleForm form);

  Future<bool> updateVehicle(VehicleForm form);
}
