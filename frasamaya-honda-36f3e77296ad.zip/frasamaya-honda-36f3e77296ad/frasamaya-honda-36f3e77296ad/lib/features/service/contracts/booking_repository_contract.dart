import 'package:honda/features/service/models/booking.dart';
import 'package:honda/features/service/models/category_service.dart';

abstract class BookingRepositoryContract {
  Future<List<Booking>> getHistory();

  Future<List<CategoryService>> getCategoryService();

  Future<bool> createBooking(BookingForm form);

  Future<bool> cancelBooking(CancelBooking form);
}
