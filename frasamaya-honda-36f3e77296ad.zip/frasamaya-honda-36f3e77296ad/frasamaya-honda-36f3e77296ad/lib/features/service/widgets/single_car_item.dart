import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:honda/features/service/models/vehicle.dart';
import 'package:honda/widgets/honda_button.dart';

class SingleCarItem extends StatelessWidget {
  final Vehicle vehicle;
  final VoidCallback onTap;
  final VoidCallback onEdit;

  const SingleCarItem({
    Key key,
    this.onTap,
    this.onEdit,
    this.vehicle,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 15, horizontal: 10),
      margin: EdgeInsets.only(bottom: 10),
      constraints: BoxConstraints(
        maxWidth: MediaQuery.of(context).size.width,
      ),
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey[300]),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Row(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Image.asset(
                'assets/icons/product.png',
                height: 25,
              ),
              SizedBox(width: 10),
              Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    vehicle.longName,
                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  ),
                  Text(
                    vehicle.nopol,
                    style: TextStyle(
                      fontSize: 12,
                      color: Colors.grey,
                    ),
                  ),
                ],
              ),
              Spacer(),
              (onEdit != null)
                  ? PrimaryButton(
                      text: 'Edit',
                      onPressed: onEdit,
                    )
                  : PrimaryButton(
                      text: 'Pilih',
                      onPressed: onTap,
                    ),
            ],
          ),
        ],
      ),
    );
  }
}
