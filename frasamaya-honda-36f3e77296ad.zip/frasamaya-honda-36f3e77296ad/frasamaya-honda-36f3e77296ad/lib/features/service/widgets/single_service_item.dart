import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:honda/features/product/helpers/product_helper.dart';
import 'package:intl/intl.dart';

class SingleServiceItem extends StatefulWidget {
  final String id;
  final String name;
  final String policeNumber;
  final String status;
  final String type;
  final DateTime date;
  final String idKendaraan;
  final String transmission;
  final String vehicleType;
  final VoidCallback onTap;

  const SingleServiceItem({
    Key key,
    this.id,
    this.name: '-',
    this.policeNumber: '-',
    this.status,
    this.type,
    this.date,
    this.onTap,
    this.idKendaraan,
    this.transmission,
    this.vehicleType,
  }) : super(key: key);

  @override
  _SingleServiceItemState createState() => _SingleServiceItemState();
}

class _SingleServiceItemState extends State<SingleServiceItem> {
  @override
  Widget build(BuildContext context) {
    final DateFormat df = DateFormat('E, dd MMM yyyy');
    return InkWell(
      onTap: widget.onTap,
      child: Container(
        padding: EdgeInsets.symmetric(vertical: 15, horizontal: 10),
        margin: EdgeInsets.only(bottom: 10),
        constraints: BoxConstraints(
          maxWidth: MediaQuery.of(context).size.width,
        ),
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey),
          borderRadius: BorderRadius.circular(10),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Image.asset(
                  'assets/icons/product.png',
                  height: 25,
                ),
                SizedBox(width: 10),
                Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(
                      "${widget.name} ${carTypeText(widget.vehicleType)} ${transmissionText(widget.transmission)}",
                      style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                    ),
                    Text(
                      widget.policeNumber,
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
                Spacer(),
                _buildStatusText(),
              ],
            ),
            Divider(
              color: Colors.grey,
              thickness: 1,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Text(widget.type),
                Text(
                  df.format(widget.date),
                  style: TextStyle(color: Colors.grey),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatusText() {
    String status = widget.status;
    Map<String, dynamic> statusText;

    if (status == '0') statusText = {'text': 'MENUNGGU', 'color': Colors.orange};
    if (status == '1') statusText = {'text': 'PROSES', 'color': Colors.blue};
    if (status == '2') statusText = {'text': 'SELESAI', 'color': Colors.green};
    if (status == '3') statusText = {'text': 'BATAL', 'color': Colors.red};

    return Text(statusText['text'], style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: statusText['color'] ?? Colors.black));
  }
}
