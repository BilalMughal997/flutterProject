import 'dart:io';

import 'package:honda/features/service/contracts/vehicle_repository_contract.dart';
import 'package:honda/features/service/data/vehicle_api_service.dart';
import 'package:honda/features/service/models/vehicle.dart';
import 'package:http/http.dart' show MultipartFile;

class VehicleRepository implements VehicleRepositoryContract {
  VehicleApiService _service;

  VehicleRepository() {
    _service = VehicleApiService.create();
  }

  @override
  Future<List<Vehicle>> getVehicles() async {
    final resp = await _service.getVehicles();
    return resp.body['data'].map<Vehicle>((json) => Vehicle.fromJson(json)).toList();
  }

  @override
  Future<bool> storeVehicle(VehicleForm form) async {
    print('store');
    final bytes = await form.image.readAsBytes();
    final file = MultipartFile.fromBytes('image', bytes, filename: form.image.path);
    final resp = await _service.storeVehicle(
      model: form.model,
      noMesin: form.noMesin,
      noRangka: form.noRangka,
      nopol: form.nopol,
      transmition: form.transmision,
      type: form.type,
      year: form.year,
      image: file,
    );

    return resp.statusCode >= 200 && resp.statusCode < 300;
  }

  @override
  Future<bool> updateVehicle(VehicleForm form) async {
    if (form.image is File) {
      print('update with image');
      final bytes = await form.image.readAsBytes();
      final file = MultipartFile.fromBytes('image', bytes, filename: form.image.path);
      final resp = await _service.updateVehicle(
        id: form.id,
        model: form.model,
        noMesin: form.noMesin,
        noRangka: form.noRangka,
        nopol: form.nopol,
        transmition: form.transmision,
        type: form.type,
        year: form.year,
        image: file,
      );
      return resp.statusCode >= 200 && resp.statusCode < 300;
    }
    print('update only');
    final resp = await _service.updateVehicle(
      id: form.id,
      model: form.model,
      noMesin: form.noMesin,
      noRangka: form.noRangka,
      nopol: form.nopol,
      transmition: form.transmision,
      type: form.type,
      year: form.year,
    );

    return resp.statusCode >= 200 && resp.statusCode < 300;
  }
}
