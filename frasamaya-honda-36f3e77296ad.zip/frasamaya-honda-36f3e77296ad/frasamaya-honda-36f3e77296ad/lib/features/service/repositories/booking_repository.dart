import 'package:honda/features/service/contracts/booking_repository_contract.dart';
import 'package:honda/features/service/data/service_api_service.dart';
import 'package:honda/features/service/models/booking.dart';
import 'package:honda/features/service/models/category_service.dart';

class BookingRepository implements BookingRepositoryContract {
  ServiceApiService _service;

  BookingRepository() {
    _service = ServiceApiService.create();
  }

  @override
  Future<bool> createBooking(BookingForm form) async {
    final resp = await _service.createBooking(form.toJson());
    return resp.statusCode >= 200 && resp.statusCode < 300;
  }

  @override
  Future<List<CategoryService>> getCategoryService() async {
    final resp = await _service.getServiceCategory();
    return resp.body['data'].map<CategoryService>((json) => CategoryService.fromJson(json)).toList();
  }

  @override
  Future<List<Booking>> getHistory() async {
    final resp = await _service.getBookingHistory();
    return resp.body['data'].map<Booking>((json) => Booking.fromJson(json)).toList();
  }

  @override
  Future<bool> cancelBooking(CancelBooking form) async {
    final resp = await _service.cancelBooking(form.toJson());
    return resp.statusCode >= 200 || resp.statusCode < 300;
  }
}
