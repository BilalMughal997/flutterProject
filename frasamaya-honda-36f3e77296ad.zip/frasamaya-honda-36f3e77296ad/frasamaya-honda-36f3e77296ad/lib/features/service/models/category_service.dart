class CategoryService {
  String id;
  String name;

  CategoryService({this.id, this.name});

  factory CategoryService.fromJson(Map<String, dynamic> json) {
    return CategoryService(
      id: json['id_category_service'] ?? '-',
      name: json['name'] ?? '-',
    );
  }
}
