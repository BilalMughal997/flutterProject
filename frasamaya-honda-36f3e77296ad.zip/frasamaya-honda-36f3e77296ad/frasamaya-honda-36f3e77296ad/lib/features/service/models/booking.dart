import 'package:honda/features/service/models/category_service.dart';
import 'package:honda/features/service/models/vehicle.dart';

class Booking {
  String address;
  String createdAt;
  String date;
  String description;
  String id;
  String spedometer;
  String status;
  String time;
  String type;
  String user;
  Vehicle vehicle;
  CategoryService categoryService;
  String reason;

  Booking({
    this.address,
    this.createdAt,
    this.date,
    this.description,
    this.id,
    this.spedometer,
    this.status,
    this.time,
    this.type,
    this.user,
    this.vehicle,
    this.categoryService,
    this.reason,
  });

  factory Booking.fromJson(Map<String, dynamic> json) {
    return Booking(address: json['address'], createdAt: json['created_at'], date: json['date'], description: json['description'], id: json['id_booking'], spedometer: json['spedometer'], status: json['status'], time: json['time'], type: json['type'], user: json['user'], vehicle: json['kendaraan'] != null ? Vehicle.fromJson(json['kendaraan']) : null, categoryService: json['category'] != null ? CategoryService.fromJson(json['category']) : null, reason: json['reason']);
  }
}

class BookingForm {
  String address;
  String category;
  String date;
  String description;
  String spedometer;
  String time;
  String type;
  String idKendaraan;

  BookingForm({
    this.address,
    this.category,
    this.date,
    this.description,
    this.spedometer,
    this.time,
    this.type,
    this.idKendaraan,
  });

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['address'] = this.address;
    data['category'] = this.category;
    data['date'] = this.date;
    data['description'] = this.description;
    data['spedometer'] = this.spedometer;
    data['time'] = this.time;
    data['type'] = this.type;
    data['id_kendaraan'] = this.idKendaraan;
    return data;
  }
}

class CancelBooking {
  String id;
  String reason;

  CancelBooking({this.id, this.reason});

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['reason'] = this.reason;
    return data;
  }
}
