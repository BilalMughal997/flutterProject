import 'dart:io';

import 'package:honda/features/product/helpers/product_helper.dart';

class Vehicle {
  String id;
  String image;
  String model;
  String noMesin;
  String noRangka;
  String nopol;
  String transmition;
  String type;
  String user;
  String year;

  Vehicle({
    this.id,
    this.image,
    this.model,
    this.noMesin,
    this.noRangka,
    this.nopol,
    this.transmition,
    this.type,
    this.user,
    this.year,
  });

  String get longName => "${this.model} ${carTypeText(this.type)} ${transmissionText(this.transmition)}";

  factory Vehicle.fromJson(Map<String, dynamic> json) {
    return Vehicle(
      id: json['id_kendaraan'],
      image: json['image'],
      model: json['model'],
      noMesin: json['no_mesin'],
      noRangka: json['no_rangka'],
      nopol: json['nopol'],
      transmition: json['transmition'],
      type: json['type'],
      user: json['user'],
      year: json['year'],
    );
  }
}

class VehicleForm {
  String id;
  File image;
  String model;
  String noMesin;
  String noRangka;
  String nopol;
  int transmision;
  int type;
  int year;

  VehicleForm({
    this.id,
    this.image,
    this.model,
    this.noMesin,
    this.noRangka,
    this.nopol,
    this.transmision,
    this.type,
    this.year,
  });
}
