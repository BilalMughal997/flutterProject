import 'package:chopper/chopper.dart';
import 'package:honda/core/client_preset.dart';
import 'package:http/http.dart' show MultipartFile;

part 'vehicle_api_service.chopper.dart';

@ChopperApi(baseUrl: 'kendaraan')
abstract class VehicleApiService extends ChopperService {
  @Get(path: '/')
  Future<Response> getVehicles();

  @Post(path: '/')
  @multipart
  Future<Response> storeVehicle({
    @Part('nopol') String nopol,
    @Part('no_rangka') String noRangka,
    @Part('no_mesin') String noMesin,
    @Part('type') int type,
    @Part('model') String model,
    @Part('year') int year,
    @Part('transmition') int transmition,
    @PartFile('image') MultipartFile image,
  });

  @Post(path: 'edit')
  @multipart
  Future<Response> updateVehicle({
    @Part('id') String id,
    @Part('nopol') String nopol,
    @Part('no_rangka') String noRangka,
    @Part('no_mesin') String noMesin,
    @Part('type') int type,
    @Part('model') String model,
    @Part('year') int year,
    @Part('transmition') int transmition,
    @PartFile('image') MultipartFile image,
  });

  static VehicleApiService create() {
    final client = ClientPreset.authClientMultipart(services: [_$VehicleApiService()]);
    return _$VehicleApiService(client);
  }
}
