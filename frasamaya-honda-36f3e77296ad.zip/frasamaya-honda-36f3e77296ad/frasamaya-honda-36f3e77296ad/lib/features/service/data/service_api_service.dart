import 'package:chopper/chopper.dart';
import 'package:honda/core/client_preset.dart';

part 'service_api_service.chopper.dart';

@ChopperApi(baseUrl: '/')
abstract class ServiceApiService extends ChopperService {
  @Post(path: 'booking')
  Future<Response> createBooking(@Body() Map<String, dynamic> body);

  @Get(path: 'booking')
  Future<Response> getBookingHistory();

  @Get(path: 'category_service')
  Future<Response> getServiceCategory();

  @Post(path: 'booking/cancel')
  Future<Response> cancelBooking(@Body() Map<String, dynamic> body);

  static ServiceApiService create() {
    final client = ClientPreset.authClient(services: [_$ServiceApiService()]);
    return _$ServiceApiService(client);
  }
}
