import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/service/contracts/vehicle_repository_contract.dart';

import './bloc.dart';

class AddVehicleBloc extends Bloc<AddVehicleEvent, AddVehicleState> {
  VehicleRepositoryContract _repository;

  AddVehicleBloc() {
    _repository = GetIt.I<VehicleRepositoryContract>();
  }

  @override
  AddVehicleState get initialState => InitialAddVehicleState();

  @override
  Stream<AddVehicleState> mapEventToState(
    AddVehicleEvent event,
  ) async* {
    if (event is StoreVehicle) {
      yield LoadingAddVehicleState();
      try {
        final res = event.isUpdate ? await _repository.updateVehicle(event.form) : await _repository.storeVehicle(event.form);
        if (res)
          yield SuccessAddVehicleState();
        else
          yield FailedAddVehicleState('Gagal simpan kendaraan');
      } catch (e) {
        yield FailedAddVehicleState(e.toString());
      }
    }
  }
}
