import 'package:equatable/equatable.dart';
import 'package:honda/features/service/models/vehicle.dart';

abstract class AddVehicleEvent extends Equatable {
  const AddVehicleEvent();
}

class StoreVehicle extends AddVehicleEvent {
  final VehicleForm form;
  final isUpdate;

  StoreVehicle(this.form, {this.isUpdate: false});

  @override
  List<Object> get props => [form, isUpdate];
}
