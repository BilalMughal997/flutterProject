import 'package:equatable/equatable.dart';

abstract class AddVehicleState extends Equatable {
  const AddVehicleState();
}

class InitialAddVehicleState extends AddVehicleState {
  @override
  List<Object> get props => [];
}

class LoadingAddVehicleState extends AddVehicleState {
  @override
  List<Object> get props => [];
}

class SuccessAddVehicleState extends AddVehicleState {
  @override
  List<Object> get props => [];
}

class FailedAddVehicleState extends AddVehicleState {
  final String reason;

  FailedAddVehicleState(this.reason);

  @override
  List<Object> get props => [reason];
}
