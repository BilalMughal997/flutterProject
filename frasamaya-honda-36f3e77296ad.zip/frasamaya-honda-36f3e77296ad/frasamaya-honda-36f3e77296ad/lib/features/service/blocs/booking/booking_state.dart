import 'package:equatable/equatable.dart';
import 'package:honda/features/service/models/booking.dart';

abstract class BookingState extends Equatable {
  const BookingState();
}

class InitialBookingState extends BookingState {
  @override
  List<Object> get props => [];
}

class LoadingBookingState extends BookingState {
  @override
  List<Object> get props => [];
}

class LoadedBookingState extends BookingState {
  final List<Booking> items;

  LoadedBookingState(this.items);

  @override
  List<Object> get props => [items];
}

class FailedBookingState extends BookingState {
  final String reason;

  FailedBookingState(this.reason);

  @override
  List<Object> get props => [reason];
}
