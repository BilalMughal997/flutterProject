import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/service/contracts/booking_repository_contract.dart';

import './bloc.dart';

class BookingBloc extends Bloc<BookingEvent, BookingState> {
  BookingRepositoryContract _repository;

  BookingBloc() {
    _repository = GetIt.I<BookingRepositoryContract>();
  }

  @override
  BookingState get initialState => InitialBookingState();

  @override
  Stream<BookingState> mapEventToState(
    BookingEvent event,
  ) async* {
    if (event is GetBooking) {
      yield LoadingBookingState();

      try {
        final items = await _repository.getHistory();
        yield LoadedBookingState(items);
      } catch (e) {
        yield FailedBookingState(e.toString());
      }
    }
  }
}
