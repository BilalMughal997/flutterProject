import 'package:equatable/equatable.dart';

abstract class BookingEvent extends Equatable {
  const BookingEvent();
}

class GetBooking extends BookingEvent {
  @override
  List<Object> get props => [];
}
