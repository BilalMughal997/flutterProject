import 'package:equatable/equatable.dart';
import 'package:honda/features/service/models/booking.dart';

abstract class AddBookingEvent extends Equatable {
  const AddBookingEvent();
}

class StoreBooking extends AddBookingEvent {
  final BookingForm form;

  StoreBooking(this.form);

  @override
  List<Object> get props => [form];
}
