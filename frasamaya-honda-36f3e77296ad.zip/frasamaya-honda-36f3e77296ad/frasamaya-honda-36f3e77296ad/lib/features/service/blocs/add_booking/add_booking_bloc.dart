import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/service/contracts/booking_repository_contract.dart';

import './bloc.dart';

class AddBookingBloc extends Bloc<AddBookingEvent, AddBookingState> {
  BookingRepositoryContract _repository;

  AddBookingBloc() {
    _repository = GetIt.I<BookingRepositoryContract>();
  }

  @override
  AddBookingState get initialState => InitialAddBookingState();

  @override
  Stream<AddBookingState> mapEventToState(
    AddBookingEvent event,
  ) async* {
    if (event is StoreBooking) {
      yield LoadingAddBookingState();

      try {
        final res = await _repository.createBooking(event.form);
        if (res)
          yield SuccessAddBookingState();
        else
          yield FailedAddBookingState('Gagal membuat booking');
      } catch (e) {
        yield FailedAddBookingState(e.toString());
      }
    }
  }
}
