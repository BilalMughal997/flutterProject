import 'package:equatable/equatable.dart';

abstract class AddBookingState extends Equatable {
  const AddBookingState();
}

class InitialAddBookingState extends AddBookingState {
  @override
  List<Object> get props => [];
}

class LoadingAddBookingState extends AddBookingState {
  @override
  List<Object> get props => [];
}

class SuccessAddBookingState extends AddBookingState {
  @override
  List<Object> get props => [];
}

class FailedAddBookingState extends AddBookingState {
  final String reason;

  FailedAddBookingState(this.reason);

  @override
  List<Object> get props => [reason];
}
