import 'package:equatable/equatable.dart';

abstract class CancelBookingState extends Equatable {
  const CancelBookingState();
}

class InitialCancelBookingState extends CancelBookingState {
  @override
  List<Object> get props => [];
}

class LoadingCancelBookingState extends CancelBookingState {
  @override
  List<Object> get props => [];
}

class SuccessCancelBookingState extends CancelBookingState {
  @override
  List<Object> get props => [];
}

class FailedCancelBookingState extends CancelBookingState {
  final String reason;

  FailedCancelBookingState(this.reason);

  @override
  List<Object> get props => [];
}
