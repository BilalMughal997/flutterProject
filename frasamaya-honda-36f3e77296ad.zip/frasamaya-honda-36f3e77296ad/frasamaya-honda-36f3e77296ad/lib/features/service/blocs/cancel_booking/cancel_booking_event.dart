import 'package:equatable/equatable.dart';
import 'package:honda/features/service/models/booking.dart';

abstract class CancelBookingEvent extends Equatable {
  const CancelBookingEvent();
}

class Cancel extends CancelBookingEvent {
  final CancelBooking form;

  Cancel(this.form);
  @override
  List<Object> get props => [];
}
