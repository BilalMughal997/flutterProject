import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/service/contracts/booking_repository_contract.dart';

import './bloc.dart';

class CancelBookingBloc extends Bloc<CancelBookingEvent, CancelBookingState> {
  BookingRepositoryContract _repository;

  CancelBookingBloc() {
    _repository = GetIt.I<BookingRepositoryContract>();
  }

  @override
  CancelBookingState get initialState => InitialCancelBookingState();

  @override
  Stream<CancelBookingState> mapEventToState(
    CancelBookingEvent event,
  ) async* {
    if (event is Cancel) {
      yield LoadingCancelBookingState();

      try {
        final res = await _repository.cancelBooking(event.form);
        if (res)
          yield SuccessCancelBookingState();
        else
          yield FailedCancelBookingState('Gagal cancel booking.');
      } catch (e) {
        yield FailedCancelBookingState(e.toString());
      }
    }
  }
}
