import 'package:equatable/equatable.dart';
import 'package:honda/features/service/models/vehicle.dart';

abstract class VehicleState extends Equatable {
  const VehicleState();
}

class InitialVehicleState extends VehicleState {
  @override
  List<Object> get props => [];
}

class LoadingVehicleState extends VehicleState {
  @override
  List<Object> get props => [];
}

class LoadedVehicleState extends VehicleState {
  final List<Vehicle> items;

  LoadedVehicleState(this.items);

  @override
  List<Object> get props => [items];
}

class FailedVehicleState extends VehicleState {
  final String reason;

  FailedVehicleState(this.reason);

  @override
  List<Object> get props => [reason];
}
