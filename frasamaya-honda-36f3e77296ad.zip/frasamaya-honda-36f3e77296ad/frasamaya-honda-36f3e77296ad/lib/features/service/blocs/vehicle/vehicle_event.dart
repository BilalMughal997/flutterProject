import 'package:equatable/equatable.dart';

abstract class VehicleEvent extends Equatable {
  const VehicleEvent();
}

class GetVehicle extends VehicleEvent {
  @override
  List<Object> get props => [];
}
