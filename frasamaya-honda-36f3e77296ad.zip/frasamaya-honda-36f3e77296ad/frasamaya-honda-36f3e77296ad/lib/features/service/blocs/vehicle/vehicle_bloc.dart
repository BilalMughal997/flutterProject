import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/service/contracts/vehicle_repository_contract.dart';

import './bloc.dart';

class VehicleBloc extends Bloc<VehicleEvent, VehicleState> {
  VehicleRepositoryContract _repository;

  VehicleBloc() {
    _repository = GetIt.I<VehicleRepositoryContract>();
  }

  @override
  VehicleState get initialState => InitialVehicleState();

  @override
  Stream<VehicleState> mapEventToState(
    VehicleEvent event,
  ) async* {
    if (event is GetVehicle) {
      yield LoadingVehicleState();

      try {
        final items = await _repository.getVehicles();
        yield LoadedVehicleState(items);
      } catch (e) {
        yield FailedVehicleState(e.toString());
      }
    }
  }
}
