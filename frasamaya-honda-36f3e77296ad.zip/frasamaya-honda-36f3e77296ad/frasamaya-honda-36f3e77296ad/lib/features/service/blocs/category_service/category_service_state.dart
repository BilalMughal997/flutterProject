import 'package:equatable/equatable.dart';
import 'package:honda/features/service/models/category_service.dart';

abstract class CategoryServiceState extends Equatable {
  const CategoryServiceState();
}

class InitialCategoryServiceState extends CategoryServiceState {
  @override
  List<Object> get props => [];
}

class LoadingCategoryServiceState extends CategoryServiceState {
  @override
  List<Object> get props => [];
}

class LoadedCategoryServiceState extends CategoryServiceState {
  final List<CategoryService> items;

  LoadedCategoryServiceState(this.items);

  @override
  List<Object> get props => [items];
}

class FailedCategoryServiceState extends CategoryServiceState {
  final String reason;

  FailedCategoryServiceState(this.reason);

  @override
  List<Object> get props => [reason];
}
