import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/service/contracts/booking_repository_contract.dart';

import './bloc.dart';

class CategoryServiceBloc extends Bloc<CategoryServiceEvent, CategoryServiceState> {
  BookingRepositoryContract _repository;

  CategoryServiceBloc() {
    _repository = GetIt.I<BookingRepositoryContract>();
  }

  @override
  CategoryServiceState get initialState => InitialCategoryServiceState();

  @override
  Stream<CategoryServiceState> mapEventToState(
    CategoryServiceEvent event,
  ) async* {
    if (event is GetCategoryService) {
      yield LoadingCategoryServiceState();

      try {
        final items = await _repository.getCategoryService();
        yield LoadedCategoryServiceState(items);
      } catch (e) {
        yield FailedCategoryServiceState(e.toString());
      }
    }
  }
}
