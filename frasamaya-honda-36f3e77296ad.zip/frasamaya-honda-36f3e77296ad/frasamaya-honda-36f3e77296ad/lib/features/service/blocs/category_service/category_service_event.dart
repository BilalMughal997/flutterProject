import 'package:equatable/equatable.dart';

abstract class CategoryServiceEvent extends Equatable {
  const CategoryServiceEvent();
}

class GetCategoryService extends CategoryServiceEvent {
  @override
  List<Object> get props => [];
}
