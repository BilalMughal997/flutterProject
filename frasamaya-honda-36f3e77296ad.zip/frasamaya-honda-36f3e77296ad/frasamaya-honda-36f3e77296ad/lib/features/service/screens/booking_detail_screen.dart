import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/features/service/blocs/cancel_booking/bloc.dart';
import 'package:honda/features/service/models/booking.dart';
import 'package:honda/widgets/honda_button.dart';
import 'package:intl/intl.dart';

class BookingDetailScreen extends StatefulWidget {
  final Booking booking;

  const BookingDetailScreen({Key key, @required this.booking}) : super(key: key);

  @override
  _BookingDetailScreenState createState() => _BookingDetailScreenState();
}

class _BookingDetailScreenState extends State<BookingDetailScreen> {
  CancelBookingBloc _bloc;
  bool _loadingCancel;
  TextEditingController _reasonController;
  GlobalKey<ScaffoldState> _scaffoldKey;

  @override
  void initState() {
    _bloc = CancelBookingBloc();
    _loadingCancel = false;
    _reasonController = TextEditingController(text: '');
    _scaffoldKey = GlobalKey<ScaffoldState>();
    super.initState();
  }

  @override
  void dispose() {
    _bloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final bookingDateFormat = DateFormat('yyyy-MM-dd HH:mm:ss');
    final bookingDate = bookingDateFormat.parse(widget.booking.createdAt);
    DateFormat df = DateFormat('E, dd MMM yyyy');
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text('Detail'),
      ),
      body: BlocProvider(
        create: (context) => _bloc,
        child: BlocListener(
          bloc: _bloc,
          listener: (context, state) {
            if (state is LoadingCancelBookingState) setState(() => _loadingCancel = true);
            if (state is SuccessCancelBookingState) {
              Navigator.pop(context, true);
            }

            if (state is FailedCancelBookingState) {
              setState(() => _loadingCancel = false);
              _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text('Gagal submit pembatalan.')));
              Navigator.pop(context, false);
            }
          },
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Expanded(
                  child: SingleChildScrollView(
                    child: Container(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: <Widget>[
                          SizedBox(height: 20),
                          Row(
                            mainAxisSize: MainAxisSize.min,
                            children: <Widget>[
                              Image.asset(
                                'assets/icons/product.png',
                                height: 25,
                              ),
                              SizedBox(width: 10),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: <Widget>[
                                  Text(
                                    widget.booking.vehicle?.longName ?? '-',
                                    style: TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                                  ),
                                  Text(
                                    widget.booking.vehicle?.nopol ?? '-',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: Colors.grey,
                                    ),
                                  ),
                                ],
                              ),
                              Spacer(),
                              _buildStatusText(),
                            ],
                          ),
                          SizedBox(height: 40),
                          Text(
                            'Rincian',
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                          SizedBox(height: 20),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: _textItem('tanggal servis', df.format(bookingDate)),
                              ),
                              Expanded(
                                child: _textItem('jam servis', widget.booking.time),
                              ),
                            ],
                          ),
                          SizedBox(height: 20),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: _textItem('jarak tempuh', widget.booking.spedometer),
                              ),
                              Expanded(
                                child: _textItem('kategori servis', widget.booking.categoryService?.name ?? '-'),
                              ),
                            ],
                          ),
                          SizedBox(height: 20),
                          Visibility(
                            visible: widget.booking.type == '0',
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: <Widget>[
                                Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: _textItem('alamat pickup', widget.booking.address),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 20),
                              ],
                            ),
                          ),
                          Row(
                            children: <Widget>[
                              Expanded(
                                child: _textItem('keterangan', widget.booking.description),
                              ),
                            ],
                          ),
                          SizedBox(height: 20),
                          Visibility(
                            visible: widget.booking.status == '3',
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisSize: MainAxisSize.min,
                              children: <Widget>[
                                Row(
                                  children: <Widget>[
                                    Expanded(
                                      child: _textItem('alasan', widget.booking.reason),
                                    ),
                                  ],
                                ),
                                SizedBox(height: 20),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                Visibility(
                  visible: widget.booking.status == '0',
                  child: Container(
                    margin: EdgeInsets.only(bottom: 20),
                    width: double.infinity,
                    height: 45,
                    child: SecondaryButton(
                      text: 'batalkan'.toUpperCase(),
                      onPressed: _loadingCancel ? null : _cancelBooking,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _textItem(String label, String value) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(
          label.toUpperCase(),
          style: TextStyle(fontSize: 14, color: Colors.black45),
        ),
        SizedBox(height: 3),
        Text(
          value ?? '-',
          style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold),
        ),
      ],
    );
  }

  Widget _buildStatusText() {
    String status = widget.booking.status;
    Map<String, dynamic> statusText;

    if (status == '0') statusText = {'text': 'MENUNGGU', 'color': Colors.orange};
    if (status == '1') statusText = {'text': 'PROSES', 'color': Colors.blue};
    if (status == '2') statusText = {'text': 'SELESAI', 'color': Colors.green};
    if (status == '3') statusText = {'text': 'BATAL', 'color': Colors.red};

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      child: Center(
        child: Text(
          statusText['text'],
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      decoration: BoxDecoration(
        color: statusText['color'],
        borderRadius: BorderRadius.circular(15),
      ),
    );
  }

  _cancelBooking() async {
    await showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text('Konfirmasi'),
        content: Container(
          child: _loadingCancel ? _loadingCancelForm() : _cancelForm(),
        ),
        actions: <Widget>[
          FlatButton(
            onPressed: _loadingCancel
                ? null
                : () {
                    Navigator.pop(context);
                  },
            child: Text('Urungkan'),
          ),
          FlatButton(
            onPressed: _loadingCancel
                ? null
                : () {
                    final cancel = CancelBooking(id: widget.booking.id, reason: _reasonController.text);
                    _bloc.add(Cancel(cancel));
                  },
            child: Text('Kirim'),
          ),
        ],
      ),
      barrierDismissible: false,
    );
  }

  _cancelForm() {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: <Widget>[
        Text('Beritahu kami mengapa anda membatalkan layanan kami?'),
        TextField(
          controller: _reasonController,
          decoration: InputDecoration(
            hintText: 'Tulis alasan',
            border: UnderlineInputBorder(),
            enabledBorder: UnderlineInputBorder(),
            focusedBorder: UnderlineInputBorder(),
          ),
          maxLines: 3,
        ),
      ],
    );
  }

  _loadingCancelForm() {
    return Center(
      child: CircularProgressIndicator(),
    );
  }
}
