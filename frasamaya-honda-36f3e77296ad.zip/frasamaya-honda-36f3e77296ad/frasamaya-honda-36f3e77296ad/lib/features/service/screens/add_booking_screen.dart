import 'package:datetime_picker_formfield/datetime_picker_formfield.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/features/service/blocs/add_booking/add_booking_bloc.dart';
import 'package:honda/features/service/blocs/add_booking/add_booking_event.dart';
import 'package:honda/features/service/blocs/add_booking/add_booking_state.dart';
import 'package:honda/features/service/blocs/category_service/bloc.dart';
import 'package:honda/features/service/models/booking.dart';
import 'package:honda/features/service/models/category_service.dart';
import 'package:honda/features/service/screens/car_selector_screen.dart';
import 'package:honda/screens/main_screen.dart';
import 'package:honda/widgets/honda_button.dart';
import 'package:honda/widgets/honda_navigation_widget.dart';
import 'package:intl/intl.dart';

class AddBookingScreen extends StatefulWidget {
  final ServiceType type;
  final String idKendaraan;

  const AddBookingScreen({Key key, this.type, @required this.idKendaraan}) : super(key: key);

  @override
  _AddBookingScreenState createState() => _AddBookingScreenState();
}

class _AddBookingScreenState extends State<AddBookingScreen> {
  AddBookingBloc _addBookingBloc;
  CategoryServiceBloc _categoryServiceBloc;
  GlobalKey<FormState> _formKey;
  GlobalKey<ScaffoldState> _scaffoldKey;
  BookingForm _form;
  List<CategoryService> _categories;
  bool _loading;

  @override
  void initState() {
    _addBookingBloc = AddBookingBloc();
    _categoryServiceBloc = CategoryServiceBloc();
    _formKey = GlobalKey<FormState>();
    _scaffoldKey = GlobalKey<ScaffoldState>();
    _form = BookingForm();
    _categories = [];
    _loading = false;
    super.initState();

    _categoryServiceBloc.add(GetCategoryService());
  }

  @override
  void dispose() {
    _addBookingBloc.close();
    _categoryServiceBloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    DateFormat df = DateFormat('dd/MM/yyyy');
    DateFormat dfSave = DateFormat('yyyy-MM-dd');
    DateFormat tf = DateFormat('HH:mm');
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text((widget.type == ServiceType.BOOKING) ? "Booking servis" : "Pickup servis"),
      ),
      body: MultiBlocProvider(
        providers: [
          BlocProvider(create: (context) => _categoryServiceBloc),
          BlocProvider(create: (context) => _addBookingBloc),
        ],
        child: MultiBlocListener(
          listeners: [
            BlocListener(
              bloc: _categoryServiceBloc,
              listener: (context, state) {
                if (state is LoadedCategoryServiceState) setState(() => _categories = state.items);
              },
            ),
            BlocListener(
              bloc: _addBookingBloc,
              listener: (context, state) async {
                if (state is LoadingAddBookingState) setState(() => _loading = true);
                if (state is SuccessAddBookingState) {
                  setState(() => _loading = false);
                  await showDialog(
                    context: context,
                    barrierDismissible: false,
                    builder: (context) => AlertDialog(
                      content: Text('Pesanan berhasil dilakukan. Anda akan dihubungi admin untuk konfirmasi waktu service'),
                      actions: <Widget>[
                        FlatButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          child: Text('OK'),
                        ),
                      ],
                    ),
                  );

                  Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => MainScreen(menu: HondaMenu.SERVICE)));
                }

                if (state is FailedAddBookingState) {
                  setState(() => _loading = false);
                  _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text(state.reason)));
                }
              },
            ),
          ],
          child: Container(
            child: Form(
              key: _formKey,
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    SizedBox(height: 30),
                    Text(
                      'Tanggal Servis',
                      style: TextStyle(fontSize: 18),
                    ),
                    SizedBox(height: 10),
                    DateTimeField(
                      format: df,
                      onShowPicker: (context, currentValue) async {
                        return await showDatePicker(
                          context: context,
                          initialDate: DateTime.now(),
                          firstDate: currentValue ?? DateTime.now(),
                          lastDate: DateTime.now().add(Duration(days: 366)),
                        );
                      },
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Pilih tanggal servis',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                      ),
                      onSaved: (t) => _form.date = dfSave.format(t),
                      validator: (t) {
                        if (t == null) return 'Silahkan pilih tanggal servis';
                        return null;
                      },
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Jam Servis',
                      style: TextStyle(fontSize: 18),
                    ),
                    SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                      isDense: true,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Pilih jam servis',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                      ),
                      onSaved: (t) => _form.time = t,
                      validator: (t) {
                        if (t == null) return 'Silahkan pilih jam servis';
                        return null;
                      },
                      onChanged: (v) {
                        print(v);
                      },
                      items: _buildTimeSet().map<DropdownMenuItem<String>>((e) {
                        final now = DateTime.now();
                        final dt = DateTime(now.year, now.month, now.day, e.hour, e.minute);
                        return DropdownMenuItem<String>(
                          value: tf.format(dt),
                          child: Text(tf.format(dt)),
                        );
                      }).toList(),
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Jarak Tempuh Kendaraan (Km)',
                      style: TextStyle(fontSize: 18),
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Masukan jarak tempuh kendaraan dalam Km',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                      ),
                      keyboardType: TextInputType.number,
                      onSaved: (t) => _form.spedometer = t,
                      validator: (t) {
                        if (t.isEmpty) return 'Jarak tempuh diperlukan';
                        return null;
                      },
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Kategori Servis',
                      style: TextStyle(fontSize: 18),
                    ),
                    SizedBox(height: 10),
                    DropdownButtonFormField<String>(
                      isDense: true,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Masukan kategori servis',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                      ),
                      onSaved: (t) => _form.category = t,
                      validator: (t) {
                        if (t == null) return 'Silahkan pilih kategori servis';
                        return null;
                      },
                      onChanged: (v) {
                        print(v);
                      },
                      items: _buildCategory(),
                    ),
                    SizedBox(height: 20),
                    (widget.type == ServiceType.PICKUP) ? Text(
                      'Alamat',
                      style: TextStyle(fontSize: 18),
                    ): Container(),
                    (widget.type == ServiceType.PICKUP) ? SizedBox(height: 10): Container(),
                    (widget.type == ServiceType.PICKUP) ? TextFormField(
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Masukan Alamat',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                      ),
                      maxLines: 3,
                      onSaved: (t) => _form.address = t,
                    ): Container(),
                    (widget.type == ServiceType.PICKUP) ? SizedBox(height:20): Container(),
                    Text(
                      'Keterangan',
                      style: TextStyle(fontSize: 18),
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Masukan Keterangan',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                      ),
                      maxLines: 3,
                      onSaved: (t) => _form.description = t,
                    ),
                    SizedBox(height: 30),
                    SizedBox(
                      height: 45,
                      child: PrimaryButton(
                        text: 'SUBMIT',
                        loading: _loading,
                        onPressed: _submit,
                      ),
                    ),
                    SizedBox(height: 30),
                    Text('Waktu service kendaraan anda akan dilakukan h+1 dari waktu booking yang anda pilih', textAlign: TextAlign.center),
                    SizedBox(height: 30),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  List<DropdownMenuItem<String>> _buildCategory() {
    return _categories
        .map<DropdownMenuItem<String>>(
          (e) => DropdownMenuItem<String>(
            value: e.id,
            child: Text(e.name),
          ),
        )
        .toList();
  }

  List<TimeOfDay> _buildTimeSet() {
    final startTime = TimeOfDay(hour: 8, minute: 0);
    final endTime = TimeOfDay(hour: 17, minute: 15);
    List<TimeOfDay> times = [];

    var hour = startTime.hour;
    var minute = startTime.minute;
    final step = Duration(minutes: 15);

    do {
      times.add(TimeOfDay(hour: hour, minute: minute));
      minute += step.inMinutes;
      while (minute >= 60) {
        minute -= 60;
        hour++;
      }
    } while (hour < endTime.hour || hour == endTime.hour && minute < endTime.minute);

    return times;
  }

  void _submit() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      _form.type = widget.type == ServiceType.BOOKING ? "1" : "0";
      _form.idKendaraan = widget.idKendaraan;
      _addBookingBloc.add(StoreBooking(_form));
    }
  }
}
