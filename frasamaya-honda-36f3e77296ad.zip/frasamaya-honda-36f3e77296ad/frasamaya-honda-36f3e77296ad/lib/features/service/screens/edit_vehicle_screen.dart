import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/config/app_config.dart';
import 'package:honda/core/helpers/media_process.dart';
import 'package:honda/features/service/blocs/add_vehicle/add_vehicle_bloc.dart';
import 'package:honda/features/service/blocs/add_vehicle/add_vehicle_event.dart';
import 'package:honda/features/service/blocs/add_vehicle/add_vehicle_state.dart';
import 'package:honda/features/service/blocs/vehicle/bloc.dart';
import 'package:honda/features/service/models/vehicle.dart';
import 'package:honda/widgets/honda_button.dart';

class EditVehicleScreen extends StatefulWidget {
  final Vehicle vehicle;

  const EditVehicleScreen({Key key, @required this.vehicle}) : super(key: key);

  @override
  _EditVehicleScreenState createState() => _EditVehicleScreenState();
}

class _EditVehicleScreenState extends State<EditVehicleScreen> {
  VehicleForm _form;
  AddVehicleBloc _bloc;
  VehicleBloc _vehicleBloc;
  GlobalKey<FormState> _formKey;
  GlobalKey<ScaffoldState> _scaffoldKey;

  bool _loading;

  ImageProvider _placeholder;

  @override
  void initState() {
    _form = VehicleForm();
    _bloc = AddVehicleBloc();
    _vehicleBloc = VehicleBloc();
    _formKey = GlobalKey<FormState>();
    _scaffoldKey = GlobalKey<ScaffoldState>();
    _placeholder = AssetImage('assets/icons/upload.png');
    _loading = false;

    super.initState();
    _form.id = widget.vehicle.id;
    _placeholder = NetworkImage(widget.vehicle.image);
  }

  @override
  void dispose() {
    _vehicleBloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      appBar: AppBar(
        title: Text('Edit Kendaraan'),
      ),
      body: MultiBlocProvider(
        providers: [
          BlocProvider(create: (context) => _bloc),
        ],
        child: MultiBlocListener(
          listeners: [
            BlocListener(
              bloc: _bloc,
              listener: (context, state) {
                if (state is LoadingAddVehicleState) setState(() => _loading = true);
                if (state is SuccessAddVehicleState) {
                  setState(() => _loading = false);
                  Navigator.pop(context, true);
                }
                if (state is FailedAddVehicleState) {
                  setState(() => _loading = false);
                  _scaffoldKey.currentState.showSnackBar(SnackBar(content: Text(state.reason)));
                }
              },
            ),
          ],
          child: Container(
            child: Form(
              key: _formKey,
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    SizedBox(height: 30),
                    InkWell(
                      onTap: _selectFile,
                      child: Image(
                        image: _placeholder,
                        fit: BoxFit.fitWidth,
                      ),
                    ),
                    SizedBox(height: 20),
                    Text(
                      'No. Polisi',
                      style: TextStyle(fontSize: 18),
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      initialValue: widget.vehicle.nopol,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Masukan No. Polisi',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                      ),
                      onSaved: (t) => _form.nopol = t,
                      validator: (t) {
                        if (t.isEmpty) return 'No. Polisi diperlukan';
                        return null;
                      },
                    ),
                    SizedBox(height: 20),
                    Text(
                      'No. Rangka',
                      style: TextStyle(fontSize: 18),
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      initialValue: widget.vehicle.noRangka,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Masukan No. Rangka',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                      ),
                      onSaved: (t) => _form.noRangka = t,
                      validator: (t) {
                        if (t.isEmpty) return 'No. Rangka diperlukan';
                        return null;
                      },
                    ),
                    SizedBox(height: 20),
                    Text(
                      'No. Mesin',
                      style: TextStyle(fontSize: 18),
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      initialValue: widget.vehicle.noMesin,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Masukan No. Mesin',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                      ),
                      onSaved: (t) => _form.noMesin = t,
                      validator: (t) {
                        if (t.isEmpty) return 'No. Mesin diperlukan';
                        return null;
                      },
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Model',
                      style: TextStyle(fontSize: 18),
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      initialValue: widget.vehicle.model,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Masukan Model kendaraan',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                      ),
                      onSaved: (t) => _form.model = t,
                      validator: (t) {
                        if (t.isEmpty) return 'Model diperlukan';
                        return null;
                      },
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Tipe',
                      style: TextStyle(fontSize: 18),
                    ),
                    SizedBox(height: 10),
                    DropdownButtonFormField<int>(
                      value: int.parse(widget.vehicle.type),
                      isDense: true,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Masukan Tipe',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                      ),
                      onSaved: (t) => _form.type = t,
                      onChanged: (v) {
                        print(v);
                      },
                      validator: (t) {
                        if (t == null) return 'Silahkan pilih tipe';
                        return null;
                      },
                      items: _buildType(),
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Transmisi',
                      style: TextStyle(fontSize: 18),
                    ),
                    SizedBox(height: 10),
                    DropdownButtonFormField<int>(
                      value: int.parse(widget.vehicle.transmition),
                      isDense: true,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Masukan Transmisi',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                      ),
                      onSaved: (t) => _form.transmision = t,
                      validator: (t) {
                        if (t == null) return 'Silahkan pilih transmisi';
                        return null;
                      },
                      onChanged: (v) {
                        print(v);
                      },
                      items: _buildTransmission(),
                    ),
                    SizedBox(height: 20),
                    Text(
                      'Tahun',
                      style: TextStyle(fontSize: 18),
                    ),
                    SizedBox(height: 10),
                    TextFormField(
                      initialValue: widget.vehicle.year,
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: 'Masukan Tahun',
                        labelStyle: TextStyle(
                          fontSize: 18,
                        ),
                        floatingLabelBehavior: FloatingLabelBehavior.never,
                      ),
                      keyboardType: TextInputType.number,
                      onSaved: (t) => _form.year = int.parse(t),
                      validator: (t) {
                        if (t.isEmpty) return 'Tahun diperlukan';
                        return null;
                      },
                    ),
                    SizedBox(height: 30),
                    SizedBox(
                      height: 45,
                      child: PrimaryButton(
                        loading: _loading,
                        text: 'Simpan',
                        onPressed: _submit,
                      ),
                    ),
                    SizedBox(height: 30),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  List<DropdownMenuItem<int>> _buildType() {
    final data = [
      {'id': 0, 'name': 'S'},
      {'id': 1, 'name': 'RS'},
      {'id': 2, 'name': 'Prestige'},
    ];

    return data
        .map<DropdownMenuItem<int>>((e) => DropdownMenuItem<int>(
              value: e['id'],
              child: Text(e['name']),
            ))
        .toList();
  }

  List<DropdownMenuItem<int>> _buildTransmission() {
    final data = [
      {'id': 0, 'name': 'MT'},
      {'id': 1, 'name': 'AT'},
      {'id': 2, 'name': 'CVT'},
    ];

    return data
        .map<DropdownMenuItem<int>>((e) => DropdownMenuItem<int>(
              value: e['id'],
              child: Text(e['name']),
            ))
        .toList();
  }

  _submit() {
    if (_formKey.currentState.validate()) {
      _formKey.currentState.save();
      _bloc.add(StoreVehicle(_form, isUpdate: true));
    }
  }

  void _selectFile() async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            ListTile(
              leading: Container(
                decoration: BoxDecoration(
                  color: AppConfig.of(context).color.primary.withAlpha(100),
                  borderRadius: BorderRadius.circular(10),
                ),
                padding: EdgeInsets.all(5),
                child: Icon(
                  Icons.camera_alt,
                  color: Colors.white,
                ),
              ),
              title: Text('Kamera'),
              onTap: () async {
                final file = await pickImageFromCamera();
                if (file != null) {
                  setState(() {
                    _placeholder = FileImage(file);
                    _form.image = file;
                  });
                }
                Navigator.pop(context);
              },
            ),
            ListTile(
              leading: Container(
                decoration: BoxDecoration(
                  color: AppConfig.of(context).color.primary.withAlpha(100),
                  borderRadius: BorderRadius.circular(10),
                ),
                padding: EdgeInsets.all(5),
                child: Icon(
                  Icons.image,
                  color: Colors.white,
                ),
              ),
              title: Text('Gallery'),
              onTap: () async {
                final file = await pickImageFromGallery();
                if (file != null) {
                  setState(() {
                    _placeholder = FileImage(file);
                    _form.image = file;
                  });
                }
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
    );
  }
}
