import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/config/app_config.dart';
import 'package:honda/features/service/blocs/booking/bloc.dart';
import 'package:honda/features/service/models/booking.dart';
import 'package:honda/features/service/screens/booking_detail_screen.dart';
import 'package:honda/features/service/screens/car_selector_screen.dart';
import 'package:honda/features/service/widgets/single_service_item.dart';
import 'package:intl/intl.dart';

class ServiceSection extends StatefulWidget {
  @override
  _ServiceSectionState createState() => _ServiceSectionState();
}

class _ServiceSectionState extends State<ServiceSection> with SingleTickerProviderStateMixin {
  TabController _tabController;
  BookingBloc _bloc;
  GlobalKey<RefreshIndicatorState> _rk;
  List<Booking> _waiting;
  List<Booking> _process;
  List<Booking> _history;

  @override
  void initState() {
    _tabController = TabController(length: 3, vsync: this, initialIndex: 0);
    _bloc = BookingBloc();
    _rk = GlobalKey<RefreshIndicatorState>();
    _waiting = [];
    _process = [];
    _history = [];
    super.initState();

    _bloc.add(GetBooking());
  }

  @override
  void dispose() {
    _bloc.close();
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => _bloc,
      child: BlocListener(
        bloc: _bloc,
        listener: (context, state) {
          if (state is LoadedBookingState) {
            setState(() {
              _waiting = state.items.where((element) => element.status == "0").toList();
              _process = state.items.where((element) => element.status == "1").toList();
              _history = state.items.where((element) => element.status == "2" || element.status == "3").toList();
            });
          }
        },
        child: Container(
          child: RefreshIndicator(
            key: _rk,
            onRefresh: () async {
              _bloc.add(GetBooking());
            },
            child: CustomScrollView(
              slivers: <Widget>[
                SliverAppBar(
                  title: Text('Service'),
                  centerTitle: true,
                  expandedHeight: 250,
                  bottom: PreferredSize(
                    child: Container(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: <Widget>[
                          InkWell(
                            child: Image.asset(
                              'assets/icons/book_button.png',
                              fit: BoxFit.fitWidth,
                            ),
                            onTap: () {
                              Navigator.of(context).push(MaterialPageRoute(builder: (context) => CarSelectorScreen()));
                            },
                          ),
                          SizedBox(height: 10),
                          InkWell(
                            child: Image.asset(
                              'assets/icons/pickup_button.png',
                              fit: BoxFit.fitWidth,
                            ),
                            onTap: () {
                              Navigator.of(context).push(
                                MaterialPageRoute(
                                  builder: (context) => CarSelectorScreen(
                                    type: ServiceType.PICKUP,
                                  ),
                                ),
                              );
                            },
                          ),
                        ],
                      ),
                    ),
                    preferredSize: Size.fromHeight(250),
                  ),
                ),
                SliverAppBar(
                  pinned: true,
                  floating: true,
                  expandedHeight: 60,
                  bottom: PreferredSize(
                    preferredSize: Size.fromHeight(60),
                    child: TabBar(
                      controller: _tabController,
                      indicatorColor: AppConfig.of(context).color.primary,
                      labelColor: AppConfig.of(context).color.primary,
                      labelStyle: TextStyle(fontWeight: FontWeight.bold),
                      labelPadding: EdgeInsets.symmetric(vertical: 20),
                      unselectedLabelColor: Colors.grey,
                      indicatorWeight: 3,
                      tabs: <Widget>[Text('Request'), Text('Diproses'), Text('Riwayat')],
                    ),
                  ),
                ),
                SliverFillRemaining(
                  fillOverscroll: true,
                  hasScrollBody: true,
                  child: TabBarView(
                    controller: _tabController,
                    children: <Widget>[
                      Container(
                        child: SingleChildScrollView(
                          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: _buildWaitingList(),
                          ),
                        ),
                      ),
                      Container(
                        child: SingleChildScrollView(
                          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: _buildProcessList(),
                          ),
                        ),
                      ),
                      Container(
                        child: SingleChildScrollView(
                          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 10),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: _buildHistoryList(),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _buildWaitingList() {
    if (_waiting.length == 0) {
      return [Text('Tidak ada data')];
    }
    return _waiting.map<Widget>((e) {
      final dt = DateFormat('yyyy-MM-dd HH:mm:ss');
      return SingleServiceItem(
        type: e.type == '0' ? 'PICKUP' : 'BOOKING',
        name: e.vehicle?.model ?? '-',
        policeNumber: e.vehicle?.nopol ?? '-',
        status: e.status,
        date: dt.parse(e.createdAt),
        transmission: e.vehicle.transmition,
        vehicleType: e.vehicle.type,
        onTap: () async {
          final res = await Navigator.push(context, MaterialPageRoute(builder: (context) => BookingDetailScreen(booking: e)));
          if (res is bool && res) {
            _rk.currentState?.show();
          }
        },
      );
    }).toList();
  }

  List<Widget> _buildProcessList() {
    if (_process.length == 0) {
      return [Text('Tidak ada data')];
    }
    return _process.map<Widget>((e) {
      final dt = DateFormat('yyyy-MM-dd HH:mm:ss');
      return SingleServiceItem(
        type: e.type == '0' ? 'PICKUP' : 'BOOKING',
        name: e.vehicle?.model ?? '-',
        policeNumber: e.vehicle?.nopol ?? '-',
        status: e.status,
        date: dt.parse(e.createdAt),
        transmission: e.vehicle.transmition,
        vehicleType: e.vehicle.type,
        onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) => BookingDetailScreen(booking: e)));
        },
      );
    }).toList();
  }

  List<Widget> _buildHistoryList() {
    if (_history.length == 0) {
      return [Text('Tidak ada data')];
    }
    return _history.map<Widget>((e) {
      final dt = DateFormat('yyyy-MM-dd HH:mm:ss');
      return SingleServiceItem(
        type: e.type == '0' ? 'PICKUP' : 'BOOKING',
        name: e.vehicle?.model ?? '-',
        policeNumber: e.vehicle?.nopol ?? '-',
        status: e.status,
        date: dt.parse(e.createdAt),
        transmission: e.vehicle.transmition,
        vehicleType: e.vehicle.type,
        onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (context) => BookingDetailScreen(booking: e)));
        },
      );
    }).toList();
  }
}
