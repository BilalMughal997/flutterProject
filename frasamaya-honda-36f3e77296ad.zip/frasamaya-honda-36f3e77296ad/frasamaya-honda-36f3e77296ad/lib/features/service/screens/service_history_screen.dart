import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/features/service/blocs/booking/bloc.dart';
import 'package:honda/features/service/models/booking.dart';
import 'package:honda/features/service/widgets/single_service_item.dart';
import 'package:intl/intl.dart';

import 'booking_detail_screen.dart';

class ServiceHistoryScreen extends StatefulWidget {
  @override
  _ServiceHistoryScreenState createState() => _ServiceHistoryScreenState();
}

class _ServiceHistoryScreenState extends State<ServiceHistoryScreen> {
  BookingBloc _bloc;
  GlobalKey<RefreshIndicatorState> _rk;
  List<Booking> _items;

  @override
  void initState() {
    _bloc = BookingBloc();
    _rk = GlobalKey<RefreshIndicatorState>();
    _items = [];
    super.initState();

    _bloc.add(GetBooking());
  }

  @override
  void dispose() {
    _bloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Riwayat Servis'),
      ),
      body: BlocProvider(
        create: (context) => _bloc,
        child: BlocListener(
          bloc: _bloc,
          listener: (context, state) {
            if (state is LoadedBookingState) {
              setState(() => _items = state.items);
            }
          },
          child: Container(
            child: RefreshIndicator(
              key: _rk,
              onRefresh: () async {
                _bloc.add(GetBooking());
              },
              child: SingleChildScrollView(
                padding: EdgeInsets.symmetric(horizontal: 20),
                physics: AlwaysScrollableScrollPhysics(),
                child: Column(
                  children: _buildList(),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _buildList() {
    return _items.map<Widget>((e) {
      final dt = DateFormat('yyyy-MM-dd HH:mm:ss');
      return SingleServiceItem(
        type: e.type == '0' ? 'PICKUP' : 'BOOKING',
        name: e.vehicle?.model ?? '-',
        policeNumber: e.vehicle?.nopol ?? '-',
        status: e.status,
        date: dt.parse(e.createdAt),
        vehicleType: e.vehicle.type,
        transmission: e.vehicle.transmition,
        idKendaraan: e.vehicle.id,
        id: e.id,
        onTap: () async {
          final res = await Navigator.push(context, MaterialPageRoute(builder: (context) => BookingDetailScreen(booking: e)));
          if (res is bool && res) {
            _rk.currentState?.show();
          }
        },
      );
    }).toList();
  }
}
