import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/features/service/blocs/vehicle/bloc.dart';
import 'package:honda/features/service/models/vehicle.dart';
import 'package:honda/features/service/screens/add_booking_screen.dart';
import 'package:honda/features/service/screens/add_vehicle_screen.dart';
import 'package:honda/features/service/widgets/single_car_item.dart';
import 'package:honda/widgets/honda_button.dart';

import 'edit_vehicle_screen.dart';

enum ServiceType {
  BOOKING,
  PICKUP,
}

class CarSelectorScreen extends StatefulWidget {
  final ServiceType type;
  final bool isEdit;

  const CarSelectorScreen({Key key, this.type: ServiceType.BOOKING, this.isEdit: false}) : super(key: key);

  @override
  _CarSelectorScreenState createState() => _CarSelectorScreenState();
}

class _CarSelectorScreenState extends State<CarSelectorScreen> {
  VehicleBloc _bloc;
  List<Vehicle> _vehicles;
  GlobalKey<RefreshIndicatorState> _rk;

  @override
  void initState() {
    _bloc = VehicleBloc();
    _vehicles = [];
    _rk = GlobalKey<RefreshIndicatorState>();
    super.initState();

    _bloc.add(GetVehicle());
  }

  @override
  void dispose() {
    _bloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text((widget.isEdit) ? 'Daftar kendaraan' : 'Pilih Kendaraan'),
      ),
      body: BlocProvider(
        create: (context) => _bloc,
        child: BlocListener(
          bloc: _bloc,
          listener: (context, state) {
            if (state is LoadedVehicleState) setState(() => _vehicles = state.items);
          },
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 20),
            child: Column(
              children: <Widget>[
                Expanded(
                  child: Container(
                    child: RefreshIndicator(
                      key: _rk,
                      onRefresh: () async {
                        _bloc.add(GetVehicle());
                      },
                      child: SingleChildScrollView(
                        physics: AlwaysScrollableScrollPhysics(),
                        child: Column(
                          children: _buildItems(),
                        ),
                      ),
                    ),
                  ),
                ),
                Container(
                  width: double.infinity,
                  height: 50,
                  margin: EdgeInsets.only(bottom: 20),
                  child: SecondaryButton(
                    text: 'Tambah Kendaraan',
                    onPressed: () async {
                      final res = await Navigator.push(context, MaterialPageRoute(builder: (context) => AddVehicleScreen()));
                      if (res is bool && res) {
                        _bloc.add(GetVehicle());
                      }
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _buildItems() {
    return _vehicles
        .map<Widget>(
          (e) => SingleCarItem(
            vehicle: e,
            onEdit: !widget.isEdit
                ? null
                : () async {
                    final res = await Navigator.push(context, MaterialPageRoute(builder: (context) => EditVehicleScreen(vehicle: e)));
                    if (res is bool && res) _rk.currentState.show();
                  },
            onTap: () {
              Navigator.push(context, MaterialPageRoute(builder: (context) => AddBookingScreen(type: widget.type, idKendaraan: e.id)));
            },
          ),
        )
        .toList();
  }
}
