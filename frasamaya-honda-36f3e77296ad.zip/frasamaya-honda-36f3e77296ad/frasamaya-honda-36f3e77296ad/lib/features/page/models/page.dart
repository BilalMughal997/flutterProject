class Page {
  String content;
  String title;

  Page({this.content, this.title});

  factory Page.fromJson(Map<String, dynamic> json) {
    return Page(
      content: json['content'],
      title: json['title'],
    );
  }
}
