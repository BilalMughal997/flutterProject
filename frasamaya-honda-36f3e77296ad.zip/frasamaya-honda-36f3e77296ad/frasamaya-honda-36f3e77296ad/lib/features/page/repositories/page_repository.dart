import 'package:honda/features/page/contracts/page_repository_contract.dart';
import 'package:honda/features/page/data/page_api_service.dart';
import 'package:honda/features/page/models/page.dart';

class PageRepository implements PageRepositoryContract {
  PageApiService _service;
  Map<String, String> _pages;

  PageRepository() {
    _service = PageApiService.create();
    _pages = {
      'tentangKami': '1',
      'fasilitasKami': '2',
      'alamatKami': '4',
      'hubungiKami': '5',
    };
  }

  @override
  Future<Page> alamatKami() async {
    final resp = await _service.getPage(_pages['alamatKami']);
    return Page.fromJson(resp.body['data']);
  }

  @override
  Future<Page> fasilitasKami() async {
    final resp = await _service.getPage(_pages['fasilitasKami']);
    return Page.fromJson(resp.body['data']);
  }

  @override
  Future<Page> kontakKami() async {
    final resp = await _service.getPage(_pages['hubungiKami']);
    return Page.fromJson(resp.body['data']);
  }

  @override
  Future<Page> tentangKami() async {
    final resp = await _service.getPage(_pages['tentangKami']);
    return Page.fromJson(resp.body['data']);
  }
}
