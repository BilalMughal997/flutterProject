import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/features/page/bloc/bloc.dart';
import 'package:webview_flutter/webview_flutter.dart';

enum PageType {
  TENTANG_KAMI,
  FASILITAS_KAMI,
  ALAMAT_KAMI,
  HUBUNGI_KAMI,
}

class PageScreen extends StatefulWidget {
  final PageType type;

  const PageScreen({Key key, @required this.type}) : super(key: key);

  @override
  _PageScreenState createState() => _PageScreenState();
}

class _PageScreenState extends State<PageScreen> {
  PageBloc _bloc;
  String _title;
  Completer<WebViewController> _controller;

  @override
  void initState() {
    _bloc = PageBloc();
    _title = '';
    _controller = Completer<WebViewController>();
    super.initState();

    if (widget.type == PageType.TENTANG_KAMI) _bloc.add(GetTentangKamiPage());
    if (widget.type == PageType.FASILITAS_KAMI) _bloc.add(GetFasilitasKamiPage());
    if (widget.type == PageType.ALAMAT_KAMI) _bloc.add(GetAlamatKamiPage());
    if (widget.type == PageType.HUBUNGI_KAMI) _bloc.add(GetHubungiKamiPage());
  }

  @override
  void dispose() {
    _bloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (context) => _bloc,
      child: Scaffold(
        appBar: AppBar(
          title: Text(_title),
        ),
        body: Container(
          child: BlocListener(
            bloc: _bloc,
            listener: (context, state) {
              if (state is LoadingPageState) setState(() => _title = 'Memuat');
              if (state is SuccessPageState) setState(() => _title = state.page.title);
              if (state is FailedPageState) setState(() => _title = 'Error');
            },
            child: BlocBuilder(
              bloc: _bloc,
              builder: (context, state) {
                if (state is SuccessPageState) {
//                  return SingleChildScrollView(
//                    padding: EdgeInsets.symmetric(horizontal: 20),
//                    child: Column(
//                      crossAxisAlignment: CrossAxisAlignment.stretch,
//                      children: <Widget>[
//                        Html(data: state.page.content),
//                      ],
//                    ),
//                  );

                  return WebView(
                    initialUrl: Uri.dataFromString(state.page.content, mimeType: 'text/html').toString(),
                    javascriptMode: JavascriptMode.unrestricted,
                    onWebViewCreated: (WebViewController webViewController) {
                      _controller.complete(webViewController);
                    },
                    javascriptChannels: <JavascriptChannel>[
                      _toasterJavascriptChannel(context),
                    ].toSet(),
                    navigationDelegate: (NavigationRequest request) {
                      if (request.url.startsWith('https://www.youtube.com/')) {
                        print('blocking navigation to $request}');
                        return NavigationDecision.prevent;
                      }
                      print('allowing navigation to $request');
                      return NavigationDecision.navigate;
                    },
                    onPageStarted: (String url) {
                      print('Page started loading: $url');
                    },
                    onPageFinished: (String url) {
                      print('Page finished loading: $url');
                    },
                    gestureNavigationEnabled: true,
                  );
                }

                if (state is FailedPageState) {
                  return Center(
                    child: Text('Gagal memuat halaman'),
                  );
                }

                return Center(
                  child: CircularProgressIndicator(),
                );
              },
            ),
          ),
        ),
      ),
    );
  }

  JavascriptChannel _toasterJavascriptChannel(BuildContext context) {
    return JavascriptChannel(
      name: 'Toaster',
      onMessageReceived: (JavascriptMessage message) {
        Scaffold.of(context).showSnackBar(
          SnackBar(content: Text(message.message)),
        );
      },
    );
  }
}
