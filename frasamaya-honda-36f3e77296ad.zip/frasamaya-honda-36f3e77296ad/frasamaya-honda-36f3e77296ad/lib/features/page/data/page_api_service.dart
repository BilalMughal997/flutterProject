import 'package:chopper/chopper.dart';
import 'package:honda/core/client_preset.dart';

part 'page_api_service.chopper.dart';

@ChopperApi(baseUrl: 'page')
abstract class PageApiService extends ChopperService {
  @Get(path: 'index/{id}')
  Future<Response> getPage(@Path('id') String id);

  static PageApiService create() {
    final client = ClientPreset.authClient(services: [_$PageApiService()]);
    return _$PageApiService(client);
  }
}
