import 'package:honda/features/page/models/page.dart';

abstract class PageRepositoryContract {
  Future<Page> tentangKami();

  Future<Page> fasilitasKami();

  Future<Page> alamatKami();

  Future<Page> kontakKami();
}
