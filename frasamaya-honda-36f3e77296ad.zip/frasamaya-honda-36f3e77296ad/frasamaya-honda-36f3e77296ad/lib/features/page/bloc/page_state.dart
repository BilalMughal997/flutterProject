import 'package:equatable/equatable.dart';
import 'package:honda/features/page/models/page.dart';

abstract class PageState extends Equatable {
  const PageState();
}

class InitialPageState extends PageState {
  @override
  List<Object> get props => [];
}

class LoadingPageState extends PageState {
  @override
  List<Object> get props => [];
}

class SuccessPageState extends PageState {
  final Page page;

  SuccessPageState(this.page);

  @override
  List<Object> get props => [page];
}

class FailedPageState extends PageState {
  final String reason;

  FailedPageState(this.reason);

  @override
  List<Object> get props => [reason];
}
