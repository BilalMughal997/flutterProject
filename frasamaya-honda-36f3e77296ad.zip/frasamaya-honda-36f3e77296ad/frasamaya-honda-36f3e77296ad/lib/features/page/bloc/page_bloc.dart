import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/page/contracts/page_repository_contract.dart';

import './bloc.dart';

class PageBloc extends Bloc<PageEvent, PageState> {
  PageRepositoryContract _repository;

  PageBloc() {
    _repository = GetIt.I<PageRepositoryContract>();
  }

  @override
  PageState get initialState => InitialPageState();

  @override
  Stream<PageState> mapEventToState(
    PageEvent event,
  ) async* {
    if (event is GetTentangKamiPage) {
      yield LoadingPageState();

      try {
        final page = await _repository.tentangKami();
        yield SuccessPageState(page);
      } catch (e) {
        yield FailedPageState(e.toString());
      }
    }

    if (event is GetFasilitasKamiPage) {
      yield LoadingPageState();

      try {
        final page = await _repository.fasilitasKami();
        yield SuccessPageState(page);
      } catch (e) {
        yield FailedPageState(e.toString());
      }
    }

    if (event is GetAlamatKamiPage) {
      yield LoadingPageState();

      try {
        final page = await _repository.alamatKami();
        yield SuccessPageState(page);
      } catch (e) {
        yield FailedPageState(e.toString());
      }
    }

    if (event is GetHubungiKamiPage) {
      yield LoadingPageState();

      try {
        final page = await _repository.kontakKami();
        yield SuccessPageState(page);
      } catch (e) {
        yield FailedPageState(e.toString());
      }
    }
  }
}
