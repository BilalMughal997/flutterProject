import 'package:equatable/equatable.dart';

abstract class PageEvent extends Equatable {
  const PageEvent();
}

class GetTentangKamiPage extends PageEvent {
  @override
  List<Object> get props => [];
}

class GetFasilitasKamiPage extends PageEvent {
  @override
  List<Object> get props => [];
}

class GetAlamatKamiPage extends PageEvent {
  @override
  List<Object> get props => [];
}

class GetHubungiKamiPage extends PageEvent {
  @override
  List<Object> get props => [];
}
