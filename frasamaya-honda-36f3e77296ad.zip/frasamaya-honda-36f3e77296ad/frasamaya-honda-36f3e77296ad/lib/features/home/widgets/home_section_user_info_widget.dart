import 'package:flutter/material.dart';

class HomeSectionUserInfoWidget extends StatelessWidget {
  final String name;
  final ImageProvider image;

  const HomeSectionUserInfoWidget({
    Key key,
    this.name: 'Nama User',
    this.image: const NetworkImage('https://placehold.it/60'),
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 60,
      child: Row(
        children: <Widget>[
          Container(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(60),
              child: Container(
                color: Colors.white,
                height: 60,
                child: Image(
                  image: this.image,
                  width: 60,
                ),
              ),
            ),
          ),
          SizedBox(width: 10),
          Expanded(
            child: Container(
              height: double.infinity,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Text(
                    'Selamat datang kembali,',
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                    ),
                  ),
                  Text(
                    this.name,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ],
              ),
            ),
          ),
//          Container(
//            child: Image(
//              image: AssetImage('assets/icons/notification_active.png'),
//            ),
//          ),
        ],
      ),
    );
  }
}
