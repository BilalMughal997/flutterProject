import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/config/app_config.dart';
import 'package:honda/features/home/blocs/nearby/bloc.dart';
import 'package:honda/features/home/models/event.dart';
import 'package:honda/features/home/screens/all_event_screen.dart';
import 'package:honda/screens/post_detail_screen.dart';
import 'package:honda/widgets/honda_button.dart';
import 'package:intl/intl.dart';

class HomeSectionNearbyEventWidget extends StatefulWidget {
  const HomeSectionNearbyEventWidget({Key key}) : super(key: key);

  @override
  _HomeSectionNearbyEventWidgetState createState() => _HomeSectionNearbyEventWidgetState();
}

class _HomeSectionNearbyEventWidgetState extends State<HomeSectionNearbyEventWidget> {
  List<Event> _events;

  @override
  void initState() {
    _events = [];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<NearbyBloc, NearbyState>(
      listener: (context, state) {
        if (state is LoadedNearbyState) setState(() => _events = state.items);
      },
      child: Visibility(
        visible: _events.length > 0,
        child: Container(
          child: Column(
            children: <Widget>[
              Container(
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Text(
                            'Event di Sekitarmu',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Buruan, ikuti banyak event menarik',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.normal,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => AllEventScreen()));
                      },
                      child: Text(
                        'Lihat semua',
                        style: TextStyle(
                          color: AppConfig.of(context).color.primary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Container(
                width: MediaQuery.of(context).size.width,
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: _buildItems(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _buildItems() {
    return _events.map<Widget>((e) {
      final df = DateFormat('yyyy-MM-dd HH:mm:ss');
      final date = e.createdAt == null ? null : df.parse(e.createdAt);

      return NearbyEventItem(
        id: e.id,
        title: e.title,
        image: NetworkImage(e.image),
        date: date,
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => PostDetailScreen(
                image: NetworkImage(e.image),
                date: date,
                title: e.title,
                content: e.content,
              ),
            ),
          );
        },
      );
    }).toList();
  }
}

class NearbyEventItem extends StatelessWidget {
  final String id;
  final String title;
  final ImageProvider image;
  final DateTime date;
  final VoidCallback onTap;

  const NearbyEventItem({
    Key key,
    this.id,
    this.title,
    this.image,
    this.date,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    DateFormat dayFormat = DateFormat('dd');
    DateFormat abbrMonthFormat = DateFormat('MMM');

    return Container(
      margin: EdgeInsets.only(right: 20),
      width: 170,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          AspectRatio(
            aspectRatio: 1,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: AspectRatio(
                  aspectRatio: 1 / 1,
                  child: new Container(
                    decoration: new BoxDecoration(
                        image: new DecorationImage(
                      fit: BoxFit.cover,
                      alignment: FractionalOffset.topCenter,
                      image: this.image,
                    )),
                  )),
            ),
          ),
          SizedBox(height: 10),
          Text(
            this.title,
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Column(
                children: <Widget>[
                  Text(date == null ? '-' : dayFormat.format(date)),
                  Text(date == null ? '' : abbrMonthFormat.format(date)),
                ],
              ),
              PrimaryButton(
                text: 'Baca',
                onPressed: this.onTap,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
