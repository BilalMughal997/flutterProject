import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/config/app_config.dart';
import 'package:honda/features/home/blocs/banner/banner_bloc.dart';
import 'package:honda/features/home/blocs/banner/banner_state.dart';
import 'package:honda/features/home/models/banner.dart' as BannerModel;
import 'package:honda/features/home/screens/all_banner_screen.dart';
import 'package:honda/widgets/view_image_widget.dart';

class HomeSectionBannerWidget extends StatefulWidget {
  final double indicatorPadding;

  const HomeSectionBannerWidget({
    Key key,
    this.indicatorPadding: 20,
  }) : super(key: key);

  @override
  _HomeSectionBannerWidgetState createState() => _HomeSectionBannerWidgetState();
}

class _HomeSectionBannerWidgetState extends State<HomeSectionBannerWidget> {
  int _currentPosition;
  List<BannerModel.Banner> _banners;

  @override
  void initState() {
    _currentPosition = 0;
    _banners = [];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<BannerBloc, BannerState>(
      listener: (context, state) {
        if (state is LoadedBannerState) setState(() => _banners = state.items);
      },
      child: Container(
        child: Visibility(
          visible: _banners.length > 0,
          child: Column(
            children: <Widget>[
              CarouselSlider(
                options: CarouselOptions(
                  aspectRatio: 9 / 3,
                  autoPlay: true,
                  pauseAutoPlayOnTouch: true,
                  onPageChanged: (page, _) {
                    setState(() => _currentPosition = page);
                  },
                ),
                items: _buildItems(),
              ),
              Container(
                margin: EdgeInsets.only(top: 20, bottom: 5),
                padding: EdgeInsets.symmetric(
                  horizontal: this.widget.indicatorPadding,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: <Widget>[
                    Container(
                      child: BannerPositionIndicator(
                        length: _banners.length,
                        currentPosition: _currentPosition,
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.push(context, MaterialPageRoute(builder: (context) => AllBannerScreen()));
                      },
                      child: Container(
                        child: Text(
                          'Lihat Semua',
                          style: TextStyle(
                            fontSize: 14,
                            fontWeight: FontWeight.w600,
                            color: AppConfig.of(context).color.primary,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _buildItems() {
    return _banners
        .map<Widget>(
          (bi) => Builder(
            builder: (context) => InkWell(
              onTap: () {},
              child: InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => ViewImageWidget(image: NetworkImage(bi.image))));
                },
                child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image(
                      image: NetworkImage(bi.image),
                      fit: BoxFit.fitHeight,
                    ),
                  ),
                ),
              ),
            ),
          ),
        )
        .toList();
  }
}

class BannerPositionIndicator extends StatelessWidget {
  final int length;
  final int currentPosition;
  final bool center;

  const BannerPositionIndicator({
    Key key,
    @required this.length,
    this.currentPosition: 0,
    this.center: false,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      child: Row(
        mainAxisAlignment: center ? MainAxisAlignment.center : MainAxisAlignment.start,
        children: Iterable<int>.generate(this.length)
            .map(
              (i) => Container(
                margin: EdgeInsets.only(right: 5),
                width: this.currentPosition == i ? 20 : 8,
                height: 8,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(8),
                  color: this.currentPosition == i ? AppConfig.of(context).color.primary : Colors.grey,
                ),
              ),
            )
            .toList(),
      ),
    );
  }
}
