import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/config/app_config.dart';
import 'package:honda/features/home/blocs/promo/bloc.dart';
import 'package:honda/features/home/models/offer.dart';
import 'package:honda/features/home/screens/all_promo_screen.dart';
import 'package:honda/features/home/screens/webview_detail_screen.dart';
import 'package:honda/widgets/honda_button.dart';
import 'package:honda/widgets/view_image_widget.dart';

class HomeSectionPromoWidget extends StatefulWidget {
  final double titlePadding;

  const HomeSectionPromoWidget({
    Key key,
    this.titlePadding: 20,
  }) : super(key: key);

  @override
  _HomeSectionPromoWidgetState createState() => _HomeSectionPromoWidgetState();
}

class _HomeSectionPromoWidgetState extends State<HomeSectionPromoWidget> {
  List<Offer> _promos;

  @override
  void initState() {
    _promos = [];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<PromoBloc, PromoState>(
      listener: (context, state) {
        if (state is LoadedPromoState) setState(() => _promos = state.items);
      },
      child: Visibility(
        visible: _promos.length > 0,
        child: Container(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: <Widget>[
              Container(
                padding: EdgeInsets.symmetric(horizontal: this.widget.titlePadding),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text(
                      'Promo Menarik',
                      style: TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      'Nikmati penawaran utama dari servis kami',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.normal,
                        color: Colors.grey,
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 10),
              Container(
                height: 300,
                width: MediaQuery.of(context).size.width,
                color: AppConfig.of(context).color.accent,
                padding: EdgeInsets.symmetric(vertical: 60),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: <Widget>[
                      _promoAction(),
                      ..._buildItems(),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _promoAction() {
    return Container(
      child: AspectRatio(
        aspectRatio: 1,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Image(image: AssetImage('assets/icons/offer.png'), width: MediaQuery.of(context).size.width * 0.25),
            SizedBox(height: 30),
            PrimaryButton(
              text: 'Lihat Semua',
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => AllPromoScreen()));
              },
            ),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildItems() {
    return _promos
        .map<Widget>((item) => Container(
              margin: EdgeInsets.only(right: 20),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: InkWell(
                  onTap: () {
                    if (item.url != null)
                      Navigator.push(context, MaterialPageRoute(builder: (context) => WebviewDetailScreen(url: item.url)));
                    else
                      Navigator.push(context, MaterialPageRoute(builder: (context) => ViewImageWidget(image: NetworkImage(item.image))));
                  },
                  child: AspectRatio(
                      aspectRatio: 487 / 451,
                      child: new Container(
                        decoration: new BoxDecoration(
                            image: new DecorationImage(
                          fit: BoxFit.cover,
                          alignment: FractionalOffset.topCenter,
                          image: new NetworkImage(item.image),
                        )),
                      )),
                ),
              ),
            ))
        .toList();
  }
}
