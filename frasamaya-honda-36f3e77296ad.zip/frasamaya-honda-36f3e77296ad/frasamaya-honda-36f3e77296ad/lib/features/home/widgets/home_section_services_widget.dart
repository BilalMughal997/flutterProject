import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:honda/features/service/screens/car_selector_screen.dart';

class HomeSectionServicesWidget extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(
            'Servis Menu',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Expanded(
                child: InkWell(
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => CarSelectorScreen()));
                  },
                  child: Image.asset(
                    'assets/icons/button_booking.png',
                    fit: BoxFit.fitWidth,
                  ),
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                child: InkWell(
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => CarSelectorScreen(type: ServiceType.PICKUP)));
                  },
                  child: Image.asset(
                    'assets/icons/button_pickup.png',
                    fit: BoxFit.fitWidth,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
