import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/config/app_config.dart';
import 'package:honda/features/home/blocs/tips_trick/bloc.dart';
import 'package:honda/features/home/models/tips.dart';
import 'package:honda/features/home/screens/all_tips_screen.dart';
import 'package:honda/screens/post_detail_screen.dart';
import 'package:honda/widgets/honda_button.dart';
import 'package:intl/intl.dart';

class HomeSectionTipsTrickWidget extends StatefulWidget {
  const HomeSectionTipsTrickWidget({Key key}) : super(key: key);

  @override
  _HomeSectionTipsTrickWidgetState createState() => _HomeSectionTipsTrickWidgetState();
}

class _HomeSectionTipsTrickWidgetState extends State<HomeSectionTipsTrickWidget> {
  List<Tips> _tips;

  @override
  void initState() {
    _tips = [];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return BlocListener<TipsTrickBloc, TipsTrickState>(
      listener: (context, state) {
        if (state is LoadedTipsTrickState) setState(() => _tips = state.items);
      },
      child: Visibility(
        visible: _tips.length > 0,
        child: Container(
          child: Column(
            children: <Widget>[
              Container(
                child: Row(
                  children: <Widget>[
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisSize: MainAxisSize.min,
                        children: <Widget>[
                          Text(
                            'Tips & Trick',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          Text(
                            'Kami akan selalu berbagi tips bermanfaat',
                            style: TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.normal,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ),
                    InkWell(
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => AllTipsScreen()));
                      },
                      child: Text(
                        'Lihat semua',
                        style: TextStyle(
                          color: AppConfig.of(context).color.primary,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 20),
              Container(
                width: MediaQuery.of(context).size.width,
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: Row(
                    children: _buildItems(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _buildItems() {
    return _tips.map<Widget>((e) {
      final df = DateFormat('yyyy-MM-dd HH:mm:ss');
      final date = e.createdAt == null ? null : df.parse(e.createdAt);
      return TipsTrickItem(
        id: e.id,
        title: e.title,
        date: date,
        image: NetworkImage(e.image ?? 'https://placehold.it/500'),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => PostDetailScreen(
                image: NetworkImage(e.image),
                date: date,
                title: e.title,
                content: e.content,
              ),
            ),
          );
        },
      );
    }).toList();
  }
}

class TipsTrickItem extends StatelessWidget {
  final String id;
  final String title;
  final ImageProvider image;
  final DateTime date;
  final VoidCallback onTap;

  const TipsTrickItem({
    Key key,
    this.id,
    this.title,
    this.image,
    this.date,
    this.onTap,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    DateFormat dateFormat = DateFormat('dd MMM yyyy');

    return Container(
      margin: EdgeInsets.only(right: 20),
      width: 220,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.start,
        children: <Widget>[
          AspectRatio(
            aspectRatio: 4 / 2,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: AspectRatio(
                aspectRatio: 1 / 1,
                child: new Container(
                  decoration: new BoxDecoration(
                    image: new DecorationImage(
                      fit: BoxFit.cover,
                      alignment: FractionalOffset.topCenter,
                      image: this.image,
                    ),
                  ),
                ),
              ),
            ),
          ),
          SizedBox(height: 10),
          Text(
            this.title,
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Text(date == null ? 'Unknown' : dateFormat.format(date)),
              PrimaryButton(
                text: 'Baca',
                onPressed: onTap,
              ),
            ],
          ),
        ],
      ),
    );
  }
}
