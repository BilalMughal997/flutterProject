class Offer {
  String id;
  String image;
  String name;
  String url;

  Offer({this.id, this.image, this.name, this.url});

  factory Offer.fromJson(Map<String, dynamic> json) {
    return Offer(
      id: json['id_offer'],
      image: json['image'],
      name: json['name'],
      url: json['url'],
    );
  }
}
