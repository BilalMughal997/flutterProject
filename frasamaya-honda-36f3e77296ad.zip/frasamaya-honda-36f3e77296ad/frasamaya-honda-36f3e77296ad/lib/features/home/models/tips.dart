class Tips {
  String content;
  String createdAt;
  String id;
  String image;
  String title;

  Tips({this.content, this.createdAt, this.id, this.image, this.title});

  factory Tips.fromJson(Map<String, dynamic> json) {
    return Tips(
      content: json['content'],
      createdAt: json['created_at'],
      id: json['id_tips'],
      image: json['image'],
      title: json['title'],
    );
  }
}
