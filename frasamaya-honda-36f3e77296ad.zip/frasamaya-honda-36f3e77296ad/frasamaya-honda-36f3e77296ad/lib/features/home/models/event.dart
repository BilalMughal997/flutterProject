class Event {
  String content;
  String createdAt;
  String id;
  String image;
  String title;

  Event({this.content, this.createdAt, this.id, this.image, this.title});

  factory Event.fromJson(Map<String, dynamic> json) {
    return Event(
      content: json['content'],
      createdAt: json['created_at'],
      id: json['id_event'],
      image: json['image'],
      title: json['title'],
    );
  }
}
