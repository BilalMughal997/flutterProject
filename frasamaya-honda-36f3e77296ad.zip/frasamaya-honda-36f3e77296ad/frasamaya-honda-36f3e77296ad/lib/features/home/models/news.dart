class News {
  String content;
  String createdAt;
  String id;
  String image;
  String title;

  News({this.content, this.createdAt, this.id, this.image, this.title});

  factory News.fromJson(Map<String, dynamic> json) {
    return News(
      content: json['content'],
      createdAt: json['created_at'],
      id: json['id_news'],
      image: json['image'],
      title: json['title'],
    );
  }
}
