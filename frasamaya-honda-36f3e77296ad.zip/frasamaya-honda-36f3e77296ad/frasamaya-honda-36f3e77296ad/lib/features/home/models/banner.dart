class Banner {
  String description;
  String id;
  String image;
  String name;

  Banner({this.description, this.id, this.image, this.name});

  factory Banner.fromJson(Map<String, dynamic> json) {
    return Banner(
      description: json['description'],
      id: json['id_banner'],
      image: json['image'],
      name: json['name'],
    );
  }
}
