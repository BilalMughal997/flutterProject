import 'package:honda/features/home/contracts/nearby_repository_contract.dart';
import 'package:honda/features/home/models/event.dart';

class DummyNearbyRepository implements NearbyRepositoryContract {
  @override
  Future<List<Event>> getNearbyEvent() async {
    await Future.delayed(Duration(seconds: 3));
    final data = [Event()];

    return Future.value(data);
  }
}
