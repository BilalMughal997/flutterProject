import 'package:honda/features/home/contracts/promo_repository_contract.dart';
import 'package:honda/features/home/data/home_api_service.dart';
import 'package:honda/features/home/models/offer.dart';

class PromoRepository implements PromoRepositoryContract {
  HomeApiService _service;

  PromoRepository() {
    _service = HomeApiService.create();
  }

  @override
  Future<List<Offer>> getPromo() async {
    final resp = await _service.getOffers();
    return resp.body['data'].map<Offer>((json) => Offer.fromJson(json)).toList();
  }
}
