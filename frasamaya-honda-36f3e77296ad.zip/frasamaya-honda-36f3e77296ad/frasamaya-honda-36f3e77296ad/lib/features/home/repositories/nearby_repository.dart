import 'package:honda/features/home/contracts/nearby_repository_contract.dart';
import 'package:honda/features/home/data/home_api_service.dart';
import 'package:honda/features/home/models/event.dart';

class NearbyRepository implements NearbyRepositoryContract {
  HomeApiService _service;

  NearbyRepository() {
    _service = HomeApiService.create();
  }

  @override
  Future<List<Event>> getNearbyEvent() async {
//    final df = DateFormat('dd-MM-yyyy');
    final resp = await _service.getEvents();
    return resp.body['data'].map<Event>((json) => Event.fromJson(json)).toList();
  }
}
