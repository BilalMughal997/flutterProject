import 'package:honda/features/home/contracts/tips_trick_repository_contract.dart';
import 'package:honda/features/home/data/home_api_service.dart';
import 'package:honda/features/home/models/tips.dart';

class TipsTrickRepository implements TipsTrickRepositoryContract {
  HomeApiService _service;

  TipsTrickRepository() {
    _service = HomeApiService.create();
  }

  @override
  Future<List<Tips>> getTipsTrick() async {
    final resp = await _service.getTipsTricks();
    return resp.body['data'].map<Tips>((json) => Tips.fromJson(json)).toList();
  }
}
