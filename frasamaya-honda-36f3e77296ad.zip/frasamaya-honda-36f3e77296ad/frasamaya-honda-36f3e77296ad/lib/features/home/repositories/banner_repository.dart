import 'package:honda/features/home/contracts/banner_repository_contract.dart';
import 'package:honda/features/home/data/home_api_service.dart';
import 'package:honda/features/home/models/banner.dart';

class BannerRepository implements BannerRepositoryContract {
  HomeApiService _service;

  BannerRepository() {
    _service = HomeApiService.create();
  }

  @override
  Future<List<Banner>> getBanners() async {
    final resp = await _service.getBanners();
    return resp.body['data'].map<Banner>((json) => Banner.fromJson(json)).toList();
  }
}
