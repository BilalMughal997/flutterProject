import 'package:honda/features/home/contracts/news_repository_contract.dart';
import 'package:honda/features/home/models/news.dart';

class DummyNewsRepository implements NewsRepositoryContract {
  @override
  Future<List<News>> getNews() async {
    await Future.delayed(Duration(seconds: 3));
    final data = [
      News(),
    ];

    return Future.value(data);
  }
}
