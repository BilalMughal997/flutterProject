import 'package:honda/features/home/contracts/promo_repository_contract.dart';
import 'package:honda/features/home/models/offer.dart';

class DummyPromoRepository implements PromoRepositoryContract {
  @override
  Future<List<Offer>> getPromo() async {
    await Future.delayed(Duration(seconds: 3));
    return [
      Offer(),
    ];
  }
}
