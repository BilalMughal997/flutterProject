import 'package:honda/features/home/contracts/news_repository_contract.dart';
import 'package:honda/features/home/data/home_api_service.dart';
import 'package:honda/features/home/models/news.dart';

class NewsRepository implements NewsRepositoryContract {
  HomeApiService _service;

  NewsRepository() {
    _service = HomeApiService.create();
  }

  @override
  Future<List<News>> getNews() async {
    final resp = await _service.getNewses();
    return resp.body['data'].map<News>((json) => News.fromJson(json)).toList();
  }
}
