import 'package:honda/features/home/contracts/banner_repository_contract.dart';
import 'package:honda/features/home/models/banner.dart' as BannerModel;

class DummyBannerRepository implements BannerRepositoryContract {
  @override
  Future<List<BannerModel.Banner>> getBanners() async {
    await Future.delayed(Duration(seconds: 2));
    final banners = [
      BannerModel.Banner(id: '1', image: 'https://placehold.it/200', name: 'as', description: 'sf'),
    ];

    return Future.value(banners);
  }
}
