import 'package:honda/features/home/contracts/tips_trick_repository_contract.dart';
import 'package:honda/features/home/models/tips.dart';

class DummyTipsTrickRepository implements TipsTrickRepositoryContract {
  @override
  Future<List<Tips>> getTipsTrick() async {
    await Future.delayed(Duration(seconds: 3));
    final data = [
      Tips(),
    ];

    return Future.value(data);
  }
}
