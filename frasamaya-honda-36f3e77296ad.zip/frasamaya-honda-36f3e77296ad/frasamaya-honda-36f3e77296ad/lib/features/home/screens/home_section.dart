import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/config/app_config.dart';
import 'package:honda/core/blocs/authentication/authentication_bloc.dart';
import 'package:honda/core/models/user.dart';
import 'package:honda/features/home/blocs/banner/banner_bloc.dart';
import 'package:honda/features/home/blocs/banner/banner_event.dart';
import 'package:honda/features/home/blocs/nearby/bloc.dart';
import 'package:honda/features/home/blocs/news/bloc.dart';
import 'package:honda/features/home/blocs/promo/bloc.dart';
import 'package:honda/features/home/blocs/tips_trick/bloc.dart';
import 'package:honda/features/home/widgets/home_section_banner_widget.dart';
import 'package:honda/features/home/widgets/home_section_nearby_event_widget.dart';
import 'package:honda/features/home/widgets/home_section_news_widget.dart';
import 'package:honda/features/home/widgets/home_section_promo_widget.dart';
import 'package:honda/features/home/widgets/home_section_services_widget.dart';
import 'package:honda/features/home/widgets/home_section_tips_trick_widget.dart';
import 'package:honda/features/home/widgets/home_section_user_info_widget.dart';

class HomeSection extends StatefulWidget {
  @override
  _HomeSectionState createState() => _HomeSectionState();
}

class _HomeSectionState extends State<HomeSection> {
  BannerBloc _bannerBloc;
  PromoBloc _promoBloc;
  NearbyBloc _nearbyBloc;
  TipsTrickBloc _tipsTrickBloc;
  NewsBloc _newsBloc;

  @override
  void initState() {
    _bannerBloc = BannerBloc();
    _promoBloc = PromoBloc();
    _nearbyBloc = NearbyBloc();
    _tipsTrickBloc = TipsTrickBloc();
    _newsBloc = NewsBloc();
    super.initState();

    _bannerBloc.add(GetBanner());
    _promoBloc.add(GetPromo());
    _nearbyBloc.add(GetNearby());
    _tipsTrickBloc.add(GetTipsTrick());
    _newsBloc.add(GetNews());
  }

  @override
  void dispose() {
    _bannerBloc.close();
    _promoBloc.close();
    _newsBloc.close();
    _tipsTrickBloc.close();
    _newsBloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    User user = BlocProvider.of<AuthenticationBloc>(context).user;

    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (context) => _bannerBloc),
        BlocProvider(create: (context) => _promoBloc),
        BlocProvider(create: (context) => _nearbyBloc),
        BlocProvider(create: (context) => _tipsTrickBloc),
        BlocProvider(create: (context) => _newsBloc),
      ],
      child: Container(
        width: double.infinity,
        child: RefreshIndicator(
          onRefresh: () async {
            _bannerBloc.add(GetBanner());
            _promoBloc.add(GetPromo());
            _nearbyBloc.add(GetNearby());
            _tipsTrickBloc.add(GetTipsTrick());
            _newsBloc.add(GetNews());
          },
          child: SingleChildScrollView(
            child: Stack(
              children: <Widget>[
                Container(
                  height: 220,
                  width: MediaQuery.of(context).size.width,
                  decoration: BoxDecoration(
                    color: AppConfig.of(context).color.primary.withAlpha(210),
                  ),
                ),
                Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: <Widget>[
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      margin: EdgeInsets.only(top: 40),
                      child: HomeSectionUserInfoWidget(
                        name: user.name,
                        image: NetworkImage(user.avatar ?? 'https://placehold.it/500'),
                      ),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 30),
                      child: HomeSectionBannerWidget(),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      margin: EdgeInsets.only(top: 20),
                      child: HomeSectionServicesWidget(),
                    ),
                    Container(
                      margin: EdgeInsets.only(top: 20),
                      child: HomeSectionPromoWidget(),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      margin: EdgeInsets.only(top: 20),
                      child: HomeSectionNearbyEventWidget(),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      margin: EdgeInsets.only(top: 20),
                      child: HomeSectionTipsTrickWidget(),
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(horizontal: 20),
                      margin: EdgeInsets.only(top: 20),
                      child: HomeSectionNewsWidget(),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
