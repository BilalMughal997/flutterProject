import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/features/home/blocs/tips_trick/bloc.dart';
import 'package:honda/features/home/blocs/tips_trick/tips_trick_bloc.dart';
import 'package:honda/features/home/models/tips.dart';
import 'package:honda/screens/post_detail_screen.dart';
import 'package:honda/widgets/honda_button.dart';
import 'package:intl/intl.dart';

class AllTipsScreen extends StatefulWidget {
  @override
  _AllTipsScreenState createState() => _AllTipsScreenState();
}

class _AllTipsScreenState extends State<AllTipsScreen> {
  TipsTrickBloc _bloc;
  List<Tips> _tips;

  @override
  void initState() {
    _bloc = TipsTrickBloc();
    _tips = [];
    super.initState();

    _bloc.add(GetTipsTrick());
  }

  @override
  void dispose() {
    _bloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Semua Tips'),
      ),
      body: BlocProvider(
        create: (context) => _bloc,
        child: BlocListener(
          bloc: _bloc,
          listener: (context, state) {
            if (state is LoadedTipsTrickState) setState(() => _tips = state.items);
          },
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 20),
            margin: EdgeInsets.only(top: 20),
            child: SingleChildScrollView(
              child: Column(
                children: _buildItems(),
              ),
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _buildItems() {
    return _tips.map((e) {
      final df = DateFormat('yyyy-MM-dd HH:mm:ss');
      return SingleTipsList(
        id: e.id,
        title: e.title,
        date: df.parse(e.createdAt),
        image: NetworkImage(e.image ?? 'https://placehold.it/500'),
        onPressed: () {
          Navigator.push(
              context,
              MaterialPageRoute(
                  builder: (context) => PostDetailScreen(
                        image: NetworkImage(e.image),
                        date: e.createdAt != null ? df.parse(e.createdAt) : DateTime.now(),
                        title: e.title,
                        content: e.content,
                      )));
        },
      );
    }).toList();
  }
}

class SingleTipsList extends StatelessWidget {
  final String id;
  final String title;
  final ImageProvider image;
  final DateTime date;
  final VoidCallback onPressed;

  const SingleTipsList({
    Key key,
    this.id,
    this.title,
    this.image,
    this.date,
    this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    DateFormat dateFormat = DateFormat('dd MMM yyyy');

    return Container(
      width: MediaQuery.of(context).size.width,
      child: Column(
        children: <Widget>[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image(
                  image: this.image,
                  width: 70,
                  height: 70,
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Text(this.title, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                    SizedBox(
                      height: 20,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text(dateFormat.format(this.date)),
                        SizedBox(
                          height: 25,
                          child: PrimaryButton(
                            text: 'Baca',
                            onPressed: onPressed,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 20),
          Divider(height: 2, color: Colors.grey),
          SizedBox(height: 20),
        ],
      ),
    );
  }
}
