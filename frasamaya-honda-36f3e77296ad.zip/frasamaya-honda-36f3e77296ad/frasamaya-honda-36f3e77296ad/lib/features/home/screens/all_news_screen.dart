import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/features/home/blocs/news/bloc.dart';
import 'package:honda/features/home/models/news.dart';
import 'package:honda/screens/post_detail_screen.dart';
import 'package:honda/widgets/honda_button.dart';
import 'package:intl/intl.dart';

class AllNewsScreen extends StatefulWidget {
  @override
  _AllNewsScreenState createState() => _AllNewsScreenState();
}

class _AllNewsScreenState extends State<AllNewsScreen> {
  NewsBloc _bloc;
  List<News> _news;

  @override
  void initState() {
    _bloc = NewsBloc();
    _news = [];
    super.initState();

    _bloc.add(GetNews());
  }

  @override
  void dispose() {
    _bloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Semua News'),
      ),
      body: BlocProvider(
        create: (context) => _bloc,
        child: BlocListener(
          bloc: _bloc,
          listener: (context, state) {
            if (state is LoadedNewsState) setState(() => _news = state.items);
          },
          child: Container(
            padding: EdgeInsets.symmetric(horizontal: 20),
            margin: EdgeInsets.only(top: 20),
            child: SingleChildScrollView(
              child: Column(
                children: _buildItems(),
              ),
            ),
          ),
        ),
      ),
    );
  }

  List<Widget> _buildItems() {
    return _news.map((e) {
      final df = DateFormat('yyyy-MM-dd HH:mm:ss');
      final date = e.createdAt == null ? null : df.parse(e.createdAt);
      return SingleNewsList(
        id: e.id,
        title: e.title,
        date: date,
        image: NetworkImage(e.image ?? 'https://placehold.it/500'),
        onPressed: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => PostDetailScreen(
                image: NetworkImage(e.image),
                date: date,
                title: e.title,
                content: e.content,
              ),
            ),
          );
        },
      );
    }).toList();
  }
}

class SingleNewsList extends StatelessWidget {
  final String id;
  final String title;
  final ImageProvider image;
  final DateTime date;
  final VoidCallback onPressed;

  const SingleNewsList({
    Key key,
    this.id,
    this.title,
    this.image,
    this.date,
    this.onPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    DateFormat dateFormat = DateFormat('dd MMM yyyy');

    return Container(
      width: MediaQuery.of(context).size.width,
      child: Column(
        children: <Widget>[
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image(
                  image: this.image,
                  width: 70,
                  height: 70,
                ),
              ),
              SizedBox(width: 10),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: <Widget>[
                    Text(this.title, style: TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
                    SizedBox(
                      height: 20,
                    ),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: <Widget>[
                        Text(date == null ? '-' : dateFormat.format(this.date)),
                        SizedBox(
                          height: 25,
                          child: PrimaryButton(
                            text: 'Baca',
                            onPressed: onPressed,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ],
          ),
          SizedBox(height: 20),
          Divider(height: 2, color: Colors.grey),
          SizedBox(height: 20),
        ],
      ),
    );
  }
}
