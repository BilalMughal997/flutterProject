import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/features/home/blocs/banner/banner_bloc.dart';
import 'package:honda/features/home/blocs/banner/banner_event.dart';
import 'package:honda/features/home/blocs/banner/banner_state.dart';
import 'package:honda/features/home/models/banner.dart' as Model;

import 'file:///C:/Users/wandypurnomo/Documents/code/flutter/honda/lib/widgets/view_image_widget.dart';

class AllBannerScreen extends StatefulWidget {
  @override
  _AllBannerScreenState createState() => _AllBannerScreenState();
}

class _AllBannerScreenState extends State<AllBannerScreen> {
  BannerBloc _bloc;
  List<Model.Banner> _banners;

  @override
  void initState() {
    _bloc = BannerBloc();
    _banners = [];
    super.initState();
    _bloc.add(GetBanner());
  }

  @override
  void dispose() {
    _bloc.close();
    _banners.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('All Banner'),
      ),
      body: BlocProvider(
        create: (context) => _bloc,
        child: BlocListener(
          bloc: _bloc,
          listener: (context, state) {
            if (state is LoadedBannerState) setState(() => _banners = state.items);
          },
          child: Container(
            child: SingleChildScrollView(
              padding: EdgeInsets.symmetric(horizontal: 20),
              child: Column(
                children: _buildBanners(),
              ),
            ),
          ),
        ),
      ),
    );
  }

  _buildBanners() {
    return _banners
        .map<Widget>(
          (bi) => Builder(
            builder: (context) => InkWell(
              onTap: () {},
              child: InkWell(
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => ViewImageWidget(image: NetworkImage(bi.image))));
                },
                child: Container(
                  margin: EdgeInsets.only(bottom: 10),
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image(
                      image: NetworkImage(bi.image),
                      fit: BoxFit.fitHeight,
                    ),
                  ),
                ),
              ),
            ),
          ),
        )
        .toList();
  }
}
