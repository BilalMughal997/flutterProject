import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/features/home/blocs/promo/bloc.dart';
import 'package:honda/features/home/models/offer.dart';
import 'package:honda/features/home/screens/webview_detail_screen.dart';

import 'file:///C:/Users/wandypurnomo/Documents/code/flutter/honda/lib/widgets/view_image_widget.dart';

class AllPromoScreen extends StatefulWidget {
  @override
  _AllPromoScreenState createState() => _AllPromoScreenState();
}

class _AllPromoScreenState extends State<AllPromoScreen> {
  PromoBloc _bloc;
  List<Offer> _promos;

  @override
  void initState() {
    _bloc = PromoBloc();
    _promos = [];
    super.initState();

    _bloc.add(GetPromo());
  }

  @override
  void dispose() {
    _bloc.close();
    _promos.clear();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('All Promo'),
      ),
      body: BlocProvider(
        create: (context) => _bloc,
        child: BlocListener(
          bloc: _bloc,
          listener: (context, state) {
            if (state is LoadedPromoState) setState(() => _promos = state.items);
          },
          child: Container(
            child: GridView(
              padding: EdgeInsets.symmetric(horizontal: 20),
              gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
              ),
              shrinkWrap: true,
              children: _buildPromos(),
            ),
          ),
        ),
      ),
    );
  }

  _buildPromos() {
    return _promos
        .map<Widget>((item) => Container(
              margin: EdgeInsets.only(right: 20),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: InkWell(
                  onTap: () {
                    if (item.url != null)
                      Navigator.push(context, MaterialPageRoute(builder: (context) => WebviewDetailScreen(url: item.url)));
                    else
                      Navigator.push(context, MaterialPageRoute(builder: (context) => ViewImageWidget(image: NetworkImage(item.image))));
                  },
                  child: AspectRatio(
                      aspectRatio: 487 / 451,
                      child: new Container(
                        decoration: new BoxDecoration(
                            image: new DecorationImage(
                          fit: BoxFit.cover,
                          alignment: FractionalOffset.topCenter,
                          image: new NetworkImage(item.image),
                        )),
                      )),
                ),
              ),
            ))
        .toList();
  }
}
