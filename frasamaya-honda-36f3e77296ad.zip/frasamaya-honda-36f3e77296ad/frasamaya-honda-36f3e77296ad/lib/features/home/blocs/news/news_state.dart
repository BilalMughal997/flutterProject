import 'package:equatable/equatable.dart';
import 'package:honda/features/home/models/news.dart';

abstract class NewsState extends Equatable {
  const NewsState();
}

class InitialNewsState extends NewsState {
  @override
  List<Object> get props => [];
}

class LoadingNewsState extends NewsState {
  @override
  List<Object> get props => null;
}

class LoadedNewsState extends NewsState {
  final List<News> items;

  LoadedNewsState(this.items);

  @override
  List<Object> get props => [this.items];
}

class FailedNewsState extends NewsState {
  final String reason;

  FailedNewsState(this.reason);

  @override
  List<Object> get props => [this.reason];
}
