import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/home/contracts/news_repository_contract.dart';

import './bloc.dart';

class NewsBloc extends Bloc<NewsEvent, NewsState> {
  NewsRepositoryContract _newsTrickRepository;

  NewsBloc() {
    _newsTrickRepository = GetIt.I<NewsRepositoryContract>();
  }

  @override
  NewsState get initialState => InitialNewsState();

  @override
  Stream<NewsState> mapEventToState(
    NewsEvent event,
  ) async* {
    if (event is GetNews) {
      yield LoadingNewsState();

      try {
        final data = await _newsTrickRepository.getNews();
        yield LoadedNewsState(data);
      } catch (e) {
        yield FailedNewsState(e.toString());
      }
    }
  }
}
