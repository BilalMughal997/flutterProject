import 'package:equatable/equatable.dart';

abstract class PromoEvent extends Equatable {
  const PromoEvent();
}

class GetPromo extends PromoEvent {
  @override
  List<Object> get props => null;
}
