import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/home/contracts/promo_repository_contract.dart';
import 'package:honda/features/home/models/offer.dart';

import './bloc.dart';

class PromoBloc extends Bloc<PromoEvent, PromoState> {
  PromoRepositoryContract _promoRepository;
  List<Offer> _items;

  PromoBloc() {
    _promoRepository = GetIt.I<PromoRepositoryContract>();
  }

  @override
  PromoState get initialState => InitialPromoState();

  @override
  Stream<PromoState> mapEventToState(
    PromoEvent event,
  ) async* {
    if (event is GetPromo) {
      yield LoadingPromoState();

      try {
        _items = await _promoRepository.getPromo();
        yield LoadedPromoState(_items);
      } catch (e) {
        yield FailedPromoState(e.toString());
      }
    }
  }
}
