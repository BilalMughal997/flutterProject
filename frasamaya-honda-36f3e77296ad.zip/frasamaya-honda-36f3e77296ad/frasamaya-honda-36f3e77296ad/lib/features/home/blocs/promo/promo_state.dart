import 'package:equatable/equatable.dart';
import 'package:honda/features/home/models/offer.dart';

abstract class PromoState extends Equatable {
  const PromoState();
}

class InitialPromoState extends PromoState {
  @override
  List<Object> get props => [];
}

class LoadingPromoState extends PromoState {
  @override
  List<Object> get props => null;
}

class LoadedPromoState extends PromoState {
  final List<Offer> items;

  LoadedPromoState(this.items);

  @override
  List<Object> get props => [this.items];
}

class FailedPromoState extends PromoState {
  final String reason;

  FailedPromoState(this.reason);

  @override
  List<Object> get props => [this.reason];
}
