import 'package:equatable/equatable.dart';
import 'package:honda/features/home/models/event.dart';

abstract class NearbyState extends Equatable {
  const NearbyState();
}

class InitialNearbyState extends NearbyState {
  @override
  List<Object> get props => [];
}

class LoadingNearbyState extends NearbyState {
  @override
  List<Object> get props => null;
}

class LoadedNearbyState extends NearbyState {
  final List<Event> items;

  LoadedNearbyState(this.items);

  @override
  List<Object> get props => [this.items];
}

class FailedNearbyState extends NearbyState {
  final String reason;

  FailedNearbyState(this.reason);

  @override
  List<Object> get props => [this.reason];
}
