import 'package:equatable/equatable.dart';

abstract class NearbyEvent extends Equatable {
  const NearbyEvent();
}

class GetNearby extends NearbyEvent {
  @override
  List<Object> get props => null;
}
