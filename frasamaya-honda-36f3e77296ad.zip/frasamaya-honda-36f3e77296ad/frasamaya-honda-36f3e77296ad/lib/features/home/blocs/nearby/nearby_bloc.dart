import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/home/contracts/nearby_repository_contract.dart';

import './bloc.dart';

class NearbyBloc extends Bloc<NearbyEvent, NearbyState> {
  NearbyRepositoryContract _nearbyRepository;

  NearbyBloc() {
    _nearbyRepository = GetIt.I<NearbyRepositoryContract>();
  }

  @override
  NearbyState get initialState => InitialNearbyState();

  @override
  Stream<NearbyState> mapEventToState(
    NearbyEvent event,
  ) async* {
    if (event is GetNearby) {
      yield LoadingNearbyState();

      try {
        final data = await _nearbyRepository.getNearbyEvent();
        yield LoadedNearbyState(data);
      } catch (e) {
        yield FailedNearbyState(e.toString());
      }
    }
  }
}
