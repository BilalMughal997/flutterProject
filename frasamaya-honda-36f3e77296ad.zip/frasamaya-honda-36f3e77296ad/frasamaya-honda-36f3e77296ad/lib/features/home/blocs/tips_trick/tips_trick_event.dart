import 'package:equatable/equatable.dart';

abstract class TipsTrickEvent extends Equatable {
  const TipsTrickEvent();
}

class GetTipsTrick extends TipsTrickEvent {
  @override
  List<Object> get props => null;
}
