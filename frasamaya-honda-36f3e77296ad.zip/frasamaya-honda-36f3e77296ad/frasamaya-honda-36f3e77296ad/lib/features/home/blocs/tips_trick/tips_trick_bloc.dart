import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/home/contracts/tips_trick_repository_contract.dart';

import './bloc.dart';

class TipsTrickBloc extends Bloc<TipsTrickEvent, TipsTrickState> {
  TipsTrickRepositoryContract _tipsTrickRepository;

  TipsTrickBloc() {
    _tipsTrickRepository = GetIt.I<TipsTrickRepositoryContract>();
  }

  @override
  TipsTrickState get initialState => InitialTipsTrickState();

  @override
  Stream<TipsTrickState> mapEventToState(
    TipsTrickEvent event,
  ) async* {
    if (event is GetTipsTrick) {
      yield LoadingTipsTrickState();

      try {
        final data = await _tipsTrickRepository.getTipsTrick();
        yield LoadedTipsTrickState(data);
      } catch (e) {
        yield FailedTipsTrickState(e.toString());
      }
    }
  }
}
