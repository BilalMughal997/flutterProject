import 'package:equatable/equatable.dart';
import 'package:honda/features/home/models/tips.dart';

abstract class TipsTrickState extends Equatable {
  const TipsTrickState();
}

class InitialTipsTrickState extends TipsTrickState {
  @override
  List<Object> get props => [];
}

class LoadingTipsTrickState extends TipsTrickState {
  @override
  List<Object> get props => null;
}

class LoadedTipsTrickState extends TipsTrickState {
  final List<Tips> items;

  LoadedTipsTrickState(this.items);

  @override
  List<Object> get props => [this.items];
}

class FailedTipsTrickState extends TipsTrickState {
  final String reason;

  FailedTipsTrickState(this.reason);

  @override
  List<Object> get props => [this.reason];
}
