import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';
import 'package:honda/features/home/contracts/banner_repository_contract.dart';
import 'package:honda/features/home/models/banner.dart';

import './bloc.dart';

class BannerBloc extends Bloc<BannerEvent, BannerState> {
  BannerRepositoryContract _bannerRepository;
  List<Banner> _items;

  BannerBloc() {
    _bannerRepository = GetIt.I<BannerRepositoryContract>();
    _items = [];
  }

  List<Banner> get items => _items;

  @override
  BannerState get initialState => InitialBannerState();

  @override
  Stream<BannerState> mapEventToState(
    BannerEvent event,
  ) async* {
    if (event is GetBanner) {
      yield LoadingBannerState();

      try {
        _items = await _bannerRepository.getBanners();
        yield LoadedBannerState(_items);
      } catch (e) {
        yield FailedBannerState(e.toString());
      }
    }
  }
}
