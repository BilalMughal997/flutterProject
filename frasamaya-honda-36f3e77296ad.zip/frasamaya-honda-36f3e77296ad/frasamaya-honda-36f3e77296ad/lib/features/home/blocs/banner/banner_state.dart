import 'package:equatable/equatable.dart';
import 'package:honda/features/home/models/banner.dart';

abstract class BannerState extends Equatable {
  const BannerState();
}

class InitialBannerState extends BannerState {
  @override
  List<Object> get props => [];
}

class LoadingBannerState extends BannerState {
  @override
  List<Object> get props => null;
}

class LoadedBannerState extends BannerState {
  final List<Banner> items;

  LoadedBannerState(this.items);

  @override
  List<Object> get props => [this.items];
}

class FailedBannerState extends BannerState {
  final String reason;

  FailedBannerState(this.reason);

  @override
  List<Object> get props => [this.reason];
}
