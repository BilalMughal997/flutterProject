import 'package:chopper/chopper.dart';
import 'package:honda/core/client_preset.dart';

part 'home_api_service.chopper.dart';

@ChopperApi(baseUrl: '/')
abstract class HomeApiService extends ChopperService {
  @Get(path: 'banner')
  Future<Response> getBanners();

  @Get(path: 'banner/index/{id}')
  Future<Response> getBanner(@Path('id') int id);

  @Get(path: 'event')
  Future<Response> getEvents();

  @Get(path: 'event/index/{id}')
  Future<Response> getEvent(@Path('id') int id);

  @Get(path: 'offer')
  Future<Response> getOffers();

  @Get(path: 'offer/index/{id}')
  Future<Response> getOffer(@Path('id') int id);

  @Get(path: 'tips')
  Future<Response> getTipsTricks();

  @Get(path: 'tips/index/{id}')
  Future<Response> getTipsTrick(@Path('id') int id);

  @Get(path: 'news')
  Future<Response> getNewses();

  @Get(path: 'news/index/{id}')
  Future<Response> getNews(@Path('id') int id);

  static HomeApiService create() {
    final client = ClientPreset.authClient(services: [_$HomeApiService()]);
    return _$HomeApiService(client);
  }
}
