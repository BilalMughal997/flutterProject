import 'package:honda/features/home/models/tips.dart';

abstract class TipsTrickRepositoryContract {
  Future<List<Tips>> getTipsTrick();
}
