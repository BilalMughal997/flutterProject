import 'package:honda/features/home/models/news.dart';

abstract class NewsRepositoryContract {
  Future<List<News>> getNews();
}
