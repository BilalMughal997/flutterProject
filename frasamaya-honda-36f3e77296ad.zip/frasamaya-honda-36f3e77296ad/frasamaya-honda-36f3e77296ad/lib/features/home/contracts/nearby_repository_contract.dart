import 'package:honda/features/home/models/event.dart';

abstract class NearbyRepositoryContract {
  Future<List<Event>> getNearbyEvent();
}
