import 'package:honda/features/home/models/offer.dart';

abstract class PromoRepositoryContract {
  Future<List<Offer>> getPromo();
}
