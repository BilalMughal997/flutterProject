import 'package:honda/features/home/models/banner.dart';

abstract class BannerRepositoryContract {
  Future<List<Banner>> getBanners();
}
