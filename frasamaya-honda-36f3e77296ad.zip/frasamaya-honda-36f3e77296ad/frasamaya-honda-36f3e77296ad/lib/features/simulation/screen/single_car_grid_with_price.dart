import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:honda/config/app_config.dart';
import 'package:intl/intl.dart';

class SingleCarGridWithPrice extends StatelessWidget {
  final ImageProvider image;
  final String price;
  final VoidCallback onPressed;
  final String name;

  const SingleCarGridWithPrice({
    Key key,
    this.image: const NetworkImage('https://placehold.it/500x400'),
    @required this.onPressed,
    this.price,
    this.name,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final oCcy = new NumberFormat("#,###", "en_US");
    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(
          color: Colors.grey[300],
          width: 1,
        ),
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(10),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Container(
                padding: EdgeInsets.only(top: 20, left: 20, right: 20),
                child: AspectRatio(
                  aspectRatio: 5.5 / 4,
                  child: Image(
                    image: image,
                    fit: BoxFit.fitWidth,
                  ),
                )),
            Container(
              child: Text(
                'Rp. ${oCcy.format(int.parse(price))}',
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: AppConfig.of(context).color.accent,
                ),
              ),
            ),
            SizedBox(height: 10),
            Text(
              name ?? '-',
              textAlign: TextAlign.center,
            ),
            SizedBox(height: 4),
            Expanded(
              child: InkWell(
                onTap: onPressed,
                child: Container(
                  width: double.infinity,
                  color: AppConfig.of(context).color.primary,
                  child: Center(
                    child: Text(
                      'Detail',
                      style: TextStyle(color: Colors.white),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
