import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:honda/features/product/blocs/category/bloc.dart';
import 'package:honda/features/product/blocs/product/bloc.dart';
import 'package:honda/features/product/models/product.dart';
import 'package:honda/features/product/screens/product_detail_screen.dart';
import 'package:honda/features/product/widgets/category_container_widget.dart';
import 'package:honda/features/simulation/screen/simulation_screen.dart';
import 'package:honda/features/simulation/screen/single_car_grid_with_price.dart';
import 'package:honda/widgets/honda_button.dart';

class SimulationSection extends StatefulWidget {
  final GlobalKey<ScaffoldState> scaffoldKey;

  const SimulationSection({Key key, @required this.scaffoldKey}) : super(key: key);

  @override
  _SimulationSectionState createState() => _SimulationSectionState();
}

class _SimulationSectionState extends State<SimulationSection> {
  CategoryBloc _categoryBloc;
  ProductBloc _productBloc;
  List<CategoryItemModel> _categories;
  List<Product> _products;
  bool _loading;

  @override
  void initState() {
    _categoryBloc = CategoryBloc();
    _productBloc = ProductBloc();
    _categories = [];
    _products = [];
    _loading = false;
    super.initState();

    _categoryBloc.add(GetCategories());
    _productBloc.add(GetProducts());
  }

  @override
  void dispose() {
//    _categoryBloc.close();
    _productBloc.close();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (context) => _categoryBloc),
        BlocProvider(create: (context) => _productBloc),
      ],
      child: MultiBlocListener(
        listeners: [
          BlocListener(
            bloc: _categoryBloc,
            listener: (context, state) {
              if (state is LoadedCategoryState) {
                setState(() {
                  _categories.add(CategoryItemModel(id: '', label: 'All', active: true));
                  final remoteCategory = state.categories.map<CategoryItemModel>((c) => CategoryItemModel(id: c.id, label: c.name)).toList();
                  _categories.addAll(remoteCategory);
                });
              }
            },
          ),
          BlocListener(
            bloc: _productBloc,
            listener: (context, state) {
              if (state is LoadedProductState) {
                setState(() {
                  _products = state.products;
                  _loading = false;
                });
              }

              if (state is LoadingProductState) setState(() => _loading = true);
              if (state is FailedProductState) {
                setState(() => _loading = false);
                setState(() => _products.clear());
                widget.scaffoldKey.currentState.showSnackBar(SnackBar(content: Text('Pencarian tidak ditemukan.')));
              }
            },
          ),
        ],
        child: Container(
          child: CustomScrollView(
            slivers: <Widget>[
              SliverAppBar(
                expandedHeight: 60,
                bottom: PreferredSize(
                  // Add this code
                  preferredSize: Size.fromHeight(60), // Add this code
                  child: Text(''), // Add this code
                ),
                flexibleSpace: Container(
                  margin: EdgeInsets.only(top: 30),
                  padding: EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    children: <Widget>[
                      SizedBox(height: 10),
//                      Container(
//                        child: TextFormField(
//                          onChanged: (t) {
//                            _productBloc.add(GetProducts(search: t));
//                          },
//                          decoration: InputDecoration(
//                            isDense: true,
//                            contentPadding: EdgeInsets.symmetric(vertical: 5),
//                            hintText: 'Cari Mobil',
//                            border: OutlineInputBorder(),
//                            focusedBorder: OutlineInputBorder(
//                                borderSide: BorderSide(
//                              color: Colors.grey[300],
//                            )),
//                            enabledBorder: OutlineInputBorder(
//                                borderSide: BorderSide(
//                              color: Colors.grey[300],
//                            )),
//                            prefixIcon: IconButton(
//                              icon: Icon(Icons.search),
//                              onPressed: null,
//                            ),
//                          ),
//                        ),
//                      ),
//                      SizedBox(height: 10),
                      SizedBox(
                        width: double.infinity,
                        height: 30,
                        child: SecondaryButton(
                          text: 'Simulasi',
                          onPressed: () {
                            Navigator.push(context, MaterialPageRoute(builder: (context) => SimulationScreen()));
                          },
                        ),
                      ),
//                      SizedBox(height: 10),
//                      CategoryContainerWidget(
//                        categories: _categories,
//                        onChanged: (c) {
//                          print(c.label);
//                        },
//                      ),
                    ],
                  ),
                ),
                pinned: true,
                floating: true,
              ),
              SliverPadding(
                padding: EdgeInsets.symmetric(
                  horizontal: 20,
                  vertical: 20,
                ),
                sliver: _loading ? _buildLoading() : _buildList(),
              ),
            ],
          ),
        ),
      ),
    );
  }

  _buildList() {
    return SliverGrid.count(
      crossAxisCount: 2,
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 1 / 1.15,
      children: _products
          .map<Widget>((e) => SingleCarGridWithPrice(
                name: e.name,
                price: e.price,
                image: NetworkImage(e.image.first),
                onPressed: () {
                  Navigator.push(context, MaterialPageRoute(builder: (context) => ProductDetailScreen(product: e)));
                },
              ))
          .toList(),
    );
  }

  _buildLoading() {
    return SliverFillRemaining(
      child: Center(
        child: CircularProgressIndicator(),
      ),
    );
  }
}
