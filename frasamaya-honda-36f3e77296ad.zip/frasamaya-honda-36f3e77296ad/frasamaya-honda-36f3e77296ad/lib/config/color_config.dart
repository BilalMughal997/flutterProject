import 'dart:ui';

import 'package:supercharged/supercharged.dart';

class ColorConfig {
  final Color primary = '#9C2E2E'.toColor();
  final Color accent = '#F3A029'.toColor();
}
