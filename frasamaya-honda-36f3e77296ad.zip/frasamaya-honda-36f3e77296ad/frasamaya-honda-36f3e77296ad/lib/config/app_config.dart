import 'package:flutter/material.dart';
import 'package:honda/config/color_config.dart';

class AppConfig extends InheritedWidget {
//  static const String BASE_URL = "https://honda.faqihamruddin.com/api";
  static const String BASE_URL = "https://honda.lumira.live/api";
  static const String ENV = "dev";
  static const bool showResponse = true;

  final ColorConfig color = ColorConfig();
  final Widget child;

  AppConfig({@required this.child}) : super(child: child);

  @override
  bool updateShouldNotify(InheritedWidget oldWidget) => false;

  static AppConfig of(BuildContext context) => context.dependOnInheritedWidgetOfExactType<AppConfig>();
}
