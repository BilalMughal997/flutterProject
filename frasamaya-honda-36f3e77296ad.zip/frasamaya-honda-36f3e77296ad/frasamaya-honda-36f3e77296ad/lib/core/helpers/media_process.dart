import 'dart:io';

import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path/path.dart' as p;

Future<File> pickImageFromGallery({
  bool withCropper: false,
  int maxWidth,
  int maxHeight,
}) async {
  File pickedImage = await ImagePicker.pickImage(source: ImageSource.gallery);
  if (withCropper) {
    pickedImage = await ImageCropper.cropImage(
      sourcePath: pickedImage.path,
      aspectRatio: CropAspectRatio(ratioX: 1, ratioY: 1),
      maxWidth: maxWidth,
      maxHeight: maxWidth,
      iosUiSettings: IOSUiSettings(
        aspectRatioPickerButtonHidden: true,
      ),
      androidUiSettings: AndroidUiSettings(
        lockAspectRatio: true,
      ),
    );
  }

  return pickedImage;
}

Future<File> pickImageFromCamera({
  bool withCropper: false,
  int maxWidth,
  int maxHeight,
}) async {
  File pickedImage = await ImagePicker.pickImage(source: ImageSource.camera);
  if (withCropper) {
    pickedImage = await ImageCropper.cropImage(
      sourcePath: pickedImage.path,
      aspectRatio: CropAspectRatio(ratioX: 1, ratioY: 1),
      iosUiSettings: IOSUiSettings(
        aspectRatioPickerButtonHidden: true,
      ),
      androidUiSettings: AndroidUiSettings(
        lockAspectRatio: true,
      ),
      maxWidth: maxWidth,
      maxHeight: maxWidth,
    );
  }

  return pickedImage;
}

Future<File> pickVideo(ImageSource source) async {
  File video = await ImagePicker.pickVideo(source: source);

  if (p.extension(video.path) == ".mp4") {
    if (video.lengthSync() < 10000) {
      return video;
    }
    throw Exception("File size too big");
  } else {
    throw Exception("File type not supported yet.");
  }
}
