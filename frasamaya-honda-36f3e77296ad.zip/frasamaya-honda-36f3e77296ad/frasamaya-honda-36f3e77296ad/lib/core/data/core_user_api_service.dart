import 'package:chopper/chopper.dart';

import '../client_preset.dart';

part 'core_user_api_service.chopper.dart';

@ChopperApi(baseUrl: 'user')
abstract class CoreUserApiService extends ChopperService {
  @Get(path: 'detail')
  Future<Response> profile();

  static CoreUserApiService create() {
    final client = ClientPreset.authClient(services: [_$CoreUserApiService()]);
    return _$CoreUserApiService(client);
  }
}
