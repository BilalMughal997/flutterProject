import '../contracts/auth_repository_contract.dart';
import '../models/user.dart';

class DummyAuthRepository implements AuthRepositoryContract {
  @override
  Future<User> getUser() async {
    await Future.delayed(Duration(seconds: 2));
//    return Future.error("not authenticated"); //TODO: change here to continue authentication.
    return Future.value(User(name: 'wandy purnomo', email: 'wandypurnomo92@gmail.com', avatar: 'https://placehold.it/500', phone: '08938873983'));
  }
}
