import '../contracts/auth_repository_contract.dart';
import '../data/core_user_api_service.dart';
import '../models/user.dart';

class AuthRepository implements AuthRepositoryContract {
  CoreUserApiService _service;

  AuthRepository() {
    _service = CoreUserApiService.create();
  }

  @override
  Future<User> getUser() async {
    final resp = await _service.profile();
    return User.fromJson(resp.body['data']);
  }
}
