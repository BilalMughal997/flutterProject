import '../models/user.dart';

abstract class AuthRepositoryContract {
  Future<User> getUser();
}
