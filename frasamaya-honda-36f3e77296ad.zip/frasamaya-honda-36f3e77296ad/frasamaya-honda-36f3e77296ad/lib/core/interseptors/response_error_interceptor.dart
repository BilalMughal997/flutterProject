import 'dart:async';
import 'dart:convert';

import 'package:chopper/chopper.dart';

import '../../config/app_config.dart';

class ResponseErrorInterceptor implements ResponseInterceptor {
  @override
  FutureOr<Response> onResponse(Response response) {
    if (AppConfig.showResponse) {
      print("statusCode: ${response.statusCode}");
      print('body -----------------------------------------');
      print(response.body ?? response.bodyString);
      print('----------------------------------------------');
    }
    if (response.statusCode < 200 || response.statusCode >= 300) {
      List<String> messages = [];
      if (response.body != null || response.bodyString != null) {
        var body = response.body ?? jsonDecode(response.bodyString);
        try {
          List<String> message = [];
          Map<String, dynamic> errors = body["errors"];

          errors.forEach((k, v) {
            v.forEach((msg) {
              message.add("$k : $msg");
            });
          });

          messages.add(message.first);
        } catch (error) {
          messages.add(body["message"]);
        } finally {
          messages.add("Terjadi kesalahan");
        }
      }

      messages.add("No Data");
      throw Exception(messages.first);
    }
    return response;
  }
}
