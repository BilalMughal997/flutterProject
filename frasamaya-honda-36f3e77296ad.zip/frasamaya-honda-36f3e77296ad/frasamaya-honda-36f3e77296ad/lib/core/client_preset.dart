import 'package:chopper/chopper.dart';
import 'package:flutter/widgets.dart';

import '../config/app_config.dart';
import 'interseptors/auth_request_interceptor.dart';
import 'interseptors/response_error_interceptor.dart';

class ClientPreset {
  static ChopperClient authClient({@required List<ChopperService> services}) {
    return ChopperClient(
      baseUrl: AppConfig.BASE_URL,
      services: services,
      interceptors: [
        ResponseErrorInterceptor(),
        HttpLoggingInterceptor(),
        AuthRequestInterceptor(),
        HeadersInterceptor({
          "Content-Type": "application/json",
          "Accept": "application/json",
        }),
      ],
      converter: JsonConverter(),
    );
  }

  static ChopperClient client({@required List<ChopperService> services}) {
    return ChopperClient(
      baseUrl: AppConfig.BASE_URL,
      services: services,
      interceptors: [
        ResponseErrorInterceptor(),
        HttpLoggingInterceptor(),
        HeadersInterceptor({
          "Content-Type": "application/json",
          "Accept": "application/json",
        }),
      ],
      converter: JsonConverter(),
    );
  }

  static ChopperClient authClientMultipart({@required List<ChopperService> services}) {
    return ChopperClient(
      baseUrl: AppConfig.BASE_URL,
      services: services,
      interceptors: [
        ResponseErrorInterceptor(),
        HttpLoggingInterceptor(),
        AuthRequestInterceptor(),
        HeadersInterceptor({
          "Content-Type": "multipart/form-data",
          "Accept": "application/json",
        }),
      ],
      converter: JsonConverter(),
    );
  }
}
