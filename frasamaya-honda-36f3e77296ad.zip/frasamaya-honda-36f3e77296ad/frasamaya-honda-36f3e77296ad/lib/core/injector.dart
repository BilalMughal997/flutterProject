import 'package:get_it/get_it.dart';
import 'package:honda/core/repositories/auth_repository.dart';
import 'package:honda/core/repositories/dummy_auth_repository.dart';
import 'package:honda/features/credential/contracts/change_password_repository_contract.dart';
import 'package:honda/features/credential/contracts/change_phone_repository_contract.dart';
import 'package:honda/features/credential/contracts/login_repository_contract.dart';
import 'package:honda/features/credential/contracts/otp_repository_contract.dart';
import 'package:honda/features/credential/contracts/register_repository_contract.dart';
import 'package:honda/features/credential/repositories/change_password_repository.dart';
import 'package:honda/features/credential/repositories/change_phone_repository.dart';
import 'package:honda/features/credential/repositories/dummy_login_repository.dart';
import 'package:honda/features/credential/repositories/dummy_register_repository.dart';
import 'package:honda/features/credential/repositories/login_repository.dart';
import 'package:honda/features/credential/repositories/otp_repository.dart';
import 'package:honda/features/credential/repositories/register_repository.dart';
import 'package:honda/features/home/contracts/banner_repository_contract.dart';
import 'package:honda/features/home/contracts/nearby_repository_contract.dart';
import 'package:honda/features/home/contracts/news_repository_contract.dart';
import 'package:honda/features/home/contracts/promo_repository_contract.dart';
import 'package:honda/features/home/contracts/tips_trick_repository_contract.dart';
import 'package:honda/features/home/repositories/banner_repository.dart';
import 'package:honda/features/home/repositories/dummy_banner_repository.dart';
import 'package:honda/features/home/repositories/dummy_nearby_repository.dart';
import 'package:honda/features/home/repositories/dummy_news_repository.dart';
import 'package:honda/features/home/repositories/dummy_promo_repository.dart';
import 'package:honda/features/home/repositories/dummy_tips_trick_repository.dart';
import 'package:honda/features/home/repositories/nearby_repository.dart';
import 'package:honda/features/home/repositories/news_repository.dart';
import 'package:honda/features/home/repositories/promo_repository.dart';
import 'package:honda/features/home/repositories/tips_trick_repository.dart';
import 'package:honda/features/page/contracts/page_repository_contract.dart';
import 'package:honda/features/page/repositories/page_repository.dart';
import 'package:honda/features/product/contracts/product_repository_contract.dart';
import 'package:honda/features/product/repositories/product_repository.dart';
import 'package:honda/features/profile/contracts/user_repository_contract.dart';
import 'package:honda/features/profile/repositories/user_repository.dart';
import 'package:honda/features/service/contracts/booking_repository_contract.dart';
import 'package:honda/features/service/contracts/vehicle_repository_contract.dart';
import 'package:honda/features/service/repositories/booking_repository.dart';
import 'package:honda/features/service/repositories/vehicle_repository.dart';

import 'contracts/auth_repository_contract.dart';

class Injector {
  static serviceLocator(String env) {
    if (env == 'local') {
      // CORE
      GetIt.I.registerLazySingleton<AuthRepositoryContract>(() => DummyAuthRepository());

      // CREDENTIAL
      GetIt.I.registerLazySingleton<LoginRepositoryContract>(() => DummyLoginRepository());
      GetIt.I.registerLazySingleton<RegisterRepositoryContract>(() => DummyRegisterRepository());
      GetIt.I.registerLazySingleton<ChangePasswordRepositoryContract>(() => ChangePasswordRepository());

      // HOME
      GetIt.I.registerLazySingleton<BannerRepositoryContract>(() => DummyBannerRepository());
      GetIt.I.registerLazySingleton<PromoRepositoryContract>(() => DummyPromoRepository());
      GetIt.I.registerLazySingleton<NearbyRepositoryContract>(() => DummyNearbyRepository());
      GetIt.I.registerLazySingleton<TipsTrickRepositoryContract>(() => DummyTipsTrickRepository());
      GetIt.I.registerLazySingleton<NewsRepositoryContract>(() => DummyNewsRepository());
    }

    if (env == 'dev') {
      // CORE
      GetIt.I.registerLazySingleton<AuthRepositoryContract>(() => AuthRepository());

      // CREDENTIAL
      GetIt.I.registerLazySingleton<LoginRepositoryContract>(() => LoginRepository());
      GetIt.I.registerLazySingleton<OtpRepositoryContract>(() => OtpRepository());
      GetIt.I.registerLazySingleton<RegisterRepositoryContract>(() => RegisterRepository());
      GetIt.I.registerLazySingleton<ChangePasswordRepositoryContract>(() => ChangePasswordRepository());
      GetIt.I.registerLazySingleton<ChangePhoneRepositoryContract>(() => ChangePhoneRepository());

      // HOME
      GetIt.I.registerLazySingleton<BannerRepositoryContract>(() => BannerRepository());
      GetIt.I.registerLazySingleton<PromoRepositoryContract>(() => PromoRepository());
      GetIt.I.registerLazySingleton<NearbyRepositoryContract>(() => NearbyRepository());
      GetIt.I.registerLazySingleton<TipsTrickRepositoryContract>(() => TipsTrickRepository());
      GetIt.I.registerLazySingleton<NewsRepositoryContract>(() => NewsRepository());

      // Product
      GetIt.I.registerLazySingleton<ProductRepositoryContract>(() => ProductRepository());

      // Service
      GetIt.I.registerLazySingleton<VehicleRepositoryContract>(() => VehicleRepository());
      GetIt.I.registerLazySingleton<BookingRepositoryContract>(() => BookingRepository());

      // USER
      GetIt.I.registerLazySingleton<UserRepositoryContract>(() => UserRepository());

      // PAGE
      GetIt.I.registerLazySingleton<PageRepositoryContract>(() => PageRepository());
    }
  }
}
