abstract class AuthenticationEvent {
  const AuthenticationEvent();
}

class Authenticate extends AuthenticationEvent {}

class AuthenticateAgain extends AuthenticationEvent {}

class RefreshUser extends AuthenticationEvent {}

class Logout extends AuthenticationEvent {}
