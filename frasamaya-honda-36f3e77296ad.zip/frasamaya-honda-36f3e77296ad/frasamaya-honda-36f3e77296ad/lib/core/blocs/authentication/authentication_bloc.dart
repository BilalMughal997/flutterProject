import 'dart:async';

import 'package:bloc/bloc.dart';
import 'package:get_it/get_it.dart';

import './bloc.dart';
import '../..//helpers/prefs.dart';
import '../../contracts/auth_repository_contract.dart';
import '../../models/user.dart';

class AuthenticationBloc extends Bloc<AuthenticationEvent, AuthenticationState> {
  AuthRepositoryContract _authRepository;
  User _user;

  User get user => _user;

  AuthenticationBloc() {
    _authRepository = GetIt.I<AuthRepositoryContract>();
  }

  @override
  AuthenticationState get initialState => InitialAuthenticationState();

  @override
  Stream<AuthenticationState> mapEventToState(
    AuthenticationEvent event,
  ) async* {
    if (event is Authenticate) {
      yield LoadingAuthenticationState();

      try {
        _user = await _authRepository.getUser();
        yield SuccessAuthenticationState(_user);
      } catch (e) {
        yield FailedAuthenticationState(e.toString());
      }
    }

    if (event is Logout) {
      setToken('');
      yield FailedAuthenticationState('Logout');
    }

    if (event is RefreshUser) {
      _user = await _authRepository.getUser();
    }
  }
}
