import '../../models/user.dart';

abstract class AuthenticationState {
  const AuthenticationState();
}

class InitialAuthenticationState extends AuthenticationState {}

class LoadingAuthenticationState extends AuthenticationState {}

class SuccessAuthenticationState extends AuthenticationState {
  final User user;

  SuccessAuthenticationState(this.user);
}

class FailedAuthenticationState extends AuthenticationState {
  final String reason;

  FailedAuthenticationState(this.reason);
}
