class Credential {
  String phone;
  String password;
  String fcm;

  Credential({this.phone, this.password, this.fcm});

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['phone'] = this.phone;
    data['password'] = this.password;
    data['fcm'] = this.fcm;
    return data;
  }
}

class Register {
  String email;
  String name;
  String password;
  String passwordConfirmation;
  String phone;

  Register({this.email, this.name, this.password, this.passwordConfirmation, this.phone});

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['email'] = this.email;
    data['name'] = this.name;
    data['password'] = this.password;
    data['repassword'] = this.passwordConfirmation;
    data['phone'] = this.phone;
    return data;
  }
}

class User {
  String avatar;
  String email;
  String id;
  String name;
  String phone;
  bool status;

  User({
    this.avatar,
    this.email,
    this.id,
    this.name,
    this.phone,
    this.status,
  });

  factory User.fromJson(Map<String, dynamic> json) {
    return User(
      avatar: json['avatar'],
      email: json['email'],
      id: json['id_user'],
      name: json['name'],
      phone: json['phone'],
      status: json['status'] == '1',
    );
  }
}
