import 'package:flutter/material.dart';
import 'package:honda/config/app_config.dart';

class HondaNavigationWidget extends StatefulWidget {
  final HondaMenu currentMenu;
  final ValueChanged<HondaMenu> onChanged;

  const HondaNavigationWidget({
    Key key,
    this.currentMenu,
    this.onChanged,
  }) : super(key: key);

  @override
  _HondaNavigationWidgetState createState() => _HondaNavigationWidgetState();
}

class _HondaNavigationWidgetState extends State<HondaNavigationWidget> {
  HondaMenu _currentMenu;

  @override
  void initState() {
    _currentMenu = widget.currentMenu ?? HondaMenu.HOME;
    super.initState();
  }

  @override
  void didUpdateWidget(HondaNavigationWidget oldWidget) {
    super.didUpdateWidget(oldWidget);
    setState(() => _currentMenu = widget.currentMenu ?? HondaMenu.HOME);
  }

  @override
  Widget build(BuildContext context) {
    final config = AppConfig.of(context);
    return Container(
      child: BottomNavigationBar(
        currentIndex: _currentMenu.index,
        onTap: _onTap,
        showSelectedLabels: true,
        fixedColor: config.color.primary,
        items: _navigationList()
            .map<BottomNavigationBarItem>(
              (nav) => BottomNavigationBarItem(
                icon: Image(image: nav['icon'], height: 25),
                activeIcon: Image(image: nav['activeIcon'], height: 25),
                title: Text(
                  nav['name'],
                  style: TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
            )
            .toList(),
      ),
    );
  }

  List<Map<String, dynamic>> _navigationList() {
    return [
      {
        'name': 'Beranda',
        'activeIcon': AssetImage('assets/icons/home_active.png'),
        'icon': AssetImage('assets/icons/home.png'),
      },
      {
        'name': 'Produk',
        'activeIcon': AssetImage('assets/icons/product_active.png'),
        'icon': AssetImage('assets/icons/product.png'),
      },
      {
        'name': 'Servis',
        'activeIcon': AssetImage('assets/icons/service_active.png'),
        'icon': AssetImage('assets/icons/service.png'),
      },
      {
        'name': 'Simulasi',
        'activeIcon': AssetImage('assets/icons/simulation_active.png'),
        'icon': AssetImage('assets/icons/simulation.png'),
      },
      {
        'name': 'Profil',
        'activeIcon': AssetImage('assets/icons/profile_active.png'),
        'icon': AssetImage('assets/icons/profile.png'),
      }
    ];
  }

  _onTap(int menu) {
    switch (menu) {
      case 1:
        setState(() => _currentMenu = HondaMenu.PRODUCT);
        break;
      case 2:
        setState(() => _currentMenu = HondaMenu.SERVICE);
        break;
      case 3:
        setState(() => _currentMenu = HondaMenu.SIMULATION);
        break;
      case 4:
        setState(() => _currentMenu = HondaMenu.PROFILE);
        break;
      default:
        setState(() => _currentMenu = HondaMenu.HOME);
        break;
    }
    widget.onChanged(_currentMenu);
  }
}

enum HondaMenu {
  HOME,
  PRODUCT,
  SERVICE,
  SIMULATION,
  PROFILE,
}
