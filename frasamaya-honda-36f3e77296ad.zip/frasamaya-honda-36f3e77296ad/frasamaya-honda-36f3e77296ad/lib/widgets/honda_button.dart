import 'package:flutter/material.dart';
import 'package:honda/config/app_config.dart';

class PrimaryButton extends StatefulWidget {
  final String text;
  final bool loading;
  final VoidCallback onPressed;
  final double fontSize;

  const PrimaryButton({
    Key key,
    this.text,
    this.loading: false,
    this.onPressed,
    this.fontSize: 17.0,
  }) : super(key: key);

  @override
  _PrimaryButtonState createState() => _PrimaryButtonState();
}

class _PrimaryButtonState extends State<PrimaryButton> {
  bool _loading;

  @override
  void initState() {
    _loading = widget.loading;
    super.initState();
  }

  @override
  void didUpdateWidget(PrimaryButton oldWidget) {
    super.didUpdateWidget(oldWidget);
    setState(() => _loading = widget.loading);
  }

  @override
  Widget build(BuildContext context) {
    final config = AppConfig.of(context);
    return Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: config.color.primary.withOpacity(0.5),
              spreadRadius: -5,
              blurRadius: 10,
              offset: Offset(0, 1), // changes position of shadow
            ),
          ],
        ),
        child: FlatButton(
          color: config.color.primary,
          disabledColor: Colors.grey.withAlpha(50),
          textColor: Colors.white,
          child: _defineChild(),
          onPressed: _loading ? null : widget.onPressed,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ));
  }

  _defineChild() {
    if (_loading) {
      return Container(
        width: 20,
        height: 20,
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation(Colors.grey),
        ),
      );
    }

    return Text(
      widget.text,
      style: TextStyle(
        fontWeight: FontWeight.w500,
        fontSize: widget.fontSize,
      ),
    );
  }
}

class SecondaryButton extends StatefulWidget {
  final String text;
  final bool loading;
  final VoidCallback onPressed;
  final double fontSize;

  const SecondaryButton({
    Key key,
    this.text,
    this.loading: false,
    this.onPressed,
    this.fontSize: 17.0,
  }) : super(key: key);

  @override
  _SecondaryButtonState createState() => _SecondaryButtonState();
}

class _SecondaryButtonState extends State<SecondaryButton> {
  bool _loading;

  @override
  void initState() {
    _loading = widget.loading;
    super.initState();
  }

  @override
  void didUpdateWidget(SecondaryButton oldWidget) {
    super.didUpdateWidget(oldWidget);
    setState(() => _loading = widget.loading);
  }

  @override
  Widget build(BuildContext context) {
    final config = AppConfig.of(context);
    return DecoratedBox(
      decoration: ShapeDecoration(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        color: Colors.white,
      ),
      child: Theme(
        data: Theme.of(context).copyWith(
          buttonTheme: ButtonTheme.of(context).copyWith(
            materialTapTargetSize: MaterialTapTargetSize.shrinkWrap,
          ),
        ),
        child: OutlineButton(
          textColor: config.color.primary,
          disabledTextColor: Colors.blueGrey,
          color: Colors.white,
          focusColor: Colors.white,
          hoverColor: config.color.primary,
          borderSide: BorderSide(
            width: 1.5,
            color: config.color.primary,
          ),
          highlightedBorderColor: config.color.primary,
          child: _defineChild(),
          onPressed: _loading ? null : widget.onPressed,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
      ),
    );
  }

  _defineChild() {
    if (_loading) {
      return Container(
        height: 20,
        width: 20,
        child: CircularProgressIndicator(
          valueColor: AlwaysStoppedAnimation(Colors.grey),
          strokeWidth: 1.5,
        ),
      );
    }

    return Text(
      widget.text,
      style: TextStyle(
        fontWeight: FontWeight.w500,
        fontSize: widget.fontSize,
      ),
    );
  }
}
