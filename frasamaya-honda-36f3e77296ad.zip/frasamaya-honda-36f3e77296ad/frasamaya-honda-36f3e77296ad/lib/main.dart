import 'package:flutter/material.dart';
import 'package:honda/config/app_config.dart';
import 'package:honda/core/injector.dart';
import 'package:honda/screens/root_screen.dart';
import 'package:logging/logging.dart';

void main() {
  Injector.serviceLocator(AppConfig.ENV);
  setupLogging();

  String s = "089630567193";
  print(s.substring(1, s.length));

  final app = AppConfig(
    child: RootScreen(),
  );

  runApp(app);
}

void setupLogging() {
  Logger.root.level = Level.ALL;
  Logger.root.onRecord.listen((rec) {
    print('${rec.level.name}: ${rec.time}: ${rec.message}');
  });
}
